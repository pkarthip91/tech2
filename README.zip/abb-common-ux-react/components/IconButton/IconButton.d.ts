import * as React from 'react';
import { HtmlAttributes } from '../../internalUtils/HtmlAttributes';
export interface IconButtonProps extends HtmlAttributes {
    /** Dim the button and disable click events */
    disabled?: boolean;
    /** Similar to 'disabled', but does not dim the content, and does not change the cursor to not-allowed. */
    isClickable: boolean;
    /** Fired when user clicks the button. Custom data can be included as callback attribute fo* easier event handler mappings. */
    onClick?: (event: React.MouseEvent<HTMLElement>, customData: unknown) => void;
    sizeClass: 'extra-small' | 'small' | 'medium' | 'large';
    /** Custom data to be passed to the onClick event handler when user clicks the button. */
    data?: unknown;
}
export interface IconButtonState {
    some: number;
}
/**
 * Circular button, with three sizes: small (default), medium and large.
 * Implements a background coloring on hover/pressed state and click-handling.
 * Used internally in CloseButton, Collapsible (expansion/collapsion icon) and
 * Pagination (clickable page numbers). CloseButton is used in Dialog, Popup,
 * Notification and TabControl for close-functionality, and in Dropdown as
 * clear-value button.
 */
export declare class IconButton extends React.Component<IconButtonProps, IconButtonState> {
    static defaultProps: {
        sizeClass: string;
        disabled: boolean;
        isClickable: boolean;
    };
    constructor(props: IconButtonProps);
    render(): JSX.Element;
    private _handleClick;
}
export default IconButton;
