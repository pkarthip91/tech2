import * as React from 'react';
import { HtmlAttributes } from '../../internalUtils/HtmlAttributes';
export interface SubMenuProps extends HtmlAttributes {
    /** The visible text value of the menuitem */
    text: string;
    /** Additional icon shown on the left side of the label text. */
    icon?: string;
    /** Dim and prevent clicks */
    disabled?: boolean;
    /** Add a blue bottom border to this item. */
    selected?: boolean;
}
/**
 * Second-level menu under a Menu component. Only to be used as a direct
 * child of Menu component, and only accepts MenuItem components as
 * children. Multi-level submenus are not supported, because they do not
 * provide good user experience.
 *
 * **Notes:**
 * - Accepts only MenuItem and MenuItemDivider components as children (nested SubMenu is not supported).
 */
export declare class SubMenu extends React.Component<SubMenuProps> {
    static readonly componentName = "SuMenu";
    constructor(props: SubMenuProps);
    render(): JSX.Element | null;
}
export default SubMenu;
