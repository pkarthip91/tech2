import * as React from 'react';
import { HtmlAttributes } from '../../internalUtils/HtmlAttributes';
export interface MenuItemProps extends HtmlAttributes {
    /** The visible text value of the menuitem */
    text?: string;
    /** A helper string for easier selection matching. Provided as callback parameter on Menu component 'onSelect' event. */
    itemId?: string;
    /** Additional icon shown on the left side of the label text. */
    icon?: string;
    /** Dim and prevent clicks */
    disabled: boolean;
    /** Add a blue bottom border to this item. */
    selected: boolean;
    /** Called when the item is selected. Note: you don't have to listen on this on all menuitems, but you can listen only once on the Menu component "onSelect" event. */
    onSelect?: (itemId: string | undefined) => void;
    /** Prevent any children. */
    children?: never;
}
/**
 * A single item in a Menu. To be used only as direct child of either Menu or SubMenu components.
 */
export declare class MenuItem extends React.Component<MenuItemProps> {
    static defaultProps: {
        disabled: boolean;
        selected: boolean;
    };
    static readonly componentName = "MenuItem";
    constructor(props: MenuItemProps);
    render(): JSX.Element | null;
}
export default MenuItem;
