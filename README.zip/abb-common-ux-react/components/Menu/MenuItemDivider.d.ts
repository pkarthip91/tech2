import * as React from 'react';
import { HtmlAttributes } from '../../internalUtils/HtmlAttributes';
export interface MenuItemDividerProps extends HtmlAttributes {
    /** Prevent any children. */
    children?: never;
}
/** Simple horizontal divider bar between two MenuItem components. */
export declare class MenuItemDivider extends React.Component<MenuItemDividerProps> {
    static readonly componentName = "MenuItemDivider";
    constructor(props: MenuItemDividerProps);
    render(): JSX.Element | null;
}
export default MenuItemDivider;
