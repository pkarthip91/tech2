import * as React from 'react';
import { HtmlAttributes } from '../../internalUtils/HtmlAttributes';
export interface MenuProps extends HtmlAttributes {
    /** How the submenus should open. */
    trigger?: 'click' | 'hover' | 'none';
    /** Fired whenever user click any visible area of the menu or one of its descendants. */
    onClick?: (event: React.MouseEvent<HTMLElement>) => void;
    /** Fired whenever user selects (i.e. clicks) any MenuItem from the menu */
    onSelect?: (item: {
        text: string;
        id: string;
    }) => void;
    /** Fired when the user clicks somewhere outside the bounding box of the menu */
    onLostFocus?: () => void;
    /** How to align the menu with its parent component bounding box. Use 'left' when on left side of the screen, and 'right' when on right side of the screen. */
    alignToParent?: 'left' | 'right';
    /** Only menu items, submenus and dividers are allowed as children. */
    /** Makes the menu black and white. */
    monochrome: boolean;
}
/**
 * Menu component is a container and manager for a number of MenuItem and SubMenu components.
 *
 * **Notes:**
 * - Accepts only MenuItem, SubMenu and MenuItemDivider components as children.
 */
export declare class Menu extends React.Component<MenuProps> {
    static defaultProps: {
        trigger: string;
        alignToParent: string;
        monochrome: boolean;
    };
    private wrapperRef;
    constructor(props: MenuProps);
    componentDidMount(): void;
    componentWillUnmount(): void;
    handleClickOutside(event: MouseEvent): void;
    render(): JSX.Element;
    private setWrapperRef;
    private walkChildren;
    private walkSubMenu;
    private onOpenChange;
    private _handleMenuClick;
    private _handleSelect;
}
export default Menu;
