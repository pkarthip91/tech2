import * as React from 'react';
export interface RadioOptionProps {
    value: string;
    text: string;
    disabled: boolean;
    /**
     * Internally set by the parent RadioGroup component. Do not use.
     * @ignore
     */
    _fromParent_: {
        groupName?: string;
        checked: boolean;
        monochrome?: boolean;
        onChange?: (value: string) => void;
    };
    /** Prevent any children. */
    children?: never;
}
/**
 * A single selectable option in a RadioButtonGroup. Value is required for selection matching. Used as direct child of RadioButtonGroup (or wrapper in some With- component, such as WithPopup)
 *
 * **Known issues:**
 * - Selection via keyboard does not work on Firefox or Safari in MacOS. In Windows they seem to work.
 */
export declare class RadioOption extends React.Component<RadioOptionProps> {
    static defaultProps: {
        _fromParent_: {};
        text: string;
        disabled: boolean;
    };
    constructor(props: RadioOptionProps);
    render(): JSX.Element;
    private _handleChange;
    private _handleClick;
}
export default RadioOption;
