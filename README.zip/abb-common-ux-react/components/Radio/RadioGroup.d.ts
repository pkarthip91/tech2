import * as React from 'react';
import { HtmlAttributes } from '../../internalUtils/HtmlAttributes';
export interface RadioGroupProps extends HtmlAttributes {
    /** Value of the selected radiobutton. Must match to 'value' attribute of a single RadioOption */
    value: string | undefined;
    /** Fired whenever the selection is changed by the user. Feed this value back to the 'value' prop, because this is a controlled component. */
    onChange?: (newState: string) => void;
    sizeClass: 'small' | 'large';
    orientation: 'vertical' | 'horizontal';
    /** Allow only RadioOptions as children, but allow wrapping them in WithPopup */
    /** Make radiobuttons black and white. */
    monochrome: boolean;
}
/**
 * Standard radiobuttons wrapped in React component for state management and styling.
 * Use RadioOption components as direct children of this component.
 *
 * **Notes:**
 * - This component is **controlled**, meaning that you **must** implement the state handling in the parent component.
 * - Accepts only RadioOptions as children.
 *
 * **Known issues:**
 * - Selection via keyboard does not work on Firefox or Safari in MacOS. In Windows they seem to work.
 */
export declare class RadioGroup extends React.Component<RadioGroupProps> {
    static defaultProps: {
        sizeClass: string;
        orientation: string;
        monochrome: boolean;
    };
    static GROUP_COUNTER: number;
    private groupName;
    constructor(props: RadioGroupProps);
    render(): JSX.Element;
    private handleChange;
}
export default RadioGroup;
