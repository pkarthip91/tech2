import * as React from 'react';
import { HtmlAttributes } from '../../internalUtils/HtmlAttributes';
export declare type SplitterPanelProps = HtmlAttributes;
export declare class SplitterPanel extends React.Component<SplitterPanelProps> {
    constructor(props: SplitterPanelProps);
    render(): JSX.Element;
}
export default SplitterPanel;
