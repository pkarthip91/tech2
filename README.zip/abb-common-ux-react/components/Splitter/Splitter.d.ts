import * as React from 'react';
import { HtmlAttributes } from '../../internalUtils/HtmlAttributes';
export interface SplitterProps extends HtmlAttributes {
    orientation: 'vertical' | 'horizontal';
    /** Set to false to freeze the panes. */
    allowResize?: boolean;
    primaryPane: 0 | 1;
    primaryPaneDefaultSize: number;
    primaryPaneMinSize: number;
    primaryPaneMaxSize: number;
    secondaryPaneMinSize: number;
    secondaryPaneMaxSize: number;
    step: number;
    onClick?: () => void;
    onDoubleClick?: () => void;
    onDragBegin?: () => void;
    onDragEnd?: (newSize: number) => void;
}
/**
 * This is just an early prototype. Not exported!
 * TODO: implement component
 * TODO: component interface documentation
 *
 * Visual display splitter component, that divides the given area into two panes, and
 * inserts a draggable, vertical or horizontal line between them, depending on the
 * orientation.
 *
 * **Notes:**
 * - Accepts only two SplitterPanel components as children
 */
export declare class Splitter extends React.Component<SplitterProps> {
    static defaultProps: {
        allowResize: boolean;
        primaryPane: number;
        primaryPaneDefaultSize: number;
        primaryPaneMinSize: number;
        primaryPaneMaxSize: number;
        secondaryPaneMinSize: number;
        secondaryPaneMaxSize: number;
        step: number;
    };
    constructor(props: SplitterProps);
    render(): JSX.Element;
}
export default Splitter;
