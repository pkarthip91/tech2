import * as React from 'react';
import { HtmlAttributes } from '../../internalUtils/HtmlAttributes';
export interface DataPoint {
    /** Current value */
    value: number;
    /** Title of the value, shown in legend and tooltip */
    label: string;
    /** Color of the segment */
    color: string;
    /** Identifier of the value, must be unique (this is compulsory, because value and label cannot be used alone, since they may change) */
    key: string;
}
export interface DonutChartProps extends HtmlAttributes {
    /** Fired when user clicks the component. */
    onClick?: (event: React.MouseEvent<HTMLElement>) => void;
    /** Ordered list of values (with labels and colors) shown in chart. */
    data: DataPoint[];
    /** Allow user to click values in legend to show/hide them in chart */
    allowValueHiding: boolean;
    /** Show/hide legend */
    showLegend: boolean;
}
export interface DonutChartState {
    chartWidth: number;
    chartHeight: number;
    hiddenValueKeys: string[];
    hoverItem: undefined | string;
}
/**
 * This is just an early prototype. Not exported!
 *
 * Donut chart component, with interactive legend.
 *
 * **Notes:**
 * - you **must** provide 'key' prop for each value, to uniquely identify each value/label/color tuple, even if label would change suddenly
 * - this component does not assign colors to the sectors, thus you **must** provide color for each value
 */
export declare class DonutChart extends React.Component<DonutChartProps, DonutChartState> {
    static defaultProps: {
        allowValueHiding: boolean;
        showLegend: boolean;
    };
    readonly state: {
        chartWidth: number;
        chartHeight: number;
        hiddenValueKeys: string[];
        hoverItem: undefined;
    };
    private svgRef;
    private hoverDisabled;
    private reason;
    private previousValues;
    private firstUpdate;
    constructor(props: DonutChartProps);
    componentDidUpdate(): void;
    render(): JSX.Element;
    private arcTween;
    private _handleResize;
    private _handleClick;
    private _handleLegendRowClick;
    private _beginMouseOver;
    private _endMouseOver;
}
export default DonutChart;
