import * as React from 'react';
import { HtmlAttributes } from '../../internalUtils/HtmlAttributes';
export interface LineChartProps extends HtmlAttributes {
    /** Fired when user clicks the component. */
    onClick?: (event: React.MouseEvent<HTMLElement>) => void;
}
export interface LineChartState {
    some: number;
}
/**
 * This is just an early prototype. Not exported!
 * TODO: implement component
 * TODO: component interface documentation
 *
 * Line chart component, with interactive legend.
 */
export declare class LineChart extends React.Component<LineChartProps, LineChartState> {
    static defaultProps: {};
    readonly state: {
        some: number;
    };
    constructor(props: LineChartProps);
    render(): JSX.Element;
    private _handleClick;
}
export default LineChart;
