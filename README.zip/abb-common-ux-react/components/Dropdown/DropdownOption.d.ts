import * as React from 'react';
export interface DropdownOptionProps {
    /** The value as shown in the selection list. */
    label: string;
    /** Machine-readable value, possibly the same as 'label', but consider using more stable values, when from example the label is localized. */
    value: any;
    /** Dim the value in selection list and prevent its selection. */
    disabled?: boolean;
    /** Prevent any children. */
    children?: never;
}
/**
 * Represents a single selectable value in Dropdown selection list. Use only
 * under Dropdown or DropdownGroup.
 */
export declare class DropdownOption extends React.Component<DropdownOptionProps> {
    static defaultProps: {
        disabled: boolean;
    };
    static readonly componentName = "DropdownOption";
    constructor(props: DropdownOptionProps);
    render(): JSX.Element | null;
}
export default DropdownOption;
