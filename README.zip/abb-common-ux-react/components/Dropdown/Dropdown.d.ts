import * as React from 'react';
import { HtmlAttributes } from '../../internalUtils/HtmlAttributes';
export interface DropdownProps extends HtmlAttributes {
    /** Fired whenever user selection changes. Listen to this and feed the value back to 'value' prop (because this is a controlled component) */
    onChange?: (selection: Array<{
        value: any;
        label: string;
        isNew: boolean;
    }>) => void;
    /** Allow multiple values to be selected */
    multiselect?: boolean;
    /** Allow user to start typing, thus filtering the list interactively */
    searchable?: boolean;
    /** Dimmed help text in place of value, before user has selected any value. */
    placeholder?: string;
    /** Title text above the input field itself. */
    label?: string;
    /** Array of selected values. Always an array, to support both single- and multiselection modes with the same interface. Can ingest the value straight from "onChange" event handler. */
    value: Array<{
        value: any;
        label?: string;
        isNew?: boolean;
    }>;
    /** Additional help text below the input field itself. */
    description?: string;
    /** Show a cross icon on the right, clicking of which removes the selection. */
    clearable?: boolean;
    disabled?: boolean;
    /** Allow the user to add a new value outside the given list of options. When such a value is selected, the onChange handler is called with the parameter "isNew" set to true. */
    allowAdd?: boolean;
    sizeClass: 'small' | 'medium' | 'large';
    /** Show a small asterist before the label. When user has not selected anything, shows a red bottom border. */
    required?: boolean;
    /** Hide the input field borders, for dense layouts, such as in AppHeader (actually, the AppTopNaviDropdown just uses this component, with 'noBorders' set to true) */
    noBorders?: boolean;
    /** Clear the selected value when user hits Escape key on keyboard */
    clearOnEscape?: boolean;
    /** Show thin blue border around the input field, when this is true. Note, the component itself does not keep track of edited-status; you have to manage it in application code. */
    edited?: boolean;
    /** Allow only DropdownItems or DropdownGroups as children */
    /** Show green borders when the value is valid. Note, this in itself does not set the error state, but just customizes how the error state is shown. */
    showValidationBarWhenValid: boolean;
    /** Show green valid-icon when the value is valid. Note, this in itself does not set the error state, but just customizes how the error state is shown. */
    showValidationIconWhenValid: boolean;
    /** Show red borders when the value is invalid. Note, this in itself does not set the error state, but just customizes how the error state is shown. */
    showValidationBarWhenInvalid: boolean;
    /** Show red invalid-icon when the value is invalid. Note, this in itself does not set the error state, but just customizes how the error state is shown. */
    showValidationIconWhenInvalid: boolean;
    /**
     * Use this input to pass validation states to the dropdown.
     *
     * **Note**
     *
     * - This will take precedence over other validation mechanism, for example, required, so be sure to
     * pass the right values. For example, if the required flag is set to true, and a value is selected, then
     * it will still show error state if validationState.error still has value 'error'.
     *
     * - The input is controlled, so the application developer needs to take care of properly setting the state
     * according to the application use cases.
     */
    validationState: ValidationState | undefined | null;
}
/**
 * This interface can be used to pass validation state to the dropdown. The message field can contain any custom field
 * and the status can be either 'error' or 'ok'.
 */
export interface ValidationState {
    message?: string;
    valid: boolean;
}
/**
 * Dropdown, also known as Select component. Supports single/multi selection and new value addition.
 * Accepts only DropdownOption and DropdownGroup components as children.
 *
 * **Notes:**
 * - This component is **controlled**, meaning that you **must** implement the state handling in the parent component.
 * - When using Dropdown in AppHeader/AppTopNavi, use AppTopNaviDropdown component instead, as it has better suited style for that case (no borders or margins)
 * - Accepts only DropdownItems or DropdownGroups as children
 */
export declare class Dropdown extends React.Component<DropdownProps> {
    static defaultProps: {
        multiselect: boolean;
        searchable: boolean;
        placeholder: string;
        label: string;
        value: never[];
        description: string;
        clearable: boolean;
        disabled: boolean;
        allowAdd: boolean;
        sizeClass: string;
        required: boolean;
        noBorders: boolean;
        edited: boolean;
        clearOnEscape: boolean;
        showValidationBarWhenValid: boolean;
        showValidationIconWhenValid: boolean;
        showValidationBarWhenInvalid: boolean;
        showValidationIconWhenInvalid: boolean;
        validationState: undefined;
    };
    static DROPDOWN_COUNTER: number;
    readonly state: {
        isMenuOpen: boolean;
    };
    private groupName;
    private options;
    private styles;
    constructor(props: DropdownProps);
    componentDidMount(): void;
    componentDidUpdate(): void;
    render(): JSX.Element;
    private constructOptions;
    private showValidationMessageContainer;
    private _handleChange;
    private _handleMenuOpen;
    private _handleMenuClose;
    private getStyles;
}
export default Dropdown;
