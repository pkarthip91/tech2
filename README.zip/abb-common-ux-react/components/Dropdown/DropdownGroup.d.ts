import * as React from 'react';
export interface DropdownGroupProps {
    label: string;
}
/**
 * Show an unselectable section header in the list of dropdown options, for visual grouping of available values.
 * Use only as a direct child of Dropdopwn component, and provide only children of type DropdopwnOption to this component.
 *
 * **Notes:**
 * - Accepts only DropdownOption and DropdownGroup components as children
 */
export declare class DropdownGroup extends React.Component<DropdownGroupProps> {
    static readonly componentName = "DropdownGroup";
    constructor(props: DropdownGroupProps);
    render(): JSX.Element | null;
}
export default DropdownGroup;
