import * as React from 'react';
import { HtmlAttributes } from '../../internalUtils/HtmlAttributes';
export interface MessageDialogProps extends HtmlAttributes {
    /** Should the message dialog be opened on hover or click event on the trigger element */
    trigger?: 'click' | 'hover';
    message?: string;
    title?: string;
    /** Button configuration to show to user. Be sure to bind matching event handlers, or just the generic onExit handler, that returns the value as well */
    buttons: 'yesno' | 'yesnocancel' | 'ok' | 'okcancel' | 'confirmcancel' | 'close';
    onYes?: () => void;
    onNo?: () => void;
    onOk?: () => void;
    onCancel?: () => void;
    onConfirm?: () => void;
    onClose?: () => void;
    onExit?: (result: string) => void;
    /** Governs the open/close state of the dialog; required only when using programmatically. */
    isOpen?: boolean | undefined;
    /** Prevent any children. */
    children?: never;
    /** Changes the primary button type to black. */
    monochromeButtons: boolean;
}
/**
 * Helper wrapper component over Dialog, with predefined layout and button-configurations for simple message dialogs.
 * Used mostly in similar way as Dialog, but with simpler interface and less customization capabilities.
 *
 * **Notes:**
 *
 * - The functionality **will fail** if the trigger element (i.e. first child of WithMessageDialog) does not
 *   expose "onClick" or "onMouseOver" event, for "click" and "hover" triggers, respectively;
 *   as a workaround, just wrap your trigger in another div.
 */
export declare class MessageDialog extends React.Component<MessageDialogProps> {
    static defaultProps: {
        trigger: string;
        monochromeButtons: boolean;
        onYes: () => void;
        onNo: () => void;
        onOk: () => void;
        onCancel: () => void;
        onConfirm: () => void;
        onClose: () => void;
        onExit: () => void;
        isOpen: undefined;
    };
    static readonly componentName = "MessageDialog";
    private resourceCleaner;
    constructor(props: MessageDialogProps);
    render(): JSX.Element;
    onYes(): void;
    onNo(): void;
    onOk(): void;
    onCancel(): void;
    onConfirm(): void;
    onClose(): void;
    closeThroughCloseButton(): void;
    close(code: string | null): void;
    registerResourceCleaner(cleaner: () => void): void;
    private _defaultResult;
}
export default MessageDialog;
