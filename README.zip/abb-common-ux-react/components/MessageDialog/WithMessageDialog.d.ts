import * as React from 'react';
export interface WithMessageDialogProps {
    children: any;
}
export interface WithMessageDialogState {
    showDialog: boolean;
}
/**
 * Helper component to use MessageDialog decralatively. Accepts exactly two child elements. The first one
 * acts as the trigger element, clicking/hovering of which causes the dialog to open, whereas the second
 * child is the MessageDialog itself.
 *
 * **Notes:**
 * - This component does not take any props; all necessary props are defined in the MessageDialog component.
 */
export declare class WithMessageDialog extends React.Component<WithMessageDialogProps, WithMessageDialogState> {
    readonly state: {
        showDialog: boolean;
    };
    private content;
    private dialogCloseHandler?;
    private autoCloseTimer;
    private originalTriggerHandler;
    constructor(props: WithMessageDialogProps);
    registerCloseHandler(handler: () => void): void;
    closeDialog(): void;
    componentWillUnmount(): void;
    render(): JSX.Element;
    private _handleOpenDialog;
    private _onEscOrLostFocus;
    private _handleCloseDialog;
    private _onOpen;
    private _cleanResources;
}
export default WithMessageDialog;
