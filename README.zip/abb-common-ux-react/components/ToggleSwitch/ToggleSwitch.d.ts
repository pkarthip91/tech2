import * as React from 'react';
import { HtmlAttributes } from '../../internalUtils/HtmlAttributes';
export interface ToggleSwitchProps extends HtmlAttributes {
    /** Optional text shown on the right of the switch */
    label?: string;
    /** Current value of the switch. */
    value: boolean;
    disabled?: boolean;
    /** Fired when the user click the component. You **must** handle this and feed the value back to "value" prop, because this component is controlled by parent. */
    onChange?: (newState: boolean) => void;
    /** Show static enabled/disabled icons inside the switch */
    showIcons?: boolean;
    /** Prevent any children. */
    children?: never;
    /** Make switch black and white. */
    monochrome: boolean;
}
/**
 * **Notes:**
 * - This component is **controlled**, meaning that you **must** implement the state handling in the parent component.
 *
 * **Known issues:**
 * - Animation not working on IE, when using icons
 */
export declare class ToggleSwitch extends React.Component<ToggleSwitchProps> {
    static defaultProps: {
        label: string;
        disabled: boolean;
        showIcons: boolean;
        value: boolean;
        monochrome: boolean;
    };
    constructor(props: ToggleSwitchProps);
    render(): JSX.Element;
    private _handleChange;
}
export default ToggleSwitch;
