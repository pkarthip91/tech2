import * as React from 'react';
import { HtmlAttributes } from '../../internalUtils/HtmlAttributes';
export interface CloseIconProps extends HtmlAttributes {
    onClick?: (event: React.MouseEvent<HTMLElement>) => void;
    sizeClass: 'extra-small' | 'small' | 'medium' | 'large';
    disabled: boolean;
    /** Prevent any children. */
    children?: never;
}
/**
 * Re-usable wrapper for 'close' (large and medium size) or 'close-light' (small and extra-small size) icons.
 * Implements a background hover state and click-handling. Used internally for dialog, popup and banner
 * notification close buttons, tabcontrol close-tab button, and dropdown clear-value button.
 */
export declare class CloseIcon extends React.Component<CloseIconProps> {
    static defaultProps: {
        sizeClass: string;
        disabled: boolean;
    };
    constructor(props: CloseIconProps);
    render(): JSX.Element;
    private _handleClick;
}
export default CloseIcon;
