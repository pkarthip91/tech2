import * as React from 'react';
import { HtmlAttributes } from '../../internalUtils/HtmlAttributes';
export interface TooltipProps extends HtmlAttributes {
    triggerOnClick: boolean;
    lazyLoading: boolean;
    followCursor: boolean;
    disabled: boolean;
    /** Show delay, in milliseconds. */
    delayShow: number;
    /** Hide delay, in milliseconds. */
    delayHide: number;
    /** Fired when the user click the tooltip. */
    onClick?: (event: React.MouseEvent<HTMLElement>) => void;
}
/**
 * Typically used as a second child element of WithPopup component.
 */
export declare class Tooltip extends React.Component<TooltipProps> {
    static readonly componentName = "Tooltip";
    static defaultProps: {
        triggerOnClick: boolean;
        lazyLoading: boolean;
        followCursor: boolean;
        disabled: boolean;
        delayShow: number;
        delayHide: number;
    };
    constructor(props: TooltipProps);
    componentDidUpdate(prevProps: TooltipProps): void;
    render(): JSX.Element;
    private _handleClick;
}
export default Tooltip;
