import * as React from 'react';
export interface WithTooltipProps {
    children: any;
}
/**
 * Helper component to use Tooltip decralatively. Accepts exactly two child elements. The first one
 * acts as the trigger element, clicking/hovering of which causes the tooltip to open, whereas the second
 * child is the Tooltip itself.
 *
 * **Notes:**
 * - This component does not take any props; all necessary props are defined in the Tooltip component.
 */
export declare class WithTooltip extends React.Component<WithTooltipProps> {
    static idCounter: number;
    private id;
    private tooltipElement;
    private renderActualContent;
    private renderNothingOnce;
    constructor(props: WithTooltipProps);
    componentDidUpdate(): void;
    forceUpdate(): void;
    render(): JSX.Element | any;
    private _onOpen;
    private _getContent;
}
export default WithTooltip;
