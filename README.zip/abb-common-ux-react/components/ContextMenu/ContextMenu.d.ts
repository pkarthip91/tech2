import * as React from 'react';
import { HtmlAttributes } from '../../internalUtils/HtmlAttributes';
export interface ContextMenuProps extends HtmlAttributes {
    onClick?: (event: React.MouseEvent<HTMLElement>) => void;
    /** Prevent any children. */
    children?: never;
}
export interface ContextMenuState {
    some: number;
}
/** TODO: implement component */
/** TODO: component interface documentation */
export declare class ContextMenu extends React.Component<ContextMenuProps, ContextMenuState> {
    static defaultProps: {};
    readonly state: {
        some: number;
    };
    constructor(props: ContextMenuProps);
    render(): JSX.Element;
    private _handleClick;
}
export default ContextMenu;
