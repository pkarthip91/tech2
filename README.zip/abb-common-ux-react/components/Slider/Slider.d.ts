import * as React from 'react';
import { HtmlAttributes } from '../../internalUtils/HtmlAttributes';
export interface SliderProps extends HtmlAttributes {
    /** Title text above the slider */
    label?: string;
    /** Fired when the value changes. Note, this is fired multiple times during a drag event, and not only when the drag ends. For single slider only one value is provided, for double slider an array of two values is provided. */
    onChange?: (event: number | number[]) => void;
    type?: 'single' | 'double';
    /** Which part to highlight. Note, highlighting the outer parts in case of double slider is not supported. */
    highlight: 'none' | 'low' | 'middle' | 'high';
    /** Range minimun value */
    min: number;
    /** Instead of the min value itself, optionally show this string in place of min value label  */
    minLabel?: string;
    /** Range maximum value */
    max: number;
    /** Instead of the max value itself, optionally show this string in place of max value label  */
    maxLabel?: string;
    /** Step value between different selectable values when dragging the slider. */
    step?: number;
    /** The current value (for single slider). You **must** provide this (or "values") as prop, as the component is controlled. You can just feed the value from onChange event handler. */
    value?: number;
    /** The current values (for double slider). You **must** provide this (or "value") as prop, as the component is controlled. You can just feed the value from onChange event handler. */
    values?: number[];
    /** When should the tooltip be shown. Option 'active' shows it when hovered or dragged, and when it has focus. */
    showTooltip: 'always' | 'active' | 'never';
    /** Dim the slider and prevent any user actions. */
    disabled?: boolean;
    /** Tick marks shown on the bar. If provided as an array of values and optional text, only those will be shown. If provided as a single number, the value range is divided with tick-marks into that many segments. */
    ticks?: [{
        value: number;
        text?: string;
    }] | number;
    /** Make slider black and white. */
    monochrome: boolean;
    /** Prevent any children. */
    children?: never;
}
export interface SliderState {
    hovering: boolean[];
    focused: boolean[];
}
/**
 * Slider component with support for two separate values (i.e. double slider).
 *
 * **Notes:**
 * - This component is **controlled**, meaning that you **must** implement the state handling in the parent component.
 */
export declare class Slider extends React.Component<SliderProps, SliderState> {
    static defaultProps: {
        label: string;
        type: string;
        showTooltip: string;
        highlight: string;
        step: number;
        monochrome: boolean;
    };
    static contextType: React.Context<string>;
    readonly state: {
        hovering: boolean[];
        focused: boolean[];
    };
    private ref;
    constructor(props: SliderProps);
    private setHover;
    componentDidMount(): void;
    render(): JSX.Element;
    private handleKeyboard;
    private onAfterChange;
    private onBeforeChange;
    private onChange;
}
export default Slider;
