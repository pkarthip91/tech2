import * as React from 'react';
import { HtmlAttributes } from '../../internalUtils/HtmlAttributes';
export interface PaginationProps extends HtmlAttributes {
    /** Called when the user changes the page, either through number or back/forward buttons, or through the popup.
     * Since this component is controlled, you **must** change the currentPage in this handler, and provide the
     * new active page through "currentPage" prop.
     */
    onGotoPage?: (toPage: number) => void;
    /** Called when the user changes the page size (through the popup). This always also resets the page number to zero.
     * We cannot keep the same page number, because it might not exist anymore, and calculating a new page number from
     * the currently visible set of rows is unreliable.
     */
    onSetPageSize?: (size: number, newPage: number) => void;
    /** Show/hide the arrow buttons. */
    showPrevNext: boolean;
    /** Show/hide the page number buttons, and possible ellipsises between them. Only 7-9 number buttons will
     * be shown at most, and exceeding buttons will be automatically wrapped behind an ellipsis.
     */
    showNumberButtons: boolean;
    /** Show/hide the text showing current page, clicking of which opens up a popup for directly selecting any given page. */
    showPageSelectionInput: boolean;
    /** Row count is required, so that the pagination can count the number of pages. */
    rowCount: number;
    currentPage: number;
    currentPageSize: number;
    /** If provided, page size setting popup will be given to the user. */
    pageSizeOptions?: number[];
    /** TODO: implement disabling of all controls */
    disabled: boolean;
    /** Object containing values for all visible text elements in the pagination component, for localization. */
    texts: {
        Showing: string;
        RowsPerPage: string;
        Page: string;
        GoToPage: string;
    };
    /** Prevent any children. */
    children?: never;
}
export interface PaginationState {
    inputValue: number | undefined;
    pageSizePopupIsOpen: boolean;
    pagePopupIsOpen: boolean;
}
/**
 * Pagination component is used typically together with SimpleTable or Datagrid
 * components, but can used in other contexts as well.
 *
 * **Notes:**
 * - This component is **controlled**, meaning that you **must** implement the state handling in the parent component. This includes
 */
export declare class Pagination extends React.Component<PaginationProps, PaginationState> {
    static defaultProps: {
        rowCount: number;
        currentPage: number;
        currentPageSize: number;
        showPrevNext: boolean;
        showNumberButtons: boolean;
        showPageSelectionInput: boolean;
        showInput: boolean;
        disabled: boolean;
        texts: {
            Showing: string;
            RowsPerPage: string;
            Page: string;
            GoToPage: string;
        };
    };
    readonly state: {
        inputValue: undefined;
        pageSizePopupIsOpen: boolean;
        pagePopupIsOpen: boolean;
    };
    constructor(props: PaginationProps);
    render(): JSX.Element;
    private handlePageSizePopupInputKeyUp;
    private validatePageSizePopupInputValue;
    private handlePageSizePopupInputValueChange;
    private disablePageSizePopupGotoButton;
    private gotoSelectedPage;
    private gotoPrevPage;
    private gotoNextPage;
    private handlePageNumberClick;
    private handleFirstEllipsisClick;
    private handleSecondEllipsisClick;
    private handlePageSizeChange;
    private gotoPage;
}
export default Pagination;
