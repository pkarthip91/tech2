import * as React from 'react';
import { HtmlAttributes } from '../../internalUtils/HtmlAttributes';
export interface LogoProps extends HtmlAttributes {
    /** Logo component does not support theming via context, because it rarely works as expected. Instead, logo color must be always manually defined. */
    color: 'red' | 'light' | 'dark';
    /** Fired when the logo bounding box is clicked. */
    onClick?: (event: React.MouseEvent<HTMLElement>) => void;
    /** Prevent any children. */
    children?: never;
}
/**
 * Helper component to show the ABB logo.
 *
 * **Notes:**
 * - This component takes all available height/width, therefore you **must** specify the size yourself in application code by wrapping this component in another element and specifying the size of that
 * - Does not adhere to globally available current theme (via React context), but you **must** specify the color always manually (usually the opposite of the theme)
 */
export declare class Logo extends React.Component<LogoProps> {
    static defaultProps: {};
    constructor(props: LogoProps);
    render(): JSX.Element;
    private _handleClick;
}
export default Logo;
