import * as React from 'react';
import { HtmlAttributes } from '../../internalUtils/HtmlAttributes';
export interface HeadingProps extends HtmlAttributes {
    /** The heading text */
    text?: string;
    /** Fired when user clicks the component. */
    onClick?: (event: React.MouseEvent<HTMLElement>) => void;
    /** Directly corresponds to standard HTML heading levels (H1-H6)  */
    level: 1 | 2 | 3 | 4 | 5 | 6;
    /** Show or hide the red ABB cursor above the heading */
    showCursor: boolean;
    /** Replace red color cursor with black and white versions, depensing on the used theme. */
    blackAndWhite: boolean;
}
/**
 * Heading component quite directly translates to HTML standard H1-H6 elements,
 * with predefined styling.
 */
export declare class Heading extends React.Component<HeadingProps> {
    static defaultProps: {
        showCursor: boolean;
        blackAndWhite: boolean;
    };
    constructor(props: HeadingProps);
    render(): JSX.Element;
    private _handleClick;
}
export default Heading;
