import * as React from 'react';
import { HtmlAttributes } from '../../internalUtils/HtmlAttributes';
export interface FunctionalTemplateProps extends HtmlAttributes {
    /** Fired when user clicks the component. */
    onClick?: (event: React.MouseEvent<HTMLElement>) => void;
}
/**
 * Component template, to be used as a basis for creating a new component. Not exported.
 *
 * **Notes:**
 * - This component is **controlled**, meaning that you **must** implement the state handling in the parent component.
 * - **consider** ...
 *
 * **Known issues:**
 * - None
 */
export declare const FunctionalTemplate: (props: FunctionalTemplateProps) => JSX.Element;
export default FunctionalTemplate;
