import * as React from 'react';
import { HtmlAttributes } from '../../internalUtils/HtmlAttributes';
export interface TemplateProps extends HtmlAttributes {
    /** Fired when user clicks the component. */
    onClick?: (event: React.MouseEvent<HTMLElement>) => void;
}
export interface TemplateState {
    some: number;
}
/**
 * Component template, to be used as a basis for creating a new component. Not exported.
 *
 * **Notes:**
 * - This component is **controlled**, meaning that you **must** implement the state handling in the parent component.
 * - **consider** ...
 *
 * **Known issues:**
 * - None
 */
export declare class Template extends React.Component<TemplateProps, TemplateState> {
    static defaultProps: {};
    readonly state: {
        some: number;
    };
    constructor(props: TemplateProps);
    render(): JSX.Element;
    private _handleClick;
}
export default Template;
