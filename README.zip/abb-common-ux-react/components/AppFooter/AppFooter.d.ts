import * as React from 'react';
import { HtmlAttributes } from '../../internalUtils/HtmlAttributes';
export interface AppFooterProps extends HtmlAttributes {
    /** Custom copyright text, for localization purposes. */
    copyrightText?: string;
    /** Show/hide text: "All rights reserved {currentYear}" */
    showCopyright?: boolean;
    /** Show/hide ABB logo. */
    showLogo?: boolean;
}
/**
 * Mostly empty footer container. Includes builtin ABB-logo and standard
 * copyright text, which can be overridden.
 */
export declare class AppFooter extends React.Component<AppFooterProps> {
    static defaultProps: {
        copyrightText: string;
        showCopyright: boolean;
        showLogo: boolean;
    };
    constructor(props: AppFooterProps);
    render(): JSX.Element;
}
export default AppFooter;
