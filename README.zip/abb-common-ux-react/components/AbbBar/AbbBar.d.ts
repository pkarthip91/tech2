import * as React from 'react';
import { HtmlAttributes } from '../../internalUtils/HtmlAttributes';
export interface AbbBarProps extends HtmlAttributes {
    /** Replace the default red ABB logo with black or white ABB logo, on light and dark themes, respectively. */
    blackAndWhiteLogo: boolean;
    /** Replace the standard ABB logo with your custom product logo. */
    customLogo?: JSX.Element;
    productName?: string;
    onLogoClick?: (event: React.MouseEvent<HTMLElement>) => void;
}
/**
 * The iconic ABB top bar, always positioned as the first, full-width element on top of the page.
 *
 * **Notes:**
 * - Accepts only window system controls (i.e. min/max/restore/close buttons) as children.
 */
export declare class AbbBar extends React.Component<AbbBarProps> {
    static defaultProps: {
        blackAndWhiteLogo: boolean;
        productName: string;
    };
    constructor(props: AbbBarProps);
    render(): JSX.Element;
    private _handleLogoClick;
}
export default AbbBar;
