import * as React from 'react';
import { HtmlAttributes } from '../../internalUtils/HtmlAttributes';
export interface LinkProps extends HtmlAttributes {
    /** Optionally draw the standard link underline. It looks better without, but it's not so clearly seen as link. */
    underline?: boolean;
    /** Fired when the user clicks the link. By preventing default action, you can still prevent navigation from happening.  */
    onClick?: (event: React.MouseEvent<HTMLElement>) => void;
    /** Standard HTML link attribute. */
    download: boolean;
    /** Standard HTML link attribute. */
    href?: string;
    /** Standard HTML link attribute. */
    referrerPolicy?: 'no-referrer' | 'no-referrer-when-downgrade' | 'origin' | 'origin-when-cross-origin' | 'strict-origin-when-cross-origin' | 'unsafe-url';
    /** Standard HTML link attribute. */
    target?: '_self' | '_blank' | '_parent' | '_top';
    /** Standard HTML link attribute. */
    rel?: string;
}
/**
 * Thin wrapper for link tags (i.e. "a" tag), to provide styles for it.
 */
export declare class Link extends React.Component<LinkProps> {
    static defaultProps: {
        underline: boolean;
        download: boolean;
    };
    constructor(props: LinkProps);
    render(): JSX.Element;
    private _handleClick;
}
export default Link;
