import * as React from 'react';
import { HtmlAttributes } from '../../internalUtils/HtmlAttributes';
export interface GaugeProps extends HtmlAttributes {
    /** Show either big round gauge, or less vertical space consuming horizontal bar gauge. */
    type: 'radial' | 'bar';
    /** The primary value shown in Gauge. Values outside the min-max range are automatically normalized to that range. */
    value: number;
    /** Range minimum value. */
    min: number;
    /** Range maximum value. */
    max: number;
    /** Custom minimum value as string. If not given, "min" will be used by default. */
    minLabel?: string;
    /** Custom maximum value as string. If not given, "max" will be used by default. */
    maxLabel?: string;
    /** Show a warning indicator in this spot, and color the value bar with warning color (yellow), when the value is below this limit. */
    lowWarn?: number;
    /** Show a warning indicator in this spot, and color the value bar with alarm color (red), when the value is below this limit. */
    lowAlarm?: number;
    /** Show a warning indicator in this spot, and color the value bar with warning color (yellow), when the value is above this limit. */
    highWarn?: number;
    /** Show a warning indicator in this spot, and color the value bar with alarm color (red), when the value is above this limit. */
    highAlarm?: number;
    /** Two visual options to show the warning/alarm limit indicators. */
    limitStyle: 'parallel' | 'orthogonal';
    /** TODO: not implemented yet. Will indicate the target value with a small triangle below the bar. */
    setpoint?: number;
    /** Textual unit representation, such as "%", "kV" or "kWh", shown next to the value. */
    unit?: string;
    /** The name of the measured data point, e.g. Power, Energy or Oil level. Shown above the value. */
    label?: string;
    /** Number of decimals to show on the value. */
    decimals: number;
    /** Customize the bar color when it is between normal limits (i.e. not in warning/alarm range). Default: green. */
    color: string;
    /** Customize the bar color when it falls inside warning limits. Default: yellow.  */
    warnColor: string;
    /** Customize the bar color when it falls inside alarm limits. Default: red.  */
    alarmColor: string;
    /** Fired when any part of the Gauge is clicked. */
    onClick?: (event: React.MouseEvent<HTMLElement>) => void;
    /** Prevent any children. */
    children?: never;
}
export interface GaugeState {
    chartWidth: number;
    chartHeight: number;
}
/**
 * Gauge component with configurable alarm/warning limits. Two styles: bar (i.e. linear) and radial.
 */
export declare class Gauge extends React.Component<GaugeProps, GaugeState> {
    static defaultProps: {
        type: string;
        unit: string;
        label: string;
        decimals: number;
        limitStyle: string;
        color: string;
        warnColor: string;
        alarmColor: string;
    };
    readonly state: {
        chartWidth: number;
        chartHeight: number;
    };
    private readonly startAngle;
    private readonly endAngle;
    private readonly justOuterArc;
    private svgRef;
    private updateReason;
    private elements;
    constructor(props: GaugeProps);
    componentDidUpdate(prevProps: GaugeProps): void;
    render(): JSX.Element;
    private renderBar;
    private renderRadial;
    private reCreateAllElements;
    private updateAllElements;
    private _getForegroundColor;
    private _getXYForAngle;
    private _getAngleForValue;
    private _getWidthForValue;
    private _getFontSize;
    private _handleResize;
    private _handleClick;
}
export default Gauge;
