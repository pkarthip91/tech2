import * as React from 'react';
import { HtmlAttributes } from '../../internalUtils/HtmlAttributes';
export interface InputProps extends HtmlAttributes {
    /**
     * Most standard HTML input types, plus one extra: textarea. Passed directly to the underlying
     * HTML input type (except textarea, which changes the underlying HTML element from 'input' to 'textarea').
     * Affects the browser-specific editor (mostly relevant in mobile) and sets the validation state
     * if no custom validation function is given). All basic HTML input types are supported - minus those that either:
     *  - are explicitly handled by other components (button, checkbox, file, image, radio, range, submit), or
     *  - are too complex to handle with this component (file, image, submit), or
     *  - don't really make much sense in this context (note, reset)
     */
    dataType: 'color' | 'date' | 'email' | 'month' | 'number' | 'password' | 'search' | 'tel' | 'text' | 'textarea' | 'time' | 'url' | 'week';
    /** Show asterisk before the label and draw a red border around the input field when empty. */
    required?: boolean;
    /** Short help text above the input field */
    label?: string;
    /** Additional help text below the input field itself. */
    description?: string;
    /** Different visual styles. Currently two styles designed and implemented. */
    type: 'normal' | 'discreet';
    /** Fired when the component the user enters a new character (i.e. release keyboard key). */
    onValueChange?: (value: string) => void;
    /** Provide your custom validation function. Called whenever the value changes. Return either an error message (non-empty message indicates error), a boolean value (false indicates error, without a message), or an object containing both. */
    validator?: (value: null | undefined | string) => string | boolean | CustomValidationResult;
    /** Provide custom validation result totally asynchronously. Return either an error message (non-empty message indicates error), a boolean value (false indicates error, without a message), or an object containing both. Mostly same as 'validator' above, but the value is provided directly as a prop. Note: this makes the above 'validator' function prop mostly useless, and it will be removed at some point. */
    validationResult?: string | boolean | CustomValidationResult | null;
    /** Custom icon, shown on the right end of the input field */
    icon?: string;
    /** Slightly dimmed placeholder text. */
    placeholder?: null | string;
    /** Show green borders when the value is valid. Note, this in itself does not set the error state, but just customizes how the error state is shown. */
    showValidationBarWhenValid: boolean;
    /** Show green valid-icon when the value is valid. Note, this in itself does not set the error state, but just customizes how the error state is shown. */
    showValidationIconWhenValid: boolean;
    /** Show red borders when the value is invalid. Note, this in itself does not set the error state, but just customizes how the error state is shown. */
    showValidationBarWhenInvalid: boolean;
    /** Show red invalid-icon when the value is invalid. Note, this in itself does not set the error state, but just customizes how the error state is shown. */
    showValidationIconWhenInvalid: boolean;
    /** Dim the whole control and prevent input. */
    disabled?: boolean;
    /** The current value of the input field. Note, you **must** provide this, as the component is controlled. */
    value?: null | undefined | string;
    /** Additional, standard HTML input-element attributes passed to the input field. */
    inputAttributes?: {
        [index: string]: any;
    };
    /** Fore onValueChange-event with empty string when user hits Escape key on keyboard. */
    clearOnEscape?: boolean;
    /** Show the cross-icon on the right end of the input field (but before possible custom icon), clicking of which causes onValueChange-event to be fired with empty string. */
    showClearIcon?: boolean;
    /** When true, show blue border around the input field. Note, the component does not keep track of changed status, and this merely draws the border. Keep track of value changes in application code. Also, this is not applicable to 'textarea'. */
    indicateChanged?: boolean;
    /** Run the validation always after the user enter a new character (i.e. release keyboard key). If false, run the validation only when the element loses focus. */
    instantValidation?: boolean;
    /** Allow user resize the element. Only valid for textarea. */
    resizable: boolean;
    /** If given, the input field stops accepting characters after this limit is reached. Note: the field *will* show more characters than the limit, if those are coming from outside the component. */
    maxLength?: number;
    /**
     * Custom keyboard handler to act on specific keys (most probably on Escape or Return).
     * Return false to cancel all further event handling, including the component internal handlers.
     * @param {KeyboardEvent} key The original keyboard event.
     */
    onKeyUp?: (key: React.KeyboardEvent<HTMLInputElement | HTMLTextAreaElement>) => void;
    /** Separate click handler for the icon. Useful for example in search fields, where the icon could be a magnifier and clicking it causes the search to be performed. */
    onIconClick?: (text: null | undefined | string) => void;
    /** Fired when the inner input/textarea -element receives focus. */
    onGotFocus?: (e: React.FocusEvent<HTMLInputElement> | React.FocusEvent<HTMLTextAreaElement>) => void;
    /** Fired when the inner input/textarea -element loses focus (i.e. blurs). */
    onLostFocus?: (e: React.FocusEvent<HTMLInputElement> | React.FocusEvent<HTMLTextAreaElement>) => void;
    /** Prevent any children. */
    children?: never;
}
export interface InputState {
    focused: boolean;
}
export interface CustomValidationResult {
    valid: boolean;
    text?: string;
}
/**
 * Generic value input component, building on top of the standard HTML input-element. Supports various value validation
 * mechanisms (instant validation, on-lost-focus-validation) and different visual cues to signal the state of the input
 * to the user, such as is-required (red bottom border when empty), has-changed (blue border), etc. Validation mechanism
 * can also be customized with custom message and to either show/hide the icon plus possibly empty message, and the red
 * overall border when in invalid state. Can be cleared through icon-click or via keyboard.
 *
 * **Notes:**
 * - Component interface is quite large and complicated, due to supporting multiple styles and validation modes.
 * - This component is **controlled**, meaning that you **must** implement the state handling in the parent component.
 */
export declare class Input extends React.Component<InputProps, InputState> {
    static defaultProps: {
        required: boolean;
        type: string;
        disabled: boolean;
        icon: string;
        placeholder: null;
        showValidationBarWhenValid: boolean;
        showValidationIconWhenValid: boolean;
        showValidationBarWhenInvalid: boolean;
        showValidationIconWhenInvalid: boolean;
        value: null;
        inputAttributes: {};
        clearOnEscape: boolean;
        showClearIcon: boolean;
        indicateChanged: boolean;
        instantValidation: boolean;
        resizable: boolean;
    };
    readonly state: {
        focused: boolean;
    };
    private inputRef;
    constructor(props: InputProps);
    focus(): void;
    render(): JSX.Element;
    private _validate;
    private _handleValueChange;
    private _handleKeyPress;
    private _handleClearIconClick;
    private clearValue;
    private _handleIconClick;
    private _handleFocus;
    private _handleBlur;
}
export default Input;
