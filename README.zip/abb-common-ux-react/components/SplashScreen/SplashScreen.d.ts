import * as React from 'react';
import { HtmlAttributes } from '../../internalUtils/HtmlAttributes';
export interface SplashScreenProps extends HtmlAttributes {
    /** The biggest title in the page. Show the product name here. */
    productName: string;
    /** The second biggest title in the page, immediately below the product name. This can be used to denote e.g. the customer or site name. */
    productSubName?: string;
    /** The product name plus version, shown in small font, on top of the dialog. */
    productFullName?: string;
    /** Static text on the bottom of the screen. Useful for regulatory texts and privacy notices. */
    footerText?: string;
    /** Value between 0-100 showing the loading progress on top of the screen. */
    progress?: number;
    /** Defaults to: "'All rights reserved {currentYear}" */
    copyrightText?: string;
    /** Prevent any children. */
    children?: never;
}
/**
 * Splash screen contains a nice background, product name and version,
 * and some additional information depending on the product. Visual design
 * is almost identical to the loading-state of Login-screen.
 *
 * **Notes:**
 * - If you want provide smooth transition from Splash screen to login form, use LoginScreen component instead, with its loading-state.
 */
export declare class SplashScreen extends React.Component<SplashScreenProps> {
    static defaultProps: {
        productFullName: string;
        progress: number;
        copyrightText: string;
    };
    constructor(props: SplashScreenProps);
    render(): JSX.Element;
}
export default SplashScreen;
