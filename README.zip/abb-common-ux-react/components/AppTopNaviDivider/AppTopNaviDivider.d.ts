import * as React from 'react';
import { HtmlAttributes } from '../../internalUtils/HtmlAttributes';
export interface AppTopNaviDividerProps extends HtmlAttributes {
    /** Prevent any children. */
    children?: never;
}
/** Small vertical divider bar, for visually separating adjacent AppTopNaviItem components. */
export declare class AppTopNaviDivider extends React.Component<AppTopNaviDividerProps> {
    constructor(props: AppTopNaviDividerProps);
    render(): JSX.Element;
}
export default AppTopNaviDivider;
