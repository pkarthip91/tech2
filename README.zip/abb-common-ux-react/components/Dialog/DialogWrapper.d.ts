import * as React from 'react';
import { HtmlAttributes } from '../../internalUtils/HtmlAttributes';
import { Dialog } from './Dialog';
import { MessageDialog } from '../MessageDialog';
export interface DialogWrapperProps extends HtmlAttributes {
    contentClassName?: string;
    containerClassName?: string;
    trigger?: 'click' | 'hover';
    showCloseButton?: boolean;
    closeOnEscape?: boolean;
    closeOnLostFocus?: boolean;
    dimBackground?: boolean;
    hideBackground?: boolean;
    disableDefaultStyle?: boolean;
    title?: string | null;
    onOpen?: (() => void) | null;
    onClose?: (() => void) | null;
    closeAfter?: number;
    render?: any;
    isOpen?: boolean | undefined;
    closeHandler?: any;
    dialog: Dialog | MessageDialog;
}
/** Internally used component, not exported. */
export declare class DialogWrapper extends React.Component<DialogWrapperProps> {
    private closeAction;
    private autoCloseTimer;
    constructor(props: DialogWrapperProps);
    componentWillUnmount(): void;
    render(): JSX.Element | null;
    private _handleCloseDialog;
    private _cleanOnClose;
    private _onOpen;
    private _onCloseClick;
}
export default DialogWrapper;
