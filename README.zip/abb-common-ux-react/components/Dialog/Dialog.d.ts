import * as React from 'react';
import { HtmlAttributes } from '../../internalUtils/HtmlAttributes';
export interface DialogProps extends HtmlAttributes {
    /** Custom CSS class applied to the dialog inner content area */
    contentClassName?: string;
    /** Custom CSS class applied to the dialog outer container element */
    containerClassName?: string;
    /** Should the dialog be opened on hover or click event on the trigger element */
    trigger?: 'click' | 'hover';
    /** Show close icon on top right corner */
    showCloseButton?: boolean;
    /** Can the user close the dialog by hitting Escape key on keyboard */
    closeOnEscape?: boolean;
    /** Close the dialog when user clicks somewhere outside of it */
    closeOnLostFocus?: boolean;
    /** Should the rest of the application be slightly dimmed (and disabled). Also called backdrop. */
    dimBackground?: boolean;
    /** Full opacity backdrop; hide the rest of the application completely while the dialog is open */
    hideBackground?: boolean;
    /** Do not apply default dialog styling; useful for customized dialogs like login screen. */
    disableDefaultStyle?: boolean;
    title?: string | null;
    onOpen?: (() => void) | null;
    onClose?: (() => void) | null;
    /** Timeout, in milliseconds, after which the dialog automatically closes. */
    closeAfter?: number;
    /** Render prop. Dialog content can be given as children, or as render prop. The advantage of render prop is that the dialog content receives a pointer to the dialog object itself, and can e.g. close it from within. */
    render?: any;
    /** Governs the open/close state of the dialog; required only when using programmatically. */
    isOpen?: boolean | undefined;
    /** An array of action buttons placed on bottom-right corner of the dialog. */
    standardButtonsOnBottom?: Array<{
        text?: string;
        icon?: string;
        type: 'primary-blue' | 'primary-black' | 'discreet-blue' | 'discreet-black' | 'normal';
        handler: (dlg: Dialog) => void;
    }>;
    /** If this is defined, the dialog becomes "complex", meaning that the primary action buttons (i.e. these buttons) are placed on top of the dialog, next to the title, and content area is separated from the top with a horizontal ruler. */
    standardButtonsOnTop?: Array<{
        text?: string;
        icon?: string;
        type: 'primary-blue' | 'primary-black' | 'discreet-blue' | 'discreet-black' | 'normal';
        handler: (dlg: Dialog) => void;
    }>;
    /** Fired whenever any part of the dialog is clicked (unless the click event is handled by some control earlier and propagation is prevented).  */
    onClick?: (event: React.MouseEvent<HTMLDivElement>) => void;
}
/**
 * Modal dialog implementation. Can be used declaratively as a child of WithDialog component, or programmatically.
 * For simple message dialogs with predefined and button configurations, check out MessageDialog component.
 *
 * **Notes:**
 *
 * - The functionality **will fail** if the trigger element (i.e. first child of WithDialog) does not
 *   expose "onClick" or "onMouseOver" event, for "click" and "hover" triggers, respectively;
 *   as a workaround, just wrap your trigger in another div.
 */
export declare class Dialog extends React.Component<DialogProps> {
    static defaultProps: {
        contentClassName: string;
        containerClassName: string;
        trigger: string;
        showCloseButton: boolean;
        closeOnEscape: boolean;
        closeOnLostFocus: boolean;
        dimBackground: boolean;
        hideBackground: boolean;
        disableDefaultStyle: boolean;
        title: null;
        onOpen: null;
        onClose: null;
        closeAfter: number;
        render: null;
        isOpen: undefined;
    };
    static readonly componentName = "Dialog";
    private resourceCleaner;
    constructor(props: DialogProps);
    render(): JSX.Element;
    close(): void;
    registerResourceCleaner(cleaner: () => void): void;
    private _handleClick;
}
export default Dialog;
