import * as React from 'react';
export interface WithDialogProps {
    children: any;
}
export interface WithDialogState {
    showDialog: boolean;
}
/**
 * Helper component to use Dialog decralatively. Accepts exactly two child elements. The first one
 * acts as the trigger element, clicking/hovering of which causes the dialog to open, whereas the second
 * child is the Dialog itself.
 *
 * **Notes:**
 * - This component does not take any props; all necessary props are defined in the Dialog component.
 */
export declare class WithDialog extends React.Component<WithDialogProps, WithDialogState> {
    readonly state: {
        showDialog: boolean;
    };
    private closeAction;
    private content;
    private autoCloseTimer;
    private originalTriggerHandler;
    constructor(props: WithDialogProps);
    closeDialog(): void;
    componentWillUnmount(): void;
    render(): JSX.Element;
    private _handleOpenDialog;
    private _handleCloseDialog;
    private _cleanOnClose;
    private _onOpen;
    private _onCloseClick;
}
export default WithDialog;
