import * as React from 'react';
import { HtmlAttributes } from '../../internalUtils/HtmlAttributes';
export interface LoginScreenProps extends HtmlAttributes {
    /** The biggest title in the page. Show the product name here. */
    productName: string;
    /** The second biggest title in the page, immediately below the product name. This can be used to denote e.g. the customer or site name. */
    productSubName?: string;
    /** The product name plus version, shown in small font, on top of the dialog. */
    productFullName?: string;
    onLogin?: (username: string | undefined, password: string | undefined, rememberMe: boolean) => void;
    loginButtonText?: string;
    usernameLabelText?: string;
    passwordLabelText?: string;
    rememberMeText?: string;
    /** Place whatever React components here. These are rendered above the standard fields.
     * For complex setups, consider setting 'showDefaultFields' to false, and implement them by hand via this prop.
     */
    customContent?: any;
    /** When true, all login fields are hidden, and only the product name and sub-name are shown. When set to false, the interactive login fields are animated to be visible. */
    loading?: boolean;
    /** [DEPRECATED: this prop will be removed, use children instead]. Static text on the bottom of the screen. Useful for regulatory texts and privacy notices.  */
    footerText?: string;
    /** If true, hide standard input controls (username, password, remember-me) */
    showDefaultFields?: boolean;
    /** Inject your custom buttons here, in the same line as standard login-button. Use 'primary' for only one button. */
    customButtons?: Array<{
        text: string;
        primary?: boolean;
        handler: (values: {
            username: string;
            password: string;
            rememberMe: boolean;
        }) => void;
    }>;
    showLoginButton?: boolean;
    /** Custom copyright text */
    copyrightText?: string;
}
export interface LoginScreenState {
    username: string;
    password: string;
    rememberMe: boolean;
}
/**
 * Login dialog is purely visual component, and it **does not** implement any business logic whatsoever regarding the authentication.
 * All texts and controls are controllable or replaceable, for localization and customization.
 * Anything provided as children will be rendered in the footer area. Reserve this for regulatory texts and links to privacy information, etc.
 *
 * **Notes:**
 * - You **must** implement all business logic and backend communication in the application.
 * - This component only renders the content and not the dialog container, thus you **must** wrap the LoginScreen into a modal dialog in the application.
 */
export declare class LoginScreen extends React.Component<LoginScreenProps, LoginScreenState> {
    static defaultProps: {
        loading: boolean;
        customButtons: never[];
        showDefaultFields: boolean;
        showLoginButton: boolean;
        usernameLabelText: string;
        passwordLabelText: string;
        loginButtonText: string;
        rememberMeText: string;
        copyrightText: string;
    };
    readonly state: {
        rememberMe: boolean;
        username: string;
        password: string;
    };
    constructor(props: LoginScreenProps);
    render(): JSX.Element;
    private _setUsername;
    private _setPassword;
    private _toggleRememberMe;
    private _handleLogin;
}
export default LoginScreen;
