import * as React from 'react';
import { HtmlAttributes } from '../../internalUtils/HtmlAttributes';
import { ThreeStateValue } from '../Checkbox';
export interface CollapsibleProps extends HtmlAttributes {
    /** Text shown in the header. */
    title: string;
    /** Optional id-string for easier component matching on user selection. */
    itemId?: string;
    icon?: string;
    /** Show a small vertical bar in item header; none for normal state, orange for warning and red for alarm. */
    alarmState?: 'normal' | 'warning' | 'alarm';
    onClick?: (id: string, evt: React.MouseEvent<HTMLElement> | React.KeyboardEvent) => void;
    /** Force-expand all child Collapsibles. Useful together with filtering functionality. In most cases should just pass-through from parent to all children, to implement proper whole-tree expansion functionality */
    expandAll: boolean;
    /** Force-collapse all child Collapsibles. Useful for quickly minimizing the whole hierarchy. In most cases should just pass-through from parent to all children, to implement proper whole-tree collapsion functionality */
    collapseAll: boolean;
    /** If this is defined (i.e. something else than undefined), a checkbox will be rendered before the title. */
    checked?: boolean | ThreeStateValue;
    /** Checkbox value is controlled, so you *must* listen to this and set the checkbox value accordingly */
    onClickCheckbox?: () => void;
    /** Allow only other, nested Collapsibles as children. */
    /**
     * Internal implementation detail - do not use.
     * @ignore
     */
    _fromParent_?: {
        filter: string | undefined;
        filterResults: any;
        hideFiltered: boolean;
        onComponentClick: (clicked: Collapsible, parents: Collapsible[]) => void;
        selected: Collapsible | Collapsible[];
        depth: number;
        expanderOnRight: boolean;
        treeContainsIcon: boolean;
        treeContainsCheckbox: boolean;
        monochrome: boolean;
    };
}
/**
 * A single Collapsible element, constituting of header and an array of child Collapsibles. Supports unlimited amount
 * of nested Collapsibles, but bear in mind that the UX easily drops drastically after a few levels.
 *
 * **Notes:**
 * - You **must** use CollapsibleContainer component as the parent for a hierarchy of Collapsible components.
 * - Accepts only nested Collapsibles as children.
 */
export declare class Collapsible extends React.Component<CollapsibleProps> {
    static defaultProps: {
        alarmState: string;
        expandAll: boolean;
        collapseAll: boolean;
    };
    static readonly componentName = "Collapsible";
    constructor(props: CollapsibleProps);
    render(): JSX.Element | null;
    private onChildComponentClick;
    private handleClick;
    private onCheckboxClick;
}
export default Collapsible;
