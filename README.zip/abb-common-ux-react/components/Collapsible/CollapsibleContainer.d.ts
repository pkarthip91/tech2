import * as React from 'react';
import { HtmlAttributes } from '../../internalUtils/HtmlAttributes';
import { Collapsible } from './Collapsible';
export interface CollapsibleContainerProps extends HtmlAttributes {
    /** Hide or dim items that do not match the filter string */
    filter?: string;
    /** Filtering has two visual modes; the filtered-out items are either dimmed or hidden completely. */
    hideFiltered?: boolean;
    /** Force-expand all child Collapsibles. Useful together with filtering functionality. */
    expandAll?: boolean;
    /** Force-collapse all child Collapsibles. Useful for quickly minimizing the whole hierarchy. */
    collapseAll?: boolean;
    /** Either show the clickable expansion on the left as rotating caret/chevron or on the right as plus/minus. This is purely visual difference. */
    expanderOnRight?: boolean;
    /** Collapsible component(s) that will be marked as selected. */
    selectedCollapsible?: Collapsible | Collapsible[] | undefined;
    /** Fired when the user clicks some Collapsible component header in the hierarchy. The full parent tree is given as an attribute for easier item recognition. */
    onItemClick?: (clicked: Collapsible, parents: Collapsible[]) => void;
    /** Allow only Collapsibles as children. */
    /** Changes child elements to black and white, including optional checkboxes.  */
    monochrome: boolean;
}
/**
 * Container and manager component for a number of Collapsible components.
 *
 * **Notes:**
 * - You **must** use this component as the parent for a hierarchy of Collapsible components.
 * - This component is **controlled**, meaning that you **must** implement the state handling in the parent component.
 * - Accepts only Collapsibles as children.
 */
export interface CollapsibleContainerState {
    filtered: boolean;
}
/** TODO: component description */
export declare class CollapsibleContainer extends React.Component<CollapsibleContainerProps, CollapsibleContainerState> {
    static defaultProps: {
        filter: string;
        hideFiltered: boolean;
        expandAll: boolean;
        collapseAll: boolean;
        selectedCollapsible: undefined;
        monochrome: boolean;
    };
    readonly state: {
        filtered: boolean;
    };
    private rootRef;
    constructor(props: CollapsibleContainerProps);
    render(): JSX.Element;
    private onComponentClick;
}
export default CollapsibleContainer;
