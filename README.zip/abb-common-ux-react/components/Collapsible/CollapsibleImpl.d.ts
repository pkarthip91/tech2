import * as React from 'react';
import { HtmlAttributes } from '../../internalUtils/HtmlAttributes';
import { ThreeStateValue } from '../Checkbox';
/**
 * This is quite a straight port to Typescript from ES6-based 3rd party library
 * https://github.com/glennflanagan/react-collapsible.
 * Differences to original:
 *   - implemented fully in Typescript, whereas the original is ES6
 *   - changed (deprecated) string-based refs to createRef API
 *   - minor type fixes and null-checks here and there
 */
export interface CollapsibleImplProps extends HtmlAttributes {
    extraClasses: string;
    transitionTime: number;
    transitionCloseTime: number;
    triggerTagName: string;
    easing: string;
    open: boolean;
    isSelected: boolean;
    selectedClassName: string;
    classParentString: string;
    openedClassName: string;
    triggerClassName: string;
    triggerOpenedClassName: string;
    contentOuterClassName: string;
    contentInnerClassName: string;
    hasChildrenClassName: string;
    accordionPosition?: string | number;
    handleTriggerClick?: (id: string | number | undefined, evt: React.MouseEvent<HTMLElement> | React.KeyboardEvent) => void;
    onOpen: () => void;
    onClose: () => void;
    onOpening: () => void;
    onClosing: () => void;
    trigger: string | HTMLElement;
    triggerWhenOpen?: string | HTMLElement;
    triggerDisabled: boolean;
    lazyRender: boolean;
    overflowWhenOpen: 'hidden' | 'visible' | 'auto' | 'scroll' | 'inherit' | 'initial' | 'unset';
    triggerSibling: HTMLElement | JSX.Element | (() => void);
    triggerIcon: HTMLElement | JSX.Element | (() => void);
    checked?: boolean | ThreeStateValue;
    leaveSpaceForCheckbox: boolean;
    handleCheckboxClick?: (id: string | number | undefined) => void;
    tabIndex?: number;
    monochrome?: boolean;
}
export interface CollapsibleImplState {
    isClosed: boolean;
    shouldSwitchAutoOnNextCycle: boolean;
    height: string | number;
    transition: string;
    hasBeenOpened: boolean;
    overflow: 'hidden' | 'visible' | 'auto' | 'scroll' | 'inherit' | 'initial' | 'unset';
    inTransition: boolean;
    shouldOpenOnNextCycle: boolean;
}
/** This is internal component used by Collapsible component. Do not use it directly in application. */
export declare class CollapsibleImpl extends React.Component<CollapsibleImplProps, CollapsibleImplState> {
    static defaultProps: {
        extraClasses: string;
        transitionTime: number;
        transitionCloseTime: undefined;
        triggerTagName: string;
        easing: string;
        open: boolean;
        classParentString: string;
        triggerDisabled: boolean;
        lazyRender: boolean;
        overflowWhenOpen: string;
        openedClassName: string;
        selectedClassName: string;
        triggerClassName: string;
        triggerOpenedClassName: string;
        contentOuterClassName: string;
        contentInnerClassName: string;
        hasChildrenClassName: string;
        triggerSibling: undefined;
        triggerIcon: undefined;
        onOpen: () => void;
        onClose: () => void;
        onOpening: () => void;
        onClosing: () => void;
        tabIndex: undefined;
        leaveSpaceForCheckbox: boolean;
        monochrome: boolean;
    };
    readonly state: {
        isClosed: boolean;
        shouldSwitchAutoOnNextCycle: boolean;
        height: React.ReactText;
        transition: string;
        hasBeenOpened: boolean;
        overflow: "scroll" | "inherit" | "initial" | "unset" | "auto" | "visible" | "hidden";
        inTransition: boolean;
        shouldOpenOnNextCycle: boolean;
    };
    private elRefs;
    constructor(props: CollapsibleImplProps);
    componentDidUpdate(prevProps: Readonly<CollapsibleImplProps>, prevState: Readonly<CollapsibleImplState>): void;
    private closeCollapsible;
    private openCollapsible;
    private continueOpenCollapsible;
    private handleTriggerClick;
    private handleCheckboxClick;
    private renderTriggerIcon;
    private renderNonClickableTriggerElement;
    private handleTransitionEnd;
    private filterMatchesRecursively;
    render(): JSX.Element;
}
export default CollapsibleImpl;
