import * as React from 'react';
import { HtmlAttributes } from '../../internalUtils/HtmlAttributes';
export declare type CardContainerProps = HtmlAttributes;
/**
 * Simple container component, for Cards. Inject CardContainerColumns as
 * direct children of this component, and Cards as direct children of those
 * columns.
 *
 * **Notes:**
 * - This component is likely to be changed in the near future to more featureful.
 * - Accepts only CardContainerColumns as children.
 */
export declare class CardContainer extends React.Component<CardContainerProps> {
    static defaultProps: {};
    constructor(props: CardContainerProps);
    render(): JSX.Element;
}
export default CardContainer;
