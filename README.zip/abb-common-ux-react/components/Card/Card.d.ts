import * as React from 'react';
import { HtmlAttributes } from '../../internalUtils/HtmlAttributes';
export interface CardProps extends HtmlAttributes {
    title: string;
    contentClass?: string;
    /** HTML standard attribute. Custom styles applied to component inner container element.  */
    contentStyle?: React.CSSProperties;
}
/**
 * Simple, static container component with title and content area. Used as child of CardContainerColumn.
 * Children are rendered as-is into content area.
 *
 * **Notes:**
 * - This component is likely to be changed in the near future to more featureful.
 */
export declare class Card extends React.Component<CardProps> {
    constructor(props: CardProps);
    render(): JSX.Element;
}
export default Card;
