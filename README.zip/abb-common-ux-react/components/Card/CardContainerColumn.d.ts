import * as React from 'react';
import { HtmlAttributes } from '../../internalUtils/HtmlAttributes';
export declare type CardContainerColumnProps = HtmlAttributes;
/**
 * Simple, full height column component, to be used as container for Card components, as a direct child of CardContainer component.
 *
 * **Notes:**
 * - This component is likely to be changed in the near future to more featureful.
 * - Accepts only Cards as children.
 */
export declare class CardContainerColumn extends React.Component<CardContainerColumnProps> {
    constructor(props: CardContainerColumnProps);
    render(): JSX.Element;
}
export default CardContainerColumn;
