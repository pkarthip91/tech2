import * as React from 'react';
import { HtmlAttributes } from '../../internalUtils/HtmlAttributes';
export interface ChartData {
    label: string;
    values: {
        [key: string]: number;
    };
}
export interface ChartField {
    id: string;
    title: string;
    color?: string;
    disabled?: boolean;
}
export interface ThresholdLine {
    /** Controls the line color, with alarm, warning and normal corresponding to red, yellow and black colors, respectively. Defaults to normal. */
    type?: 'warning' | 'alarm' | 'normal';
    /** Custom color for the line. This will override any color set by 'type' field above.  */
    color?: string;
    /** Required. At which point the line is drawn. */
    value: number;
}
export interface BarChartProps extends HtmlAttributes {
    /** Direction of the bars, defaulting to vertical. */
    mode: 'horizontal' | 'vertical';
    /** Data to be shown. Must comply with the field definitions.  */
    data: ChartData[];
    /** Dataset field definitions */
    fields: ChartField[];
    /** Optional helper lines to indicate e.g. warning limits or average.  */
    thresholds?: ThresholdLine[];
    /** Optional title of the chart. */
    title?: string;
    /** Label for X-axis. */
    xAxisLabel?: string;
    /** Label for Y-axis. */
    yAxisLabel?: string;
    /** Legend will not be shown when false. */
    showLegend: boolean;
    /** Maximum value. If not given, the highest value in the dataset is used. */
    max?: number;
    /** Minimum value. */
    min: number;
    /** Fired when user clicks the component (outside any interactive element). */
    onClick?: (event: React.MouseEvent<HTMLElement>) => void;
}
export interface BarChartState {
    hoveringOn: string | undefined;
    disabledFields: string[];
    chartHeight: number;
    chartWidth: number;
}
/**
 * Bar chart component, with interactive legend.
 */
export declare class BarChart extends React.Component<BarChartProps, BarChartState> {
    static defaultProps: {
        mode: string;
        min: number;
        showLegend: boolean;
        showLabels: boolean;
    };
    readonly state: {
        hoveringOn: undefined;
        disabledFields: string[];
        chartHeight: number;
        chartWidth: number;
    };
    private svgRef;
    private elements;
    private yAxisTickWidth;
    constructor(props: BarChartProps);
    componentDidUpdate(): void;
    render(): JSX.Element;
    private drawChart;
    private calculateMaxValue;
    private createScales;
    private drawAxisLabels;
    private drawYAxis;
    private drawXAxis;
    private drawBars;
    private drawThresholdLines;
    private clamp;
    private isHorizontal;
    private calculateYAxisLabelsMaxWidth;
    private handleResize;
    private toggleDisabled;
    private hoverStateOnMouseEnter;
    private hoverStateOnMouseLeave;
    private handleClick;
}
export default BarChart;
