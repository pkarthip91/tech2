import * as React from 'react';
import { HtmlAttributes } from '../../internalUtils/HtmlAttributes';
export interface StepperProps extends HtmlAttributes {
    /** Dim the whole component and prevent any user actions */
    disabled?: boolean;
    /** Step increment value, when plus/minus is pressed */
    step?: number;
    /** The current value of the component. Note: you **must** provide this as the component is controlled. */
    value: number;
    /** Should the value be shown between the plus/minus buttons, or just the buttons. */
    showValue?: boolean;
    /** Should direct number value editing be allowed */
    allowInputEdit: boolean;
    onMinusClick?: (event: React.MouseEvent<HTMLButtonElement>) => void;
    onPlusClick?: (event: React.MouseEvent<HTMLButtonElement>) => void;
    /** Fired whenever the value is change either through plus/minus buttons or directly editing the input box. */
    onChange?: (event: React.MouseEvent<HTMLInputElement>) => void;
    /** Prevent any children. */
    children?: never;
}
/**
 * This is just an early prototype. Not exported!
 * TODO: implement component
 * TODO: component interface documentation
 *
 * Stepper component, used to display a numeric value together with plus/minus buttons
 * for increasing/decresing the value one step at a time.
 *
 * **Notes:**
 * - This component is **controlled**, meaning that you **must** implement the state handling in the parent component.
 */
export declare class Stepper extends React.Component<StepperProps> {
    static defaultProps: {
        showValue: boolean;
        allowInputEdit: boolean;
    };
    constructor(props: StepperProps);
    render(): JSX.Element;
    private _handleMinusClick;
    private _handlePlusClick;
    private _handleChange;
}
export default Stepper;
