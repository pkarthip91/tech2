import * as React from 'react';
import { HtmlAttributes } from '../../internalUtils/HtmlAttributes';
export interface AppTopNaviDropdownProps extends HtmlAttributes {
    /** Fired when user makes a selection from the list */
    onChange?: (selection: Array<{
        value: any;
        label: string;
        isNew: boolean;
    }>) => void;
    /** Controls whether user can start typing in the field, to filter values. */
    searchable?: boolean;
    placeholder?: string;
    /** Selected value. Accepts exactly the same type of objects, as the onChange emits (i.e. you can easily bind them together)  */
    value?: Array<{
        value: any;
        label?: string;
        isNew?: boolean;
    }>;
    /** Whether user can de-select the value. */
    clearable?: boolean;
    disabled?: boolean;
    /** Should keyboard Escape-key press clear the selection. */
    clearOnEscape?: boolean;
}
/**
 * Used as a direct child of AppTopNavi, in similar manner as AppTopNaviItem. Works mostly the same way
 * as ordinary Dropdown-component (is built on top of that), but defaults to a dense style (no borders or margins).
 *
 * Use DropdownOption (plus DropdownGroup) components to populate the option list.
 *
 * **Notes:**
 * - This component is **controlled**, meaning that you **must** implement the state handling in the parent component.
 * - In contrast to basic Dropdown component, this one does not allow multiselection, because that is not a good behaviour in the AppHeader area.
 * - Similar to Dropdown, accepts only DropdownItems or DropdownGroups as children
 */
export declare class AppTopNaviDropdown extends React.Component<AppTopNaviDropdownProps> {
    static defaultProps: {
        searchable: boolean;
        placeholder: string;
        value: never[];
        clearable: boolean;
        disabled: boolean;
        clearOnEscape: boolean;
    };
    constructor(props: AppTopNaviDropdownProps);
    render(): JSX.Element;
}
export default AppTopNaviDropdown;
