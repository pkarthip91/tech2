import * as React from 'react';
import Expander from './Expander';
import { HtmlAttributes } from '../../internalUtils/HtmlAttributes';
export interface ExpanderGroupProps extends HtmlAttributes {
    singleMode?: boolean;
}
export interface ExpanderGroupState {
    openedChild: null | Expander;
}
/**
 * Container and manager for multiple Expander components. This must be used to achieve
 * automatic closing of inactive Expanders (i.e. keep only one Expander open at a time).
 *
 * **Notes:**
 */
export declare class ExpanderGroup extends React.Component<ExpanderGroupProps, ExpanderGroupState> {
    static defaultProps: {
        singleMode: boolean;
    };
    readonly state: {
        openedChild: null;
    };
    constructor(props: ExpanderGroupProps);
    render(): JSX.Element;
    private onClickChild;
}
export default ExpanderGroup;
