import * as React from 'react';
import { HtmlAttributes } from '../../internalUtils/HtmlAttributes';
export interface ExpanderProps extends HtmlAttributes {
    title: string;
    /** Set to true, to force-expand the expander. If not set, the open-state is kept in the local state of this component. */
    open?: boolean | undefined;
    /** Fired when the title area of the component is clicked.  */
    onClick?: (event: React.MouseEvent<HTMLElement>) => void;
}
export interface ExpanderState {
    open: boolean;
}
/**
 * Visual expander component, behaving much similar to HTML5 details-summary element pair.
 * Grouping these under ExpanderGroup is optional, but required for single-mode expansion.
 * Multiple levels of Expander components can be nested, and in that case the nested Expander
 * component gets a special margin to fit nicely into the parent.
 *
 * **Notes:**
 * - For automatically closing all but one expander (i.e. single-mode), make sure to wrap all Expander components under ExpanderGroup component
 */
export declare class Expander extends React.Component<ExpanderProps, ExpanderState> {
    static defaultProps: {
        open: undefined;
    };
    static readonly componentName = "Expander";
    readonly state: {
        open: boolean;
    };
    constructor(props: ExpanderProps);
    render(): JSX.Element;
    private _handleClick;
}
export default Expander;
