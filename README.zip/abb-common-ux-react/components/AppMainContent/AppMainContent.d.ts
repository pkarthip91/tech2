import * as React from 'react';
import { HtmlAttributes } from '../../internalUtils/HtmlAttributes';
export interface AppMainContentProps extends HtmlAttributes {
    /** Reserve empty space on top. Use only when your left pane can be collapsed (i.e. reserve space for the collapse/expand icon)  */
    spaceOnTop: boolean;
}
/**
 * Container for application main content, i.e. everything that is shown below application header area and on the right from left pane.
 *
 * **Notes:**
 * - This component is **controlled**, meaning that you **must** implement the state handling in the parent component.
 * - By default, AppFooter should be positioned as the last child of this component, to make it appear below main content but not under left pane
 */
export declare class AppMainContent extends React.Component<AppMainContentProps> {
    static defaultProps: {
        spaceOnTop: boolean;
    };
    constructor(props: AppMainContentProps);
    render(): JSX.Element;
}
export default AppMainContent;
