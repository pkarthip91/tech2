import * as React from 'react';
import { HtmlAttributes } from '../../internalUtils/HtmlAttributes';
import { ThreeStateValue } from '../Checkbox';
export interface Fields {
    [key: string]: string | JSX.Element | undefined | null;
}
export interface FieldStatuses {
    [key: string]: undefined | null | 1 | 2 | 3 | 4 | 5 | 6;
}
export interface DatagridRow {
    /** This property contains all the data for the row cell. Indexed by the
     * field key. */
    fields: Fields;
    /** Colorize the row with a predefined, numbered color (0-6). Colors can be
     * changed through `statusColors` prop. */
    rowStatus?: undefined | null | 0 | 1 | 2 | 3 | 4 | 5 | 6;
    /** Colorize cells of this row with a predefined, numbered color (0-6).
     * Use the field-key as the key for each cell. Colors can be changed through
     * `statusColors` prop. */
    fieldStatuses?: FieldStatuses;
    /** Set this to true, to make the row selected. Remember to enable
     * row-selection in datagrid props (`enableRowSelection`). */
    isSelected?: boolean;
    /** Set this to true, to make the row expanded. Remember to enable
     * row-expansion in datagrid props (`enableRowExpansion`), and provide the
     * expansion content (below. */
    isExpanded?: boolean;
    /** Content for the row expansion area. If this is provided (and datagrid prop
     * `enableRowExpansion` is true), the row becomes expandable. */
    expansionContent?: JSX.Element;
}
export interface DatagridColumnDef {
    /** Unique key is required for each column. */
    fieldKey: string;
    /** Column header text. This can be the same as `fieldKey`, but they are kept
     * separate for localization purposes. */
    title?: string;
    /** This feature is still under construction. Currently, it easily messes up
     * column widths configuration. It is now kept available for testing, but do
     * not use it in production yet.
     *
     * If enabled, hides the column. */
    __IN_PROGRESS__hide?: boolean;
    /** Column width. Use either a number (pixel value), or `*` for flexible width. */
    width?: '*' | number;
    /** Text alignment in this column. Applies to header, body cells and footer. */
    align?: 'left' | 'right' | 'center';
    /** When true, highlights the column with grey background. Note: this feature
     * is automatically disabled when using transparent background. */
    highlight?: boolean;
    /** Column minimum width, in pixels. Default: 50. */
    minWidth?: number;
    /** Column maximum width, in pixels. Default: positive infinity. */
    maxWidth?: number;
    /** Allow sorting by this column. */
    sortable?: boolean;
    /** Custom comparison function. By default, alphanumeric sorting is used, but
     * you can supply a custom comparison function, which should return:
     *    1: if a is bigger than b
     *   -1: if b is bigger than a
     *    0: if a and b are equal (in this case original order is used)
     */
    sortFn?: (a: any, b: any) => 1 | -1 | 0;
}
/** Custom status colors can be provided through `statusColors` prop. That prop
 * accepts values of this interface. You can give all of them, or just some of
 * them. In the former case the given color definitions fully replace the
 * defaults, and in latter case the given color definitions are merged with the
 * defaults.
 */
export interface StatusColorMappings {
    0?: string;
    1?: string;
    2?: string;
    3?: string;
    4?: string;
    5?: string;
}
export interface DatagridProps extends HtmlAttributes {
    /** Data for the datagrid. See `DatagridRow` interface for details. In short,
     * this accepts an array of rows, each of which contains the following:
     *
     *  - fields: `[{ColumnId: 'content'|| <div>...</div> }, ...]`
     *  - rowStatus: number value indicating the row status
     *  - fieldStatuses: key-value object of cell status as value and column ID as key
     *  - isSelected: boolean
     *  - isExpanded: boolean
     *  - expansionContent: JSX-content for the expansion area
  }
     */
    data: DatagridRow[];
    /** Datagrid column definitions. See `DatagridColumnDef` interface for full
     * details. In short, this accepts an array of column definitions, each of
     * which contains the following:
     *
     * - fieldKey: unique identifier of the column (often referred to as 'column id')
     * - title: visible column header string
     * - width: pixel value (number) or '*' (signifying flexible width)
     * - minWidth: pixel value (number), defaults to 50
     * - maxWidth: pixel value (number), defaults to infinity
     * - align: `left | right | center`
     * - highlight: boolean, show grey highlight background on column
     * - sortable: boolean, allow sorting by this column
     * - sortFn: optional custom sort function, if default alphanumeric sort is no good
     * */
    columns: DatagridColumnDef[];
    /** Column order is implicitly defined by the `columns` array. However, this
     * prop allows overriding it easily, without changing the `columns` prop.
     * Provide this prop as an array of field keys (strings). It can be easily
     * given by just backfeeding the value of `onColumnOrderChange` callback.
     *
     * If you want to support column dragging, you **must** set this and handle
     * `onColumnOrderChange` callback. Why, you may ask? Because this way we can
     * keep the column order explicit and out of the datagrid internal state, thus
     * making it possible to store/load the column order to/from database, or
     * otherwise persist it over page reloads. */
    columnOrder?: string[];
    /** Row sort order is implicitly defined by the order of items in the `data`
     * array. However, this prop allows defining the sort order, without changing
     * the `data` prop. Provide this prop as an object, containing the column
     * field-key, and an optional boolean for reversing order ('asc' vs 'desc').
     * It can be easily given by just backfeeding the value of `onSort` callback.
     *
     * If you want to support sorting, you **must** set this and handle `onSort`
     * callback. Why, you may ask? Because this way we can keep the sort order
     * explicit and out of the datagrid internal state, thus making it possible
     * to store/load the column order to/from database, or otherwise persist it
     * over page reloads.
     *
     * If you want, you can also opt to not set this value, and sort the `data`
     * yourself, in the `onSort` callback. */
    sortOrder?: {
        field: string;
        desc: boolean;
    };
    /** Set the page size. If not set, no pagination is used.
     * Note: this property alone will not give you the pagination control. That is
     * a separate component (`Pagination`), and you must configure and hook it to
     * the data separately. This is not the most straightforward way, but allows
     * for much more flexibility. */
    pageSize: number;
    /** Current page number, starting from 0. Remember to also set the page size
     * for this to work properly. */
    page: number;
    /** Row height can be provided either as one of the predefined heights, or as
     * custom row height (in pixels). By default, this defines the fixed row
     * height, above which the content can never grow (i.e. overflow will be hidden
     * and an ellipsis is shown). However, if `fitToContent` is enabled, `rowHeight`
     * will be used as minimum row height, and the exceeding content will make
     * each row grow on height separately. */
    rowHeight: 'small' | 'medium' | 'large' | number;
    /** When enabled, `rowHeight` is treated as minimum row height (instead of
     * fixed height), and each row is allowed to grow separately as much as the
     * content requires. */
    fitToContent: boolean;
    /** Make the row header clickable. When clicked, `onSort` will be fired, which
     * you **must** handle, and set the `sortOrder` prop accordingly. If you fail
     * to do this, the sorting will not work at all. */
    enableSorting: boolean;
    /** Show the expansion icon on the left side of the row, if the row data has
     * expansion content defined. Note: this alone will not make the row expanding
     * work: you **must** handle the `onToggleRowExpansion` callback and set the
     * expansion status in the row data accordingly. */
    enableRowExpansion: boolean;
    /** Show the selection checkbox on the left side of the row. Note: this alone
     * will not make the row selection work: you **must** handle the
     * `onToggleRowExpansion` callback and set the expansion status in the row
     * data accordingly. */
    enableRowSelection: boolean;
    /** Allow users to drag column headers to re-order them. Note: this only enables
     * the dragging behaviour, but does not actually handle setting the new column
     * order, and you have to do that in the application by handling the callback
     * `onColumnOrderChange` and setting the prop `columnOrder` accordingly. You
     * can simply feed it through in your application code, but it is important to
     * note that the Datagrid component does not hold the column order in its
     * internal state at all. This is a bit cumbersome, but allows for more
     * flexibility on the long run.
     */
    enableColumnDragging: boolean;
    /** This feature is still under construction. Currently, it easily messes up
     * column widths configuration. It is now kept available for testing, but do
     * not use it in production yet.
     *
     * If enabled, allows the user to drag column borders to resize them. */
    __IN_PROGRESS__enableColumnResize: boolean;
    /** TODO */
    /** Reserve space on the left side of the datagrid for row status indicators.
     * In order to show some row statusii, configure it in row props (`rowStatus`)
     * for each data-row separately. */
    enableRowStatusIndicators: boolean;
    /** Allow showing cell-specific status indicators. This alone does not do
     * anything, and you must specify the cell statusii in each data-row separately.
     * With this flag, you can merely turn them all of at once, even if the status
     * exists in the data. */
    enableCellStatusIndicators: boolean;
    /** Colorize every second row with slight grey background. Given a number,
     * zebra coloring is enabled with the given number used as offset. Prefer
     * offsets of 4 or 5 for larger amounts of data, as simple even/odd coloring
     * may easily cause too much visual noise. */
    zebraColoring: boolean | number;
    /** Show either normal, slightly dimmed borders, or none at all. Please note
     * that 'none' will still show a dim border between the head and the body. */
    borderStyle: 'normal' | 'discreet' | 'none';
    /** Specify the footer style. Defaults to none, and you must set this either
     * to `columns` or `free`, in order for the footer to show up at all. In
     * addition, you must provide the footer content through another prop,
     * `footerContent`. In case of `columns`, provide a key-value object of footer
     * contents per column, and in case of `free`, just provide one piece of content. */
    footerStyle: 'columns' | 'free' | 'none';
    /** Footer content can be given as a single value (free-form footer), or as an
     * object containing multiple values, one for each column (columned). In the
     * latter case, object keys represent the field keys. In both cases, footer
     * content can be given either as a string or JSX.Element. Note: remember to
     * set the `footerStyle` as well, otherwise the footer will not be shown. */
    footerContent?: string | JSX.Element | null | undefined | {
        [key: string]: string | null | undefined | JSX.Element;
    };
    /** When row selection is enabled, this sets the state of the checkbox shown
     * in the column header. It can be either unchecked (0), indeterminate (1) or
     * checked (2). Note: you must manually handle the click action callback
     * `onToggleSelectAll`, and set this prop according to your application-specific
     * calculation logic. The datagrid does not hold the selection state at all in
     * its internal state. */
    selectAllState?: ThreeStateValue;
    /** This feature is still under construction. Currently, it easily messes up
     * column widths configuration and therefore it is kept unavailable for now.
     * If enabled, allows the user to resize column so much that they don't fit
     * in the table horizontally, and a horizontal scrollbar is shown. */
    __IN_PROGRESS__allowHorizontalScroll: boolean;
    /** Add small paddings on left and right side of the datagrid body, so that the
     * first and last column contents are not too close to the container border.
     * You must decide on the use of this case by case, according to your
     * application layout and visual style. */
    sidePaddings: boolean;
    /** If given, this content is shown in place of the datagrid body. This can be
     * used for example when waiting for the data to arrive (i.e. long-running API
     * call), or when you have nothing so show (e.g. no data at all, or the user
     * has specified such content filters, that not a single row matches). */
    customMessage?: string | JSX.Element;
    /** When enabled, datagrid will not use the builtin pagination, but you have
     * decided to do it manually own. When enabled, you must slice the incoming
     * prop `data` yourself. This is required for example when doing server-side
     * data filtering or pagination. */
    enableControlledPagination: boolean;
    /** Do not use solid background, but a transparent one, thus letting the
     * container background show through. When enabled, certain other features are
     * automatically switched off, such as column highlighting and zebra (because
     * they would likely produce bad color contrasts). */
    transparentBackground: boolean;
    /** Called when user clicks the header of a column which is sortable, and the
     * sorting functionality is enabled. You must handle this and set the
     * `sortOrder` prop accordingly. */
    onSort?: (newSortOrder: {
        field: string;
    }) => void;
    /** TODO: allow multi-column sort with this interface instead of the above */
    /** Called when user drags the header of a column, and the column
     * re-ordering functionality is enabled. You must handle this and set the
     * `columnOrder` prop accordingly. */
    onColumnOrderChange?: (newColumnOrder: string[]) => void;
    /** Called when user resizes the column (by dragging its right border), and
     * the column resizing functionality is enabled. You must handle this and set
     * the new column widths for the columns in `columns` prop accordingly. */
    onColumnWidthsChange?: (newWidths: Array<{
        fieldKey: string;
        width: number | string;
    }>) => void;
    /** Called when user clicks the checkbox of a row, and the row selection
     * functionality is enabled. You must handle this and set the new column
     * selection state in `data` prop accordingly. */
    onToggleRowSelect?: (rowIndex: string, oldValue: boolean) => void;
    /** Called when user clicks the checkbox on the header of the checkbox column,
     * and the row selection functionality is enabled. You must handle this and
     * set the new column selection states for all rows in `data` prop accordingly,
     * and also feed back the select-all state to the datagrid via `selectAll` prop. */
    onToggleSelectAll?: (oldValue?: ThreeStateValue) => void;
    /** Called when user clicks the expansion carete of a row, and the row expansion
     * functionality is enabled. You must handle this and set the expansion state
     * of the row in `data` prop accordingly. */
    onToggleRowExpansion?: (expandedRows: {
        [key: string]: boolean;
    }) => void;
    /** Object containing values for all custom colors for the status indicators.
     * These have good defaults, but through this prop we allow overriding colors
     * on the application level. See interface `StatusColorMappings` above for
     * more details. */
    statusColors: StatusColorMappings;
    /** No children allowed. Everything as passed as props. */
    children?: never;
}
/**
 * Experimental, early version of Datagrid component. The API is very complicated,
 * so be sure to check the code examples in the online guideline. There will be
 * bugs and expect API breaking changes, as this is still an early beta version
 * of the component.
 *
 * **Notes:**
 * - The API is **controlled** in most cases, which means that you **must** handle
 *   the callbacks manually and set the according props, for the features to work.
 *   For example, you **must** handle `onSort` and set `sortOrder` manually, to
 *   make the sorting work. This is a bit cumbersome at first, but allows for much
 *   more flexibility on the long run (i.e. the sort-order is not kept in datagrid
 *   internal state, but on the application level state). Features behaving
 *   like this are: column dragging, column resizing, row sorting, row selection
 *   and row expansion.
 *
 * **Known issues:**
 * - Many, this is an experimental release of the component.
 * - IE will most likely never be supported.
 * - Only Chrome and Firefox are currently tested with (and there are differences between the two).
 * - At least the following are known to not work properly:
 *   - Column resizing (especially the case where columns total width is less than the table overall width)
 *   - Column dragging works on zoom 100%, but not when using some other zoom level in the browser
 *   - Performance is bad with large data (this page itself is a bit separate issue, since the page structure itself is causing most slowness)
 */
export declare class Datagrid extends React.Component<DatagridProps> {
    static defaultProps: {
        data: never[];
        page: number;
        pageSize: number;
        rowHeight: string;
        fitToContent: boolean;
        sortOrder: undefined;
        enableSorting: boolean;
        enableRowExpansion: boolean;
        enableRowSelection: boolean;
        enableColumnDragging: boolean;
        enableRowStatusIndicators: boolean;
        enableCellStatusIndicators: boolean;
        enableControlledPagination: boolean;
        zebraColoring: boolean;
        borderStyle: string;
        footerStyle: string;
        transparentBackground: boolean;
        selectAllState: ThreeStateValue;
        sidePaddings: boolean;
        statusColors: {
            0: string;
            1: string;
            2: string;
            3: string;
            4: string;
            5: string;
            6: string;
        };
        __IN_PROGRESS__enableColumnResize: boolean;
        __IN_PROGRESS__allowHorizontalScroll: boolean;
    };
    private dragElementRefs;
    private dragElementIndex?;
    private dragTargetElementIndex?;
    private draggingBack;
    private orderedColumns;
    private rootRef;
    constructor(props: DatagridProps);
    render(): JSX.Element | null;
    private handleRowSelectionChanged;
    private handleSelectAllChanged;
    private handleExpansionChanged;
    private handleSortChanged;
    private handleDragStart;
    private handleDragOver;
    private handleDragLeave;
    private handleDrop;
    private handleColumnWidthsChanged;
}
export default Datagrid;
