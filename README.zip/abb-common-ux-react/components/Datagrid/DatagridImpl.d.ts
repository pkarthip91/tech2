import * as React from 'react';
import { Column } from 'react-table';
export interface RtTableProps {
    data: any[];
    columns: Column[];
    options: any;
}
declare const _default: React.NamedExoticComponent<RtTableProps>;
export default _default;
