import * as React from 'react';
import { HtmlAttributes } from '../../internalUtils/HtmlAttributes';
import { TabItem } from '../TabControl';
export interface AboutBoxProps extends HtmlAttributes {
    productName: string;
    /** An array of TabItem components, together with their contents. */
    tabs: TabItem | TabItem[];
    /** Custom copyright text, mainly for localization purposes. */
    copyrightText: string;
    /** Prevent any children. */
    children?: never;
}
/**
 * A generic frame for About boxes. Includes common styling plus an empty TabControl.
 * Accepts 'tabs' as input, where you can inject your own TabItems.
 */
export declare class AboutBox extends React.Component<AboutBoxProps> {
    static defaultProps: {
        copyrightText: string;
    };
    readonly state: {
        activeTabIndex: number;
    };
    constructor(props: AboutBoxProps);
    render(): JSX.Element;
    private onTabChange;
}
export default AboutBox;
