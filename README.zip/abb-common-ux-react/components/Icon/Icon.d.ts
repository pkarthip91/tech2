import * as React from 'react';
import { HtmlAttributes } from '../../internalUtils/HtmlAttributes';
export interface IconProps extends HtmlAttributes {
    /** Name of the icon to use. Prepend with 'abb/', for example: abb/alarm-bell' */
    name: string;
    /** Pixel sizes for 'small', 'medium' and 'large' are 16, 24 and 32, respectively. */
    sizeClass: 'small' | 'medium' | 'large';
    /** Color of the icon. Accepts any valid color token (such as 'color-grey-10') or
     *  CSS color value (matched in that order). Defaults to color-grey-90 (i.e. #1F1F1F).
     * Note: if the color is not defined, the icon color defaults to DOM parent text
     * color (i.e. it inherits the color, according to CSS cascading rules). */
    color?: string;
    /** Fired when the use click the icon */
    onClick?: (event: React.MouseEvent<HTMLElement>) => void;
    /** Prevent any children. */
    children?: never;
}
/**
 * Easily usable wrapper over CommonUX UI icons Fonticon, in three fixed sizes.
 *
 * **Notes:**
 * - You **must** prepend the icon name with 'abb/', because we want to keep the component interface open to additional icon sets than the internal one.
 */
export declare class Icon extends React.Component<IconProps> {
    static defaultProps: {
        style: {};
        sizeClass: string;
        onClick: () => void;
    };
    constructor(props: IconProps);
    render(): JSX.Element;
}
export default Icon;
