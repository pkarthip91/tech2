import * as React from 'react';
import { HtmlAttributes } from '../../internalUtils/HtmlAttributes';
export interface SpinnerProps extends HtmlAttributes {
    /** Three color variations, does not respond to theme. */
    color: 'grey' | 'dark-grey' | 'blue' | 'red';
    /** Three different size classes, plus 'scaled', which just accommodates to parent element size. */
    sizeClass: 'scaled' | 'small' | 'medium' | 'large';
    /** Prevent any children. */
    children?: never;
}
/**
 * This is just an early prototype. Not exported!
 *
 * Small Spinner component, for places where bigger Loading Indicator is too big or heavy.
 * Does not support showing progress value, so it's only indeterminate.
 */
export declare class Spinner extends React.Component<SpinnerProps> {
    static defaultProps: {
        color: string;
        sizeClass: string;
    };
    constructor(props: SpinnerProps);
    render(): JSX.Element;
}
export default Spinner;
