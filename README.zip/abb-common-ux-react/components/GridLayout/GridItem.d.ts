import * as React from 'react';
import { HtmlAttributes } from '../../internalUtils/HtmlAttributes';
export interface GridItemProps extends HtmlAttributes {
    title?: string;
    x: number;
    y: number;
    w: number;
    h: number;
}
/**
 * This is just an early prototype. Not exported!
 * TODO: implement component
 * TODO: component interface documentation
 */
export declare class GridItem extends React.Component<GridItemProps> {
    static defaultProps: {
        title: string;
    };
    constructor(props: GridItemProps);
    render(): JSX.Element;
}
export default GridItem;
