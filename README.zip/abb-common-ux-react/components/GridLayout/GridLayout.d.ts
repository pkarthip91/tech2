import * as React from 'react';
import { HtmlAttributes } from '../../internalUtils/HtmlAttributes';
export interface GridLayoutProps extends HtmlAttributes {
    onClick?: (event: React.MouseEvent<HTMLElement>) => void;
    editMode?: boolean;
}
/**
 * This is just an early prototype. Not exported!
 * TODO: implement component
 * TODO: component interface documentation
 */
export declare class GridLayout extends React.Component<GridLayoutProps> {
    static defaultProps: {
        editMode: boolean;
    };
    private rootEl;
    private gridEl;
    private hasBeenVisible;
    constructor(props: GridLayoutProps);
    componentDidMount(): void;
    render(): JSX.Element;
    private observerVisibilityChanges;
    private onLayoutChange;
}
export default GridLayout;
