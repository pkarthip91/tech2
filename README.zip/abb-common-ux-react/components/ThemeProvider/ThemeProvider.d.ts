import * as React from 'react';
export interface ThemeProviderProps {
    /** Active theme. */
    theme: 'light' | 'dark';
}
/**
 * This component activates the React Context, where the current theme variable
 * is held. It renders nothing bu its children. You can wrap the part of your
 * application under this component, to automatically provide the active theme
 * for all CommonUX components used in the application.
 */
export declare class ThemeProvider extends React.Component<ThemeProviderProps> {
    static defaultProps: {
        theme: string;
    };
    constructor(props: ThemeProviderProps);
    render(): JSX.Element;
}
export default ThemeProvider;
