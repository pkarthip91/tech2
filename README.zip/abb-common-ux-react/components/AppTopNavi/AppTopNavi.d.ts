import * as React from 'react';
import { HtmlAttributes } from '../../internalUtils/HtmlAttributes';
export interface AppTopNaviProps extends HtmlAttributes {
    /** Makes top navi black and white. */
    monochrome: boolean;
}
/**
 * Container for application top-navigation items, placed as a child of AppHeader component.
 * Place AppTopNaviItems as direct children of this compoonent, and AppTopNaviDivider in places where
 * small vertical divider bar is required to separate different items.
 *
 * **Notes:**
 * - Accepts only AppTopNaviItem, AppTopNaviDropdown and AppTopNaviDivider components as children.
 */
export declare class AppTopNavi extends React.Component<AppTopNaviProps> {
    static defaultProps: {
        monochrome: boolean;
    };
    constructor(props: AppTopNaviProps);
    render(): JSX.Element;
}
export default AppTopNavi;
