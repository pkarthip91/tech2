import * as React from 'react';
import { HtmlAttributes } from '../../internalUtils/HtmlAttributes';
export interface ButtonProps extends HtmlAttributes {
    /** Text to display on button. Note, button does not take any children, so this plus icon are the only ways to set the button content. */
    text: string;
    /** Optional icon shown on the left before the text. */
    icon: string;
    /** Dim the button and disable click events */
    disabled?: boolean;
    /** Fired when user clicks the button. Custom data can be included as callback attribute fo* easier event handler mappings. */
    onClick?: (event: React.MouseEvent<HTMLButtonElement | HTMLAnchorElement>, customData: any) => void;
    /** Custom data to be passed to the onClick event handler when user clicks the button. */
    data?: any;
    /** Three size classes */
    sizeClass: 'small' | 'medium' | 'large';
    /** Three button shapes: rectangle has straight corners (good for mobile), rounded has slightly rounder corners (better for desktop) and pill is ABB branding style with heavy rounded-corners (do not use when you have multiple equal buttons next to each other)  */
    shape: /*'rectangle'|*/ 'rounded' | 'pill';
    /** Primary-red is **not** to be used to indicate error, but to align with ABB branding red color. */
    type: 'normal' | 'primary-blue' | 'primary-black' | 'primary-red' | 'ghost' | 'discreet-blue' | 'discreet-black';
    /** Set to true, to inject a spinner in place of the icon, and at the same time disable the button */
    isLoading: boolean;
    /** If given, button is created as a link (HTML a-tag) */
    href?: string;
    /** Standard HTML link attribute. Only used when 'href' is given. */
    download: boolean;
    /** Standard HTML link attribute. Only used when 'href' is given. */
    referrerPolicy?: 'no-referrer' | 'no-referrer-when-downgrade' | 'origin' | 'origin-when-cross-origin' | 'strict-origin-when-cross-origin' | 'unsafe-url';
    /** Standard HTML link attribute. Only used when 'href' is given. */
    target?: '_self' | '_blank' | '_parent' | '_top';
    /** Standard HTML link attribute. Only used when 'href' is given. */
    rel?: string;
    /** Prevent any children. */
    children?: never;
}
/**
 * Basic button component in different flavours. Include either text or icon, or both as contents.
 *
 * **Notes:**
 * - Usage of child elements as contents is forbidden due to the component losing control of styling
 */
export declare class Button extends React.Component<ButtonProps> {
    static defaultProps: {
        text: undefined;
        icon: undefined;
        sizeClass: string;
        type: string;
        shape: string;
        isLoading: boolean;
        download: boolean;
    };
    constructor(props: ButtonProps);
    render(): JSX.Element;
    private _handleClick;
}
export default Button;
