import * as React from 'react';
import { HtmlAttributes } from '../../internalUtils/HtmlAttributes';
export interface LoadingIndicatorProps extends HtmlAttributes {
    /** Three size classes. For radial, smallest size automatically hides the value text. */
    sizeClass: 'small' | 'medium' | 'large';
    /** Either horizontal bar or full circle. */
    type: 'bar' | 'radial';
    /** When true, the given value is displayed on top of the animated (pulsating) background. When false, only the pulsating background is shown. Note: you *must* provide the value when this is true. */
    determinate: boolean;
    /** Number value on range 0-100. Values outside the allowed range are normalized to range limits. */
    value?: number;
    /** Custom text showing either some explanation text, or the current value. */
    text?: string;
    /** Show this text when value reaches 100. If not given, the 'text' is shown all the time. */
    textWhenReady?: string;
    /** The primary color of the indicator. For determinate mode, this is the area that shows the progress value; for indeteminate mode, this is the color of the pulsating background. */
    color: 'red' | 'blue' | 'grey';
    /** Fired when any part of the loading indicator bounding box is clicked. */
    onClick?: (event: React.MouseEvent<HTMLElement>) => void;
    /** Prevent any children. */
    children?: never;
}
export interface LoadingIndicatorState {
    numberOfSegments: number;
    noDraw: boolean;
}
/**
 * Radial and linear loading indicators, both deteminate and indeterminate versions. Three size classes and three colors.
 *
 * **Known issues:**
 * - Fallback implementation used for IE and Edge, due to their inability to (properly) handle CSS animations on SVG elements
 * - The current implementation is rather CPU-intensive; do not insert large number of loading indicators on one page
 * - No theming support!
 */
export declare class LoadingIndicator extends React.Component<LoadingIndicatorProps, LoadingIndicatorState> {
    static defaultProps: {
        type: string;
        sizeClass: string;
        value: undefined;
        text: undefined;
        textWhenReady: undefined;
        color: string;
    };
    readonly state: {
        numberOfSegments: number;
        noDraw: boolean;
    };
    constructor(props: LoadingIndicatorProps);
    componentDidUpdate(prevProps: LoadingIndicatorProps): void;
    render(): JSX.Element | null;
    private _handleResize;
    private _handleClick;
}
export default LoadingIndicator;
