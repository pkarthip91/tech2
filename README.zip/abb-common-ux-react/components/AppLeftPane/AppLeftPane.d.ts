import * as React from 'react';
import { HtmlAttributes } from '../../internalUtils/HtmlAttributes';
export interface AppLeftPaneProps extends HtmlAttributes {
    /** Controls the mode of left pane. */
    visibility?: 'full' | 'compact' | 'thumbs' | 'hidden' | null | undefined;
    /** Show/hide the 1px wide grey right-border. Likely to be deprecated soon. */
    showRightBorder?: boolean;
    /** Show the collapse/expand icon. */
    showVisibilityToggle?: boolean;
    /** Fired when the user clicks the collapse/expand icon. */
    onClickToggleVisibility?: (event: React.MouseEvent<HTMLElement>) => void;
    /** Controls the icon used for collapsing */
    icon: string;
    /** Set an optional title for the left pane. It appears below the collapser icon. */
    title?: string;
    /** Set it to true if you want to show the search bar in full mode. It appears on top of all content. */
    showSearchBarInFullMode: boolean;
    /** Specify the position of the search box. By default, it is inline, meaning it will appear alongside the collapser icon. */
    searchBarPositionInFullMode: 'inline' | 'below';
    /** Set the value of the search input. Since it is a controlled component, you always have to set the value. */
    searchValue?: string;
    /** Get the value from the search input. It emits the string from the input. */
    onSearchValueChange?: (value: string) => void;
    /** Set the placeholder string for the search bar. */
    searchBarPlaceholder?: string;
    /** Set it to true if you want clear on escape for the search input */
    clearSearchOnEscape: boolean;
}
/**
 * Container for left-pane content. Includes funcionality for collapsion/expansion of the pane.
 *
 * **Notes:**
 * - This component is **controlled**, meaning that you **must** implement the state handling in the parent component (i.e. set 'collapsed' prop in parent).
 *
 * **Known issues:**
 * - Currently very simple, but will include functionality for 4 different modes (full, pictograms, thumbs, and collapsed)
 */
export declare class AppLeftPane extends React.Component<AppLeftPaneProps> {
    static defaultProps: {
        showRightBorder: boolean;
        showVisibilityToggle: boolean;
        icon: string;
        showSearchBarInFullMode: boolean;
        searchBarPositionInFullMode: string;
        clearSearchOnEscape: boolean;
    };
    constructor(props: AppLeftPaneProps);
    render(): JSX.Element;
    private _handleCollapserClick;
}
export default AppLeftPane;
