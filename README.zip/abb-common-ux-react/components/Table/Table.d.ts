import * as React from 'react';
import { HtmlAttributes } from '../../internalUtils/HtmlAttributes';
export interface TableProps extends HtmlAttributes {
    sizeClass: 'small' | 'medium' | 'large' | 'custom';
    customRowHeight?: string;
    /** Colorize every second row with slight grey background. */
    zebra: boolean;
    fitToContent: boolean;
    highlightColumns: number[];
    activeHeader?: number;
    solidBackground: boolean;
    borderType: 'normal' | 'discreet' | 'none';
}
export interface StyleClasses {
    /** Show blue bottom border on header with this class */
    activeHeader: string;
    /** Show light grey background on all cells with this class. */
    highlightCell: string;
    /** Show light grey background on all rows with this class. Use this when
     * you want to have zebra-coloring on some other offset than even/odd.
     * For large amount of data, it is often visually clearer to zebra-color
     * every fourth or fifth row. */
    zebraRow: string;
}
/**
 * Extremely simple, standard HTML table wrapper. Use exactly as you would use 'table',
 * but this just applies the styling classes. To be clear, this component already renders
 * the 'table' element.
 *
 * **Notes:**
 * - This component is the simplest possible table implementation; another, more complex implementation will be done later (as another component)
 * - Styling columns/cells with colgroups/cols does not properly together with the zebra coloring, particularly with overlapping cells (i.e. zebra + highlight at the same time)
 */
export declare class Table extends React.Component<TableProps> {
    static defaultProps: {
        sizeClass: string;
        zebra: boolean;
        fitToContent: boolean;
        highlightColumns: never[];
        solidBackground: boolean;
        borderType: string;
    };
    colCount: number;
    private rootElRef;
    static classes: StyleClasses;
    private setCustomRowHeight;
    constructor(props: TableProps);
    componentDidMount(): void;
    componentDidUpdate(): void;
    render(): JSX.Element;
}
export default Table;
