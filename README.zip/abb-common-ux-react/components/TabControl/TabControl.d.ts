import * as React from 'react';
import { HtmlAttributes } from '../../internalUtils/HtmlAttributes';
export interface TabControlProps extends HtmlAttributes {
    /** Custom class name applied to the content container. */
    contentClassName?: string;
    /** Controls which tabitem is active */
    activeTab: number;
    /** Three different visual styles. */
    type: 'primary' | 'secondary' | 'panel';
    /** Special customization flag for places where the container already provides a visible border. */
    showContentBorderOnPanelTab?: boolean;
    /** Provide the id of your custom container element, when you want to detach the tab content area from the header area. Uses React Portals as implementation. */
    containerId?: string | null;
    /** Should the tab header area stretch the width of all tab items to cover full width. */
    stretch?: boolean;
    /** Allow user to add new tab dynamically via plus-button. Note, this just provides the button, you **must** handle the new tab content creation through "onAddNewTab" event. */
    allowAdd?: boolean;
    /** Allow user to remove existing tabs. Note, this just provides the button, you **must** handle the tab deletion yourself by handling the "onRemoveTab" event. */
    allowRemove?: boolean;
    /**
     * Use this to put a padding to the left of the tab list. By default, it is false, which means no padding is set.
     * If set to true, then a default padding of 40px is set. Alternatively, a string with the amount of pixels to pad
     * can be passed to it as well. This is helpful when used in conjunction with hidden mode of the left pane.
     */
    padLeft: boolean | string;
    /** Fired when the user changes the active tab. */
    onTabChange?: (oldIndex: number, newIndex: number) => void;
    /** Fired when the user click the push button to add a new tab. */
    onAddNewTab?: (tabcontrol: TabControl, index: number) => void;
    /** Fired when the user clicks the close buttton of some tab. */
    onRemoveTab?: (tabcontrol: TabControl, index: number) => void;
    /** Accepts only TabItems as children */
    /** Make tab item headers monochrome. Panel tab style is not affected, because it does not contain any red or blue highlight color. */
    monochrome: boolean;
}
/**
 * Tabcontrol component is provided in 3 style variations and acts as the container for a number of TabItem components.
 * Tab addition/removal is supported.
 *
 * **Notes:**
 * - This component is **controlled**, meaning that you **must** implement the active tab state handling in the parent component.
 * - Accepts only TabItems as children
 */
export declare class TabControl extends React.Component<TabControlProps> {
    static defaultProps: {
        activeTab: number;
        type: string;
        containerId: null;
        stretch: boolean;
        allowAdd: boolean;
        allowRemove: boolean;
        showContentBorderOnPanelTab: boolean;
        padLeft: boolean;
        monochrome: boolean;
    };
    private containerEl;
    constructor(props: TabControlProps);
    componentDidMount(): void;
    render(): JSX.Element | null;
    private _handleClick;
    private _addNewTab;
    private _removeTab;
}
export default TabControl;
