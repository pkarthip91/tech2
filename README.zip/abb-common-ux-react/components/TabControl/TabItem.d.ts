import * as React from 'react';
import { HtmlAttributes } from '../../internalUtils/HtmlAttributes';
export interface TabItemProps extends HtmlAttributes {
    /** The title string of tabitem in the header area. */
    title: string;
    /** Dim the item title and prevent selection. */
    disabled?: boolean;
}
export declare class TabItem extends React.Component<TabItemProps> {
    static defaultProps: {
        disabled: boolean;
    };
    constructor(props: TabItemProps);
    render(): JSX.Element | null;
}
export default TabItem;
