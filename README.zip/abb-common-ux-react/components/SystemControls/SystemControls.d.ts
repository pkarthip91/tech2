import * as React from 'react';
import { HtmlAttributes } from '../../internalUtils/HtmlAttributes';
export interface SystemControlsProps extends HtmlAttributes {
    onMinimize?: (event: React.MouseEvent<HTMLElement>) => void;
    onMaximize?: (event: React.MouseEvent<HTMLElement>) => void;
    onRestore?: (event: React.MouseEvent<HTMLElement>) => void;
    onClose?: (event: React.MouseEvent<HTMLElement>) => void;
    /** Show minimize-button  */
    showMinimize?: boolean;
    /** Show maximize-button. Note: show this only when the window is **not** maximized.  */
    showMaximize?: boolean;
    /** Show restore-button, which should reset the window state back to what it was before maximizing. Note: show this only when the window is maximized.  */
    showRestore?: boolean;
    /** Show close-button. Close button is always red. */
    showClose?: boolean;
    /** Prevent any children. */
    children?: never;
}
/**
 * Show application window minimize/restore/maximize/close buttons. Should be placed on
 * the right end of AbbBar component. Useful only in the case of implementing desktop
 * applications with web-technologies, like Electron.
 *
 * **Notes:**
 * - You **should** disable the native window styles in your desktop application code before taking this into use
 * - This component is purely visual, therefore you **must** implement actual window management in your application code
 *
 * **Known issues:**
 * - Currently only Windows-style controls are supported. Mac-support is on roadmap.
 */
export declare class SystemControls extends React.Component<SystemControlsProps> {
    static defaultProps: {
        showMinimize: boolean;
        showMaximize: boolean;
        showRestore: boolean;
        showClose: boolean;
    };
    constructor(props: SystemControlsProps);
    render(): JSX.Element;
    private handleMinimize;
    private handleMaximize;
    private handleRestore;
    private handleClose;
}
export default SystemControls;
