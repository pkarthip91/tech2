import * as React from 'react';
import { HtmlAttributes } from '../../internalUtils/HtmlAttributes';
export interface MenuBarProps extends HtmlAttributes {
    onClick?: (event: React.MouseEvent<HTMLElement>) => void;
}
/**
 * NOT-READY-YET: do not use. Not exported!
 *
 * Windows-like File-menu for React. For now, use Menu, MenuItem and SubMenu instead,
 * as they provide mostly exact functionality. This component would align more with
 * Windows-style File-menu.
 */
export declare class MenuBar extends React.Component<MenuBarProps> {
    static defaultProps: {};
    constructor(props: MenuBarProps);
    render(): JSX.Element;
    private _handleClick;
}
export default MenuBar;
