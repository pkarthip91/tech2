import * as React from 'react';
import { HtmlAttributes } from '../../internalUtils/HtmlAttributes';
export declare type AppHeaderProps = HtmlAttributes;
/**
 * Full-width container for e.g. application top-navigation and user menu.
 *
 * **Notes:**
 * - By default content items are positioned to the left; use AppHeaderSpacer (which is just a "flex: 2" element) to push rest of the items to the right
 */
export declare class AppHeader extends React.Component<AppHeaderProps> {
    constructor(props: AppHeaderProps);
    render(): JSX.Element;
}
export default AppHeader;
