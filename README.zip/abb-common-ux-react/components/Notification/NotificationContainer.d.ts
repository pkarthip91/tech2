import * as React from 'react';
import { HtmlAttributes } from '../../internalUtils/HtmlAttributes';
import { NotificationData } from './NotificationData';
export interface NotificationContainerProps extends HtmlAttributes {
    /** Array of all Notifications to be shown. */
    notifications: NotificationData[];
    /** Provide your application specific handler for closing notifications. */
    actionHandler: {
        remove: (id: string) => void;
    };
    /** Prevent any children. Use "notification" array property instead to inject actual Notifications into this container. */
    children?: never;
}
/**
 * Container element and lifecycle manager of all notifications.
 *
 * **Notes:**
 * - Position this component with fixed position, to top-right corner of your application. Exact position depends on your application layout.
 * - You **must** handle the management of notification lifecycles in application (i.e. firing, queuing and removing)
 */
export declare class NotificationContainer extends React.Component<NotificationContainerProps> {
    static defaultProps: {
        notifications: never[];
    };
    constructor(props: NotificationContainerProps);
    render(): JSX.Element;
}
export default NotificationContainer;
