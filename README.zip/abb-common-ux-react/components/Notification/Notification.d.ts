import * as React from 'react';
import { HtmlAttributes } from '../../internalUtils/HtmlAttributes';
import { NotificationData } from './NotificationData';
export interface NotificationProps extends HtmlAttributes {
    /** All properties of the notification are contained in this object. */
    data: NotificationData;
    /**
     * Internal implementation detail - do not use.
     * @ignore
     */
    removalHandler: {
        remove: (id: string) => void;
    };
    /** Prevent any children. */
    children?: never;
    /** Changes the primary button type to black. */
    monochromeButtons: boolean;
}
export interface NotificationState {
    isClosing: boolean;
}
/**
 * Notification has two variants: 'banner' has only close icon, whereas 'confirmation' can include any custom buttons.
 *
 * **Notes:**
 * - This component should not be used directly, but always through NotificationContainer and its API
 * - You **must** position the NotificationContainer yourself, as that varies per application
 * - You **must** handle the management of notification lifecycles in application
 * - In case of large number of concurrent notifications, **consider** implementing a queuing mechanism
 */
export declare class Notification extends React.Component<NotificationProps, NotificationState> {
    static defaultProps: {
        isClosing: boolean;
        monochromeButtons: boolean;
    };
    readonly state: {
        isClosing: boolean;
    };
    private timeout;
    constructor(props: NotificationProps);
    render(): JSX.Element;
    componentDidMount(): void;
    remove(): void;
    private initAutomaticHiding;
    private _customButtonClickHandler;
    private _onClose;
    private _onMouseEnter;
    private _onMouseLeave;
    private _handleClick;
}
export default Notification;
