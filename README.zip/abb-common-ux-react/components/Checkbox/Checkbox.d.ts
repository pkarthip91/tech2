import * as React from 'react';
import { HtmlAttributes } from '../../internalUtils/HtmlAttributes';
export declare enum ThreeStateValue {
    Unchecked = 0,
    Indeterminate = 1,
    Checked = 2
}
export interface CheckboxProps extends HtmlAttributes {
    /** Current value of the checkbox. Use boolean value for simple 2-state checkbox and ThreeStateValue for 3-state checkbox. */
    value: boolean | ThreeStateValue;
    /** Short text shown left to the input field */
    label?: string;
    /** Checkboxes come in two sizes.
     * Note: Large size is default for checkbox, but for radiobutton the default size is small.
     */
    sizeClass: 'small' | 'large';
    /** Dim the checkbox and do not trigger click events. */
    disabled?: boolean;
    /**
     * Fired when the user changes the checkbox value by clicking it, or through keyboard, when focused.
     * No value is given as an event attribute, as this component is always used as *controlled*, so the
     * application must always have the current value in its state. Custom data object (such as row id) can
     * be included as callback attribute for easier event handler mappings.
     */
    onChange?: (customData: any) => void;
    /** Custom data to be passed to the onChange event handler on user action; used to ease access to data, when you want to avoid lambdas on handlers */
    data?: any;
    /** Prevent any children. */
    children?: never;
    /** Make checkbox black and white. */
    monochrome: boolean;
}
/**
 * Standard checkbox component.
 *
 * **Notes:**
 * - This component is **controlled**, meaning that you **must** implement the state handling in the parent component.
 */
export declare class Checkbox extends React.Component<CheckboxProps> {
    static defaultProps: {
        value: undefined;
        allowIndeterminate: boolean;
        label: string;
        sizeClass: string;
        disabled: boolean;
        monochrome: boolean;
    };
    constructor(props: CheckboxProps);
    render(): JSX.Element;
    private _handleChange;
    private _handleClick;
}
export default Checkbox;
