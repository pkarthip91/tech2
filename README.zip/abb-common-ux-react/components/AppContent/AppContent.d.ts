import * as React from 'react';
import { HtmlAttributes } from '../../internalUtils/HtmlAttributes';
export declare type AppContentProps = HtmlAttributes;
/**
 * Container for everything below the full-width application header area. Takes always
 * full page width, typically separated to left-pane and main content areas.
 */
export declare class AppContent extends React.Component<AppContentProps> {
    constructor(props: AppContentProps);
    render(): JSX.Element;
}
export default AppContent;
