import * as React from 'react';
import { HtmlAttributes } from '../../internalUtils/HtmlAttributes';
export interface ToggleButtonProps extends HtmlAttributes {
    text?: string;
    icon?: string;
    disabled?: boolean;
    /** Fired when the toggle button is clicked by the user. Note, this is not needed to handle the toggling, as the ToggleButtonGroup does that. */
    onClick?: (event: React.MouseEvent<HTMLElement>) => void;
    /**
     * Internally set by the parent ToggleButtonGroup component. Do not use.
     * @ignore
     */
    _fromParent_: {
        name: string;
        sizeClass: 'small' | 'medium' | 'large';
        multiselect: boolean;
        monochrome: boolean;
        isFirst: boolean;
        isLast: boolean;
        selected: boolean;
        nextIsSelected: boolean;
        onClick?: (target: EventTarget) => void;
    };
}
/**
 * ToggleButtons component, to be used always as a direct child of ToggleButtonGroup component.
 *
 * **Notes:**
 * - Normally there's no need to listen for the onClick event; use it only for your custom needs
 * - You **must** wrap all ToggleButtons components under ToggleButtonGroup component, because that component handles the state of the the buttons
 * - ToggleButton does not accept any children, *except Popup* (this is a special case of Popup usage, without WithPopup component as its parent)
 */
export declare class ToggleButton extends React.Component<ToggleButtonProps> {
    static defaultProps: {
        text: string;
        disabled: boolean;
        _fromParent_: {};
    };
    static readonly componentName = "ToggleButton";
    private labelDomNode;
    private hasPopup;
    constructor(props: ToggleButtonProps);
    render(): JSX.Element;
    private _handleChange;
    private _handleClick;
}
export default ToggleButton;
