import * as React from 'react';
import { HtmlAttributes } from '../../internalUtils/HtmlAttributes';
export interface ToggleButtonGroupProps extends HtmlAttributes {
    /** Fired whenever user toggles some button. The selected button(s) are reported as indices in an array. The value is always an array, to keep the interface same for multiselect and single-select. */
    onChange?: (selected: number[]) => void;
    /** Index/indices of the pressed buttons. The value is always an array, to keep the interface same for multiselect and single-select. */
    selected?: number[];
    /** Allow multiple buttons to be in pressed state concurrently. */
    multiselect?: boolean;
    /** Make toggle buttons black and white. Previously under "type: black". */
    monochrome: boolean;
    /** Three size variations. */
    sizeClass?: 'small' | 'medium' | 'large';
}
/**
 * Container and manager component for ToggleButtons.
 *
 * **Notes:**
 * - You **must** wrap all ToggleButtons components under this component, because this component handles the state of them
 * - This component is **controlled**, meaning that you **must** implement the state handling in the parent component.
 * - Accepts ToggleButtons as children, but those can also be wrapped in WithPopup, to fire up a Popup on click or hover.
 */
export declare class ToggleButtonGroup extends React.Component<ToggleButtonGroupProps> {
    static defaultProps: ToggleButtonGroupProps;
    static GROUP_COUNTER: number;
    private groupName;
    private rootDomNode;
    constructor(props: ToggleButtonGroupProps);
    render(): JSX.Element;
    private _handleChange;
}
export default ToggleButtonGroup;
