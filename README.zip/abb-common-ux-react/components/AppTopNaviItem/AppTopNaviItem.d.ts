import * as React from 'react';
import { HtmlAttributes } from '../../internalUtils/HtmlAttributes';
export interface AppTopNaviItemProps extends HtmlAttributes {
    /** When true, show blue bottom border. */
    active: boolean;
    /** When true, dims the item and disables click events. */
    disabled?: boolean;
    text: string;
    icon: string;
    /** When set will be treated as a link */
    link?: string;
    /** Set this to true, for cases where this component is used with a Menu (which opens when user clicks the item). */
    hasMenu?: boolean;
    /** Use this and onLostFocus events to open/close the menu */
    onClick?: (event: React.MouseEvent<HTMLElement>) => void;
    /** Use this and onClick events to open/close the menu */
    onLostFocus?: (event: React.FocusEvent<HTMLElement>) => void;
}
/**
 * Used as a direct child of AppTopNavi, in similar manner as AppTopNaviDropdown.
 * Item can be activated, meaning that it get blue bottom border.
 * Items can have a menu popped up on mouse click.
 *
 * **Notes:**
 * - This component is **controlled**, meaning that you **must** implement the state handling in the parent component.
 * - Managing menu open/close state must be manually managed, though it is in roadmap to provide a wrapping component for that
 * - Does not accept any children apart from a Menu, which is shown as context menu on click.
 */
export declare class AppTopNaviItem extends React.Component<AppTopNaviItemProps> {
    static defaultProps: {
        icon: undefined;
        text: undefined;
        active: boolean;
        hasMenu: boolean;
    };
    constructor(props: AppTopNaviItemProps);
    render(): JSX.Element;
    private _handleClick;
    private _handleLostFocus;
}
export default AppTopNaviItem;
