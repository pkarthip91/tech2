import * as React from 'react';
import { HtmlAttributes } from '../../internalUtils/HtmlAttributes';
import '../../../../styles/src/fonts.css';
export interface AppContainerProps extends HtmlAttributes {
    /** This controls the whole application theme setting. */
    theme: string | 'light' | 'dark';
}
/**
 * The top-level container for the whole application. Acts as theme-provider and prevents page
 * overall scroll (each component is responsible for scrolling their own content).
 */
export declare class AppContainer extends React.Component<AppContainerProps> {
    static defaultProps: {
        theme: string;
    };
    constructor(props: AppContainerProps);
    render(): JSX.Element;
}
export default AppContainer;
