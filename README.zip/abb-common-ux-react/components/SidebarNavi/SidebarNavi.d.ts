import * as React from 'react';
import { HtmlAttributes } from '../../internalUtils/HtmlAttributes';
export interface SidebarNaviProps extends HtmlAttributes {
    /** Makes the left pane black and white. */
    monochrome: boolean;
}
export declare class SidebarNavi extends React.Component<SidebarNaviProps> {
    static defaultProps: {
        monochrome: boolean;
    };
    constructor(props: SidebarNaviProps);
    render(): JSX.Element;
}
export default SidebarNavi;
