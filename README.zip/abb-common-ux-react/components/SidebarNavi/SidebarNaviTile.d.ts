import * as React from 'react';
import { HtmlAttributes } from '../../internalUtils/HtmlAttributes';
export interface SidebarNaviTileProps extends HtmlAttributes {
    title?: string;
    mode: 'thumbs' | 'pictograms';
    secondary?: boolean;
    active?: boolean;
    onClick?: (event: React.MouseEvent<HTMLElement>) => void;
}
export declare class SidebarNaviTile extends React.Component<SidebarNaviTileProps> {
    static defaultProps: {
        active: boolean;
        mode: string;
        secondary: boolean;
    };
    constructor(props: SidebarNaviTileProps);
    render(): JSX.Element;
    private _handleClick;
}
export default SidebarNaviTile;
