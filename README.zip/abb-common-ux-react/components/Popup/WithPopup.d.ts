import * as React from 'react';
export interface WithPopupProps {
    children: any;
}
/**
 * Helper component to use Popup decralatively. Accepts exactly two child elements. The first one
 * acts as the trigger element, clicking/hovering of which causes the dialog to open, whereas the second
 * child is the Popup itself.
 *
 * **Notes:**
 * - This component does not take any props; all necessary props are defined in the Popup component.
 */
export declare class WithPopup extends React.Component<WithPopupProps> {
    static readonly componentName = "WithPopup";
    private static readonly errorPrefix;
    private closeAction;
    private content;
    private closeTimeout;
    private originalTriggerClickHandler;
    private closedThroughEscapeOrIconOrTimeout;
    constructor(props: WithPopupProps);
    render(): JSX.Element;
    private _setCloseHandler;
    private _onOpen;
    private _onClose;
    private _onCloseClick;
}
export default WithPopup;
