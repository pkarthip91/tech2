import * as React from 'react';
import { HtmlAttributes } from '../../internalUtils/HtmlAttributes';
export declare type PopupPosition = 'top left' | 'top right' | 'bottom right' | 'bottom left' | 'right center' | 'left center' | 'top center' | 'bottom center';
export interface PopupProps extends HtmlAttributes {
    /** Should the dialog be opened on hover or click event on the trigger element, or on extenal trigger (i.e. controlled). If showing Popup with an external trigger, be sure to use "controlled" here. */
    trigger: 'click' | 'hover' | 'controlled';
    /** Should the popup be automatically opened on first render. */
    defaultOpen: boolean;
    /** Show the close icon in top right corner of the popup. */
    showCloseButton: boolean;
    /** Close the popup when user presses Escape key on keyboard. Note, for this to work, the popup must have focus. */
    closeOnEscape: boolean;
    /** Close the popup when user clicks somewhere outside of its area. */
    closeOnLostFocus: boolean;
    /** Do no apply popup default styling classes. Useful for highly customized popup styles. */
    disableDefaultStyle: boolean;
    /** By default, Popup has small paddings on each side, to give airy look and feel. However, in some cases this is not wanted, e.g. when showing a list of clickable items. */
    disablePaddings: boolean;
    /** Position for the popup. Best position is calculated by checking against overlap with boundary element, and applied in the order specified. For example, provide [top, bottom], to primarily show it on top of the trigger element, but fallback to bottom if there's no room above. */
    position: PopupPosition | PopupPosition[];
    onOpen: (() => void) | null;
    onClose: (() => void) | null;
    /** Timeout, in millisecods, after which the popup automatically closes. */
    closeAfter: number;
    /** Render prop. Popup content can be given as children, or as render prop. The advantage of render prop is that the popup content receives a pointer to the popup object itself, and can e.g. close it from within. */
    render: any;
    /** Governs the open/close state of the popup; use only when using programmatically in "controlled" mode. */
    show: boolean | undefined;
    /** Prevent Popup from being shown when true. */
    disabled: boolean;
}
/**
 * Contextual Popup component. Must be used declaratively as a child of WithPopup component.
 *
 * **Notes:**
 * See documentation of WithPopup for more details.
 * - **Warning**: this component will fail to call possibly defined custom onMouseEnter/onMouseLeave handlers of the trigger:
 *
 * <pre><code style="font-size: 10px">
 * &lt;WithPopup&gt;
 *   &lt;div onMouseEnter={() =&gt; alert('this will not be called!')} &gt;...&lt;/&gt;
 *   &lt;Popup ...&gt;
 *      ...
 *   &lt;/Popup&gt;
 * &lt;/WithPopup&gt;
 * </code></pre>
 *
 * As a workaround, use onMouseOver/onMouseOut events, or wrap your trigger in another div:
 *
 * <pre><code style="font-size: 10px">
 * &lt;WithPopup&gt;
 *   &lt;div&gt;
 *     &lt;div onMouseEnter={() =&gt; alert('this works')} &gt;...&lt;/&gt;
 *   &lt;/div&gt;
 *   &lt;Popup ...&gt;
 *      ...
 *   &lt;/Popup&gt;
 * &lt;/WithPopup&gt;
 * </code></pre>
 *
 */
export declare class Popup extends React.Component<PopupProps> {
    static defaultProps: {
        trigger: string;
        defaultOpen: boolean;
        showCloseButton: boolean;
        closeOnEscape: boolean;
        closeOnLostFocus: boolean;
        disableDefaultStyle: boolean;
        disablePaddings: boolean;
        position: string[];
        onOpen: null;
        onClose: null;
        closeAfter: number;
        render: null;
        show: undefined;
        disabled: boolean;
    };
    static readonly componentName = "Popup";
    readonly state: {};
    constructor(props: PopupProps);
    private handleKeyDown;
    render(): JSX.Element;
    close(): void;
}
export default Popup;
