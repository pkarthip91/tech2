import * as React from 'react';
import { HtmlAttributes } from '../../internalUtils/HtmlAttributes';
export interface AppHeaderSpacerProps extends HtmlAttributes {
    /** Prevent any children. */
    children?: never;
}
/**
 * Simple "flex: 2" spring-spacer to push the rest of the items to the right.
 */
export declare class AppHeaderSpacer extends React.Component<AppHeaderSpacerProps> {
    constructor(props: AppHeaderSpacerProps);
    render(): JSX.Element;
}
export default AppHeaderSpacer;
