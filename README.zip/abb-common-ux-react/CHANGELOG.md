# Changelog

## v0.7.2 (16-06-2020)

#### Bug fixes:

- Downgrade peer-dependency `rc-slider` back to 8.x.x, due to visual bugs in 9.x.x
- Add method `focus` in Input component API, for focusing it imperatively after render
- Fix: theming did not work at all when using isolated component modules (because React Context was re-created for each module separately)
  - i.e. like this: `import { Button } from '@abb/abb-common-ux-react/components/Button/Button';`
- internal: fix all ESLint warnings and errors (after eslint upgrade v6 --> v7 )

---

## v0.7.1 (15-05-2020)

#### Enhancements:

- CloseIcon component now takes "disabled" prop

#### Bug fixes:

- Fix: Button min-width was not respected when parent is "display: flex" and button is "flex: 0"

  - This caused the buttons to overflow at least in Dialog with standard-buttons-on-bottom

- Fix: Dropdown option disabling (was ignored)
- Fix: Multiselect dropdown visual issues (inner margins and colors slightly wrong)

---

## v0.7.0 (08-05-2020)

#### Breaking changes:

- `colorVariation` API in `ToggleButton` component has been changed to `monochrome` which accepts a boolean value

#### Enhancements:

- New prop `monochrome` added to following components: AppTopNavi, Checkbox, Collapsible, Menu, Radio, SidebarNavi, Slider, Tab, ToggleSwitch and ToggleButtonGroup
  - This changes the highlight color of the component from blue to black/white, in light/dark theme, respectively
- Dialog and Notification support primary-black and discreet-black -type of buttons

#### Bug fixes:

- Fix: Datagrid: sort not resetting on third click (now first click sorts ascending, second descending, and third removes the sort)
- Fix: Datagrid: column resizing handle too thin (1px --> 2px)
- Fix: Datagrid: footer had wrong paddings
- Fix: Datagrid: Pagination had wrong font, wrong inner paddings, and wrong mouse cursor

---

## v0.6.0 (20-04-2020)

#### Bug fixes:

- Dropdown component background was wrong when disabled

#### Enhancements:

- Added first version of Datagrid component (this is still very early beta, but giving it out for testing now)

---

## v0.5.0 (27-03-2020)

#### Breaking changes:

- Rename CSSHelpers to cssHelpers 'utils' for consistency

#### Bug fixes:

- Fixed filtering functionality in Collapsible component

#### Enhancements:

- Add Pagination component, to be used together with Table and upcoming Datagrid.
- Added ThemeProvider component, for easier theming support on cases where AppContainer component cannot be used (because it also adds opinionated layout rules)
- New prop in Popup, to disable default paddings (useful when your content takes full width/height of the popup)
- Add 'gotFocus' and 'lostFocus' events to Input component

---

## v0.3.2 (20-02-2020)

#### Bug fixes:

- Fix: Dropdown component does not show the selected value on initial render.

---

## v0.4.0 (26-02-2020)

#### Breaking changes:

- Complete re-write of the static Table component, due to new design; this component is just a thin wrapper over standard HTML table, and proper datagrid is coming soon

#### Bug fixes:

- Login screen input fields were part of a form, which caused unexptected form submission on enter-press; now there's no form, just the fields

---

## v0.3.2 (20-02-2020)

#### Bug fixes:

- Fix: Dropdown component does not show the selected value on initial render.

---

## v0.3.1 (06-02-2020)

#### Bug fixes:

- Fix a broken reference to non-existent color (color-grey-0)
  - This caused a few components to have transparent background instead of white

---

## v0.3.0 (04-02-2020)

#### Breaking changes:

- Update all 3rd party deps (incl. peerDeps) to their latest versions
  - Does not affect our components APIs, but you need to update your application peer dependencies
- Dropdown component validation API changed from accepting values 'error'/'ok' to accepting a boolean 'valid'
- WithPopup component now only accepts standard HTML elements as the trigger (i.e. the first child)
  - This fixes a few bugs in its positioning, and simplifies the implementation
  - If you've used React components as trigger, just wrap the component in a div/span
- All WithTooltip component props were moved to Tooltip component, to be in line with other With-component implementations
- The usage of ToggleButton with a Popup has changed: now you must omit the 'WithPopup' and do this instead:
  - `<ToggleButton text="..."><Popup [popup props]>[popup content]</Popup><ToggleButton>`
  - This is due to achieve simpler interface and implementation, and to fix a bug on old behaviour
- Visual breaking CSS changes to the application layout
  - Widths and positions of AppContainer, AppContent and AppMainContent were changed
  - These names are bad, and should be changed someday
- Button styles have been visually changed
  - API remains the same though, but bounding box width is slightly affected, so it will cause minor layout changes
- Multiple color definitions changed in the used color palette
  - The following were removed: gray-0, gray-5, gray-85, gray-110
  - The following were added: black-primary, black-secondary, black-tertiary, white-primary, white-secondary, white-tertiary
  - Most gray colors were updated to fix the new palette

#### Bug fixes:

- Add proper margins between Input component label, input and description elements, to align it correctly with Dropdown
- Dropdown component options can be changed after the initial construction
  - Earlier, DropdownOptions were enumerated only on constructor
- With-components (e.g. WithDialog) do not anymore swallow the original "onClick" events of the trigger.
- Fixed various color values on many components
  - Automatically reading all design token values through Figma API now
- Popup under ToggleButton should now work in all cases (there were multiple bugs, but this also breaks the API)
- Use red ABB logo by default, instead of black/white (which is still available though, through a boolean prop)
- Finalize radial Gauge styling (it had a lot of visual bugs)
- Fix TabControl container styling to make it work properly when used as a direct child of a flex-container
  - This is a workaround for a flexbox quirk
- Replace TSLint with ESLint (as per Typescript team new recommendation), and fix 300+ linter warnings/errors

#### Enhancements:

- Checkbox now accepts custom data as prop, which is then passed as an argument to onClick-handler (eases management of multiple checkboxes on a list)
- MenuItem now has `onSelect` prop, which is called when the menu item is selected
  - This is for convenience, since earlieronly the parent Menu had (and still has) a common onSelect-handler
- Add visual styles for error/ok states on Dropdown
- Add async validation API to Input component, detached from the value changing callback
- Add minimal set of re-usable CSS helper classes (mostly just the mechanism, actual styling classes will be added later)
- Popup can be disabled (new prop)
- Remove 'experimental-component' messages from a few components

---

## v0.2.1 (19-09-2019)

#### Bug fixes:

- Collapsible component had a runtime component validity check, which was causing a crash on production builds; check is now fixed

---

## v0.2.0 (17-09-2019)

#### Breaking changes:

- Dialog now has "standardButtonsOnTop" and "standardButtonsOnBottom", instead of just "standardButtons" (so the API was enhanced, but the old prop name was changed)
- Removed obsolete components which were never released as production-ready: Splitter, ProgressIndicator (use LoadingIndicator instead), MeasureBar (use Gauge instead)
- Button, ToggleButton: change prop "size" name to "sizeClass" in props
- Button, ToggleButton: use term "medium" for medium size, instead of "normal" (for consistency)
- Slider input has been seperated into 'value' for single type and 'values' for double type

#### Bug Fixes:

- Misc Notification API bug fixes: added onClose- and onClick-events, removed standardButtons (never used)
- Icon color now defaults to whatever text-color the parent has (according to CSS cascading rules)
- Tooltip now shows the arrow properly depending upon whether it is placed above or below the container
- Many other smaller fixes on component visual look and feel
-

#### Enhancements:

- Added Spinner component, as a lighweight alternative to LoadingIndicator
- Login dialog accepts children, which will be rendered in the footer area (separate 'footerText' prop will be removed after a while)
- Button component can be used as a link (just add href-attribute)
- Radiobuttons can be laid out also horizontally (only vertical layout was available previously)
- Black color variation for ToggleButton.
- Added Gauge component (bar and radial)
- Dialog StandardButtons now accept icons as well
- Loading indicator dark theme (to be done for Angular)
- Slider now supports ticksmarks (automatically spread and custom positions)
- Allow icons in dialog standard buttons
- Implement linear style Gauge

---

## v0.1.0 (31-05-2019)

#### Breaking changes:

- Black ABB stripe is no more black, but white in light theme and dark in dark theme. Plus it's taller, changed from 24px to 32px. No API changes though.
- Checkbox API changed to not report anymore old or new state
  - Because the application should keep that in its state, and perform the change logic (i.e. move from unchecked to indeterminate to checked, and back)
- Input component validation attributes have been changed, to be more logical and flexible
- Button types have changed: existing type names have been changed (e.g. discreet --> discreet-blue, primary --> primary-blue) and new types have been added (e.g. ghost)
- Due to above, all components accepting buttons as attributes (Dialog, MessageDialog, Notification) have changes in interfaces regarding button type names
- Button has alternative pill-shape (though old rectangular shape with rounded corners is still default)
- Left pane has 4 modes (full, compact, thumbs, hidden), instead of 2 (full, hidden), and the collapsing API has been refactored

#### Bug Fixes:

- Many fixes on component visuals

#### Enhancements:

- Collapsible has ability to show checkbox before the title
- Simple Spinner component, to be used where full LoadingIndicator is too big/complex
- Left pane collapse/expand icon is configurable
- Button accepts "isLoading", positioning above Spinner component into it, and making it disabled
- Input component can be used as a textarea, with multiple lines of text
- Icon color can be specified through its API
- Input has new alternative visual style: discreet
-

---

## v0.0.39 (15-04-2019)

#### Breaking changes:

- RadioGroup parameter rename from 'defaultValue' --> 'value'
- CollapsibleContainer selected state is now controlled
  - Thus it now takes the selected item as a single Collapsible component, or an array of those (i.e. it does _not_ keep track of selected values by itself)

#### Bug Fixes:

- All component props now use the Typescript v3 supported and recommended type annotations for defaultProps
  - This makes editor autocompletion work properly for required/optional components
- Components work properly with hot-module-replacement
  - Strongly tied component hierarchies like ToggleButtonGroup and RadioGroup were either crashing or not rendering properly
- All components now work properly also without a global CSS reset
- Fallback implementation of LoadingIndicator for IE and Edge provided

#### Enhancements:

- All component interfaces are now properly documented
- Checkboxes and Radiobuttons have two size classes, small/normal
- AboutBox accepts now content in a more generic way
- Change all components to accept a few basic HTML attributes (id, className, style), and apply those to the root element of the component
- On CollapsibleContainer, multiple elements can be marked as selected at the same time

---

## v0.0.0 - v.0.0.38

_No changelog for these releases._

---
