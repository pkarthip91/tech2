/**
 * Some components are published as experimental and/or in-progress, for preview.
 * On the other hand, some components will be removed at some point, and have
 * been marked as deprecated.
 *
 * These utility functions are used to show notifications about those components
 * in the console, without flooding the console (show only once per component).
 *
 * If you want to disable the notifications for all components, use
 * functions `suppressExperimentalWarnings` and `suppressDeprecationWarnings`.
 *
 * If you want to disable the notifications for some specific component, use the
 * same functions, but with additional parameter specifying the component name.
 */
export declare function suppressDeprecationWarnings(suppress?: boolean, componentName?: string): void;
export declare function showDeprecationWarning(componentName: string, text?: string): void;
export declare function suppressExperimentalWarnings(suppress?: boolean, componentName?: string): void;
export declare function showExperimentalWarning(componentName: string, text?: string): void;
