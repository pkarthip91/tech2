/// <reference types="react" />
declare let ThemeContext: React.Context<string>;
export { ThemeContext };
