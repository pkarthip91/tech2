import * as styles from '../../../../styles/src/Helpers/Helpers.css';
export declare const cssHelpers: typeof styles;
export default cssHelpers;
