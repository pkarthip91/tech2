import * as React from 'react';
import { HtmlAttributes } from '../../internalUtils/HtmlAttributes';
export declare namespace Utils {
    interface ResizerProps extends HtmlAttributes {
        /** Fired when user changes the component dimensions. */
        onSizeChange?: (side: 'left' | 'right' | 'top' | 'bottom', width: number, height: number) => void;
        /** Allow horizontal size changes. */
        horizontal: boolean;
        /** Allow vertical size changes, or both */
        vertical: boolean;
    }
    /**
     * Component Resizer, used only internally, for testing component responsiveness.
     * Not exported.
     */
    class Resizer extends React.Component<ResizerProps> {
        static defaultProps: {
            horizontal: boolean;
            vertical: boolean;
        };
        private side;
        private left;
        private right;
        private top;
        private bottom;
        private containerRef;
        private rootRef;
        constructor(props: ResizerProps);
        render(): JSX.Element;
        private topDragStart;
        private leftDragStart;
        private rightDragStart;
        private bottomDragStart;
        private resetHeight;
        private resetWidth;
        private startDrag;
        private drag;
        private endDrag;
        private handleResize;
    }
}
export default Utils;
