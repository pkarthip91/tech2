import * as React from 'react';
export interface HtmlAttributes {
    /** HTML standard attribute, applied to component root element.  */
    id?: string;
    /** HTML standard attribute. Additional class name(s) applied to component root element.  */
    className?: string;
    /** HTML standard attribute. Custom styles applied to component root element.  */
    style?: React.CSSProperties;
}
export declare function getHtmlAttributes(props: HtmlAttributes): {
    id?: string;
    style?: React.CSSProperties;
};
