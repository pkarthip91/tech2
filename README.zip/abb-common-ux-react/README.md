# Introduction
Contains React implementation for CommonUX components.

Components are styled with PostCSS (located in `../styles`). This folder
contains React-specific build scripts for those as well.

Instead of being Javascript, the codebase is implemented fully in Typescript,
which we recommend all teams to use also in their projects. However, components
can be used also in plain Javascript project. Check out example applications
in path `../examples/react` for instructions on how to include the library in
your product, and how to use components.

For component-specific API examples, browse to <https://commonux.abb.com> and
take a look at the usage examples in Components-section. In the bottom of each
component-page you can find the component API documentation (i.e. props).


# Component API design principles
Instead of being *uncontrolled* all components are *controlled* as much as
possible. Read more about this from:
<https://reactjs.org/docs/uncontrolled-components.html>.

Being controlled, many components are slightly more cumbersome to use at first,
but soon prove to be more flexible. For example, a Checkbox, being just placed
on the application, will not work out of the box. Instead, you *must* always
bind click handlers and provide value to it manually.

# Build and Test

Local build:
```
npm install
npm run build
```

Generate local NPM package (similar to publishing to NPM):
```
npm run doLocalPublish
```

For actual package delivery, ABB internal NPM registry is used, and only the
core development team has publish righs.

Do NOT publish this package to public NPM!


# Contribute
Feel free to send Merge Requests to this repo in Codebits, but make sure that
the code still compiles after your changes. Additionally, build and test either
React or Angular example application (or preferably both, located in
`../examples/`), to check that everything still looks fine.

Please note that the core development team reserves the right to reject your
changes, if they are not in line with the CommonUX design principles, or they
would be too specific for your use case (we try to provide as generic component
implementations as possible, and provide product-specific customizations through
rich component interfaces).

For smaller changes, just send the Merge Request. However, for anything larger,
please consult the core team first so that we can align the work together with
our plans and guidelines.

# Contact
When in doubt, please email the core development team at <commonux@abb.com>(our
team mailbox), or use Codebits issue reporting tool.


