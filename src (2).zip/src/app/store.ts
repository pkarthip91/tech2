import { configureStore, ThunkAction, Action } from '@reduxjs/toolkit';
import authReducer from '../features/auth/reducer/AuthSlice';
import mappingCMParameterReducer from '../features/common/reducers/mappingCMParameterSlice';
import mappingParameterReducer from '../features/common/reducers/mappingParameterSlice';
import plantviewReducer from '../features/plantview/reducer/PlantViewSlice';
import unitviewReducer from '../features/unitview/reducer/UnitViewSlice';
import homeReducer from '../features/home/reducer/HomeSlice'
import unitviewPCSDdataReducer from '../features/unitview/reducer/UnitViewPCSDdataSlice'
import cbmRead from '../features/cbmRead/reducer/CbmReadSlice'
import cbmWrite from '../features/cbmWrite/reducer/CbmWriteSlice'
import dbList from '../features/common/header/setting/reducer/DbListSlice'
import informationBar from '../features/informationBar/reducer/InformationBarSlice'
import importXML from '../features/importXML/reducer/ImportXMLFileUploadSlice'
import importXMLHistory from '../features/importXML/reducer/ImportXMLHistorySlice'
import importXMLHistoryDelete from '../features/importXML/reducer/ImportXMLHistoryDeleteSlice'
import importXMLInsert from '../features/importXML/reducer/ImportXMLInsertSlice'
import createUmPopupData from '../features/createUM/reducer/CreateUmPopuoDataSlice';
import createUmHistory from 'features/createUM/reducer/CreateUmHistorySlice';
import createUmInsert from 'features/createUM/reducer/CreateUmInsertSlice';
import createUmHistoryDelete from 'features/createUM/reducer/CreateUmHistoryDeleteSlice';

export const store = configureStore({
  reducer: {
    auth: authReducer,
    home: homeReducer,
    plantview: plantviewReducer,
    unitview: unitviewReducer,
    mappingParameterView: mappingParameterReducer,
    mappingCMParameterView: mappingCMParameterReducer,
    unitviewPCSDdata: unitviewPCSDdataReducer,
    cbmRead,
    cbmWrite,
    dbList,
    informationBar,
    importXML,
    importXMLHistory,
    importXMLHistoryDelete,
    importXMLInsert,
    createUmPopupData,
    createUmHistory,
    createUmInsert,
    createUmHistoryDelete
  },
  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware({
      serializableCheck: false
    })
});

export type AppDispatch = typeof store.dispatch;
export type RootState = ReturnType<typeof store.getState>;
export type AppThunk<ReturnType = void> = ThunkAction<
  ReturnType,
  RootState,
  unknown,
  Action<string>
>;
