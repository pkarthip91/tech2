const appConfig: any = {
  lawText: 'This is a private system. Do not attempt to logon unless you are an authorized user. ' +
    'Any authorized or unauthorized access and use may be monitored and can result in ' +
    'criminal or civil prosecution under applicable law.',
  productName: 'Cafe: Fe Tool',
  productSubName: 'Login to use this tool!'
}

export { appConfig }