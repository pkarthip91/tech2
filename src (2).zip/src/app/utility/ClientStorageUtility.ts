class ClientStorageUtility {
  constructor(private storageLocation: Storage = localStorage) { }
  add = (key: string, value: string) => {
    this.storageLocation.setItem(key, value)
  }

  remove = (key: string) => {
    this.storageLocation.removeItem(key)
  }

  get = (key: string): string | null => {
    return this.storageLocation.getItem(key)
  }

}
const ClientStorage = new ClientStorageUtility()
export { ClientStorage }