import axios from "axios";

var httpClient = axios.create({
  baseURL: "https://localhost:7092/api",
  headers: {
    "Content-type": "application/json"
  }
});

httpClient.interceptors.response.use(

  function (response) {
    return response;
  },
  function (error) {
    console.log('Api server error->', error)
    let res = error.response;
    if (res.status === 401) {
      window.location.href = 'http://localhost:3000/login?token_expired=true';
    }
    if (res.status === 400) {
      return res
    }
    return Promise.reject(error);
  }
);

export { httpClient }