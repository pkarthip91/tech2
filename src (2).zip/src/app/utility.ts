
const randomString = (count: number = 10): string => Math.random().toString(36).substring(count);

const dateTimeFormatter = (dateTime: Date | null): string => {
  if (dateTime) {
    var d = new Date(dateTime);
    return d.toLocaleString("en-US");
  } else {
    return ''
  }
}
export {
  randomString,
  dateTimeFormatter
}