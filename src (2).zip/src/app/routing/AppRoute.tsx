import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { LoginComponent } from '../../features/auth/login/components/login';
import { Home } from '../../features/home';
import { ProtectedRoute } from './ProtectedRoute';

export const AppRoute = () => {
  return (
    <>
      <Router>
        <Routes>
          <Route path="/login" element={<LoginComponent />}></Route>
          <Route element={<ProtectedRoute />}>
            <Route path="/" element={<Home />}>
            </Route>
          </Route>
        </Routes>
      </Router>
    </>
  );
}