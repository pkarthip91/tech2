import { LoginScreen } from '@abb/abb-common-ux-react'
import { useSelector } from 'react-redux'
import { NavLink, Outlet } from 'react-router-dom'

export const ProtectedRoute = () => {

  const { userInfo, userToken } = useSelector((state: any) => state.auth)

  //TO Do - In-line styles should be removed once final UI developed
  if (!(userInfo?.userName && userToken)) {

    return (
      <div style={{ width: '100%', display: 'flex', justifyContent: 'center' }} >
        <LoginScreen
          productName="Unauthorized Access"
          loading={false}
          showDefaultFields={false}
          showLoginButton={false}
          customContent={() => {
            return (
              <span>
                <NavLink to='/login'>Login</NavLink> to gain access
              </span>
            );
          }}
        />
      </div>
    )
  }

  return <Outlet />
}