class LoggerService {
  constructor() { }
  info = (label: string, data: object | null = null) => {
    console.info(label, data)
  }

  warn = (label: string, data: object | null = null) => {
    console.warn(label, data)
  }

  error = (label: string, data: object | null = null) => {
    console.error(label, data)
  }

}
const Logger = new LoggerService()
export { Logger }