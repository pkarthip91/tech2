export const appConstant: any = {
  USER_DATA: 'userData'
}