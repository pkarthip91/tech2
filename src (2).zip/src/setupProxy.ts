import { createProxyMiddleware } from 'http-proxy-middleware';
import * as dotenv from 'dotenv'

module.exports = (app: any) => {
  app.use(createProxyMiddleware('/api', {
    target: 'http://localhost:4000/',
    changeOrigin: true,
    pathRewrite: { '^/api': '' }
  })
  );
}

// module.exports = (app: any) => {
//   ;
//   dotenv.config()

//   const apiUrl = process.env.CAFE_FE_API_URL

//   let CAFEProxy = createProxyMiddleware({
//     target: apiUrl,
//     changeOrigin: true,
//     pathRewrite: {
//       '^/api': ''
//     }
//   })

//   app.use('/', CAFEProxy)

// };