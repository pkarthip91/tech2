import { createSlice } from '@reduxjs/toolkit';
import { cbmReadDataAction } from '../actions/CbmReadDataActions';
import { CBM_READ_REDUCER } from '../CbmReadConstant';

interface IPlantViewState {
  loading: boolean,
  cbmReadData: string,
  error: string | null
}
const initialState: IPlantViewState = {
  loading: false,
  cbmReadData: '',
  error: null
}

export const cbmReadSlice = createSlice({
  name: `${CBM_READ_REDUCER}`,
  initialState,
  reducers: {
  },
  extraReducers: (builder) => {
    builder
      .addCase(cbmReadDataAction.pending, (state) => {
        state.loading = true;
      })
      .addCase(cbmReadDataAction.fulfilled, (state, { payload }: any) => {
        state.loading = false;
        state.cbmReadData = payload;
        state.error = null;
      })
      .addCase(cbmReadDataAction.rejected, (state, { payload }: any) => {
        state.loading = false;
        state.error = payload
      });
  },
});
export default cbmReadSlice.reducer;
