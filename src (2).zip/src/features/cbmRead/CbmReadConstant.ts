export const CBM_READ_REDUCER = 'cbmread'
export const CBM_READ_DATA_ACTION = 'cbmreadDataAction'
export const CBM_READ_DATA_ACTION_FAIL = 'CBM read failed!'
