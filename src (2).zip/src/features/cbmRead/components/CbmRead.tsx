import { useState } from 'react';
import { useAppSelector, useAppDispatch } from '../../../app/hooks';
import { cbmReadDataAction } from '../actions/CbmReadDataActions';



export const CbmRead = () => {
  const { userToken } = useAppSelector((state: any) => state.auth)
  const dispatch = useAppDispatch();
  const [libPath, setLibPath] = useState('')

  const { loading, error, cbmReadData } = useAppSelector((state: any) => state.cbmRead)

  const onChangeLibPath = (event: any) => {
    setLibPath(event.target.value);
  }

  const onSubmitLibPath = (event: any) => {
    if (libPath)
      dispatch(cbmReadDataAction({ userToken, libPath }));
    else
      alert('Please provide lib path!')
    event.preventDefault();
  }
  return (
    <div>
      <h3>CBM Read</h3>
      {loading ? "loading..." :
        (<div>
          <form onSubmit={(e) => onSubmitLibPath(e)}>
            <label>
              libPath<span style={{ 'color': 'red' }}>*</span>:
              <input type="text" name="libpath" value={libPath} onChange={(e) => onChangeLibPath(e)} />
            </label>
            <input type="submit" value="Submit" />
          </form>
        </div>)}
      {!loading ? (error ? <div style={{ 'color': 'red' }}>{error}</div> : <div style={{ 'overflow': 'auto', 'height': '500px' }}>{cbmReadData}</div>) : <></>}
    </div>
  );
}
