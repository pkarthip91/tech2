import { createAsyncThunk } from "@reduxjs/toolkit";
import { Logger } from "../../../app/common/LoggerService";
import { CBM_READ_DATA_ACTION, CBM_READ_DATA_ACTION_FAIL, CBM_READ_REDUCER } from "../CbmReadConstant";
import { cbmReadService } from "../service/CbmReadApiService";

export const cbmReadDataAction = createAsyncThunk(
  `${CBM_READ_REDUCER}/${CBM_READ_DATA_ACTION}`,
  async ({ userToken, libPath }: any, { rejectWithValue }: any) => {
    let result = null
    try {
      const response = await cbmReadService(userToken, libPath)
      Logger.info('cbmread api- ', response)
      if (response.status === 200 && response.data) {
        result = response.data
      } else {
        result = rejectWithValue(`${CBM_READ_DATA_ACTION_FAIL}`)
      }
    } catch (error: any) {
      Logger.error(`${CBM_READ_DATA_ACTION_FAIL}`)
      if (error.message || error.response.data) {
        result = rejectWithValue(error.message || error.response.data)
      } else {
        result = rejectWithValue(`${CBM_READ_DATA_ACTION_FAIL}`)
      }
    }

    return result
  }
)
