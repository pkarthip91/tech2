import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { childViews } from '../HomeModels';
import { HOME_REDUCER } from '../HomeConstant';

interface IHomeState {
  loading: boolean,
  currentView: childViews,
  currentDB: string | null,
  error: string | null,
  clickedItem: any,
  filterTreeNodeSelection: string
}
const initialState: IHomeState = {
  loading: false,
  currentView: childViews.plantview,
  currentDB: null,
  error: null,
  clickedItem: null,
  filterTreeNodeSelection: 'ALL'
}

export const homeSlice = createSlice({
  name: `${HOME_REDUCER}`,
  initialState,
  reducers: {
    selectedViewAction: (state, action: PayloadAction<childViews>) => {
      state.currentView = action.payload
    },
    selectedCurrentDBAction: (state, action: PayloadAction<string>) => {
      state.currentDB = action.payload
    },
    homeClickedAction: (state, action: PayloadAction<any>) => {
      state.clickedItem = action.payload
    },
    filterTreeNodeSelectionAction: (state, action: PayloadAction<string>) => {
      state.filterTreeNodeSelection = action.payload
    }
  }
});
export const { selectedViewAction, selectedCurrentDBAction, homeClickedAction, filterTreeNodeSelectionAction } = homeSlice.actions;
export default homeSlice.reducer;
