import { Dropdown, DropdownOption } from "@abb/abb-common-ux-react"
import { useState } from "react";
import { AppHeaderToolbarDropdownProps } from "./AppToolbarModel";
import { useAppDispatch, useAppSelector } from "../../../app/hooks";
import { filterTreeNodeSelectionAction } from "../reducer/HomeSlice";
import React from "react";

export const FilterTreeNode = () => {
  const { filterTreeNodeSelection } = useAppSelector(state => state.home)
  const opts = ['ALL', 'UM', 'EM', 'SIM'].map((val, i) => ({ value: val, label: val, isNew: false }));
  const dispatch = useAppDispatch()
  const getSelectedObject = () => {
    try {
      return opts.filter(o => o.value == filterTreeNodeSelection)[0]
    } catch {
      return opts[0]
    }
  }
  const [selectedVlue, setSelectedValue] = useState([getSelectedObject()]
  )

  const onChange = (selection: any) => {
    setSelectedValue(selection);
    dispatch(filterTreeNodeSelectionAction(selection[0].value))
  }

  return (
    <div>
      <Dropdown {...new AppHeaderToolbarDropdownProps(selectedVlue, onChange)} >
        {opts.map(o =>
          <DropdownOption
            key={o.value}
            label={o.label}
            value={o.value}
            disabled={false}
          />
        )}
      </Dropdown>
    </div>
  )
}