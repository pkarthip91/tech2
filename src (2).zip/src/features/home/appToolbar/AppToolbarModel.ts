import { DropdownProps, ValidationState } from "@abb/abb-common-ux-react";

export class AppHeaderToolbarDropdownProps implements DropdownProps {
  public createOptionText: string = 'dfdsfdsfds'
  constructor(
    public value: Array<{ value: any; label?: string; isNew?: boolean; }> = [],
    public onChange: (selection: Array<{ value: any; label: string; isNew: boolean; }>) => void,
    public sizeClass: 'small' | 'medium' | 'large' = 'small',
    public showValidationBarWhenValid: boolean = false,
    public showValidationIconWhenValid: boolean = false,
    public showValidationBarWhenInvalid: boolean = false,
    public showValidationIconWhenInvalid: boolean = false,
    public validationState: ValidationState | undefined | null = null,
    public multiselect?: boolean,
    public searchable: boolean = true,
    public placeholder?: string,
    public label?: string,
    public description?: string,
    public clearable: boolean = true,
    public disabled?: boolean,
    public allowAdd: boolean = false,
    public noBorders?: boolean,
    public clearOnEscape: boolean = true,
    public edited?: boolean
  ) { }
}