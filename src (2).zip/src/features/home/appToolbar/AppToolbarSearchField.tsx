import { Dropdown, DropdownOption } from "@abb/abb-common-ux-react"
import { useState } from "react";
import { AppHeaderToolbarDropdownProps } from "./AppToolbarModel";

export const AppToolbarSearchField = () => {
  const opts = Array.apply(null, Array(30)).map((val, i) => ({ value: i, label: `Acc_Latest_Aqtk124SIM  #${i}`, isNew: false }));
  const [selectedVlue, setSelectedValue] = useState([opts[2]])
  const onChange = (selection: any) => {
    setSelectedValue(selection)
  }
  return (
    <>
      <Dropdown {...new AppHeaderToolbarDropdownProps(selectedVlue, onChange)} >
        {opts.map(o =>
          <DropdownOption
            key={o.value}
            label={o.label}
            value={o.value}
            disabled={false}
          />
        )}
      </Dropdown>
    </>
  )
}