import { AppTopNaviItemProps, MenuProps, SubMenuProps } from "@abb/abb-common-ux-react";

export enum childViews {
  plantview = 1,
  unitview,
  cbmread,
  cbmwrite
}

export class HeaderMenuProps implements MenuProps {
  constructor(
    public monochrome: boolean = false,
    public trigger: 'click' | 'hover' | 'none' = 'hover',
    public onClick?: (event: React.MouseEvent<HTMLElement>) => void,
    public onSelect?: (item: { text: string; id: string; }) => void,
    public onLostFocus?: () => void,
    public alignToParent: 'left' | 'right' = 'left'
  ) {
    onLostFocus = this.onLostFocus
  }
}

export class HeaderMenuAppTopNaviItemProps implements AppTopNaviItemProps {
  constructor(
    public text: string,
    public icon: string,
    public active: boolean,
    public disabled: boolean = false,
    public hasMenu: boolean = true,
    public onClick?: (event: React.MouseEvent<HTMLElement>) => void | undefined,
    public onLostFocus?: (event: React.FocusEvent<HTMLElement>) => void | undefined,
    public className?: string
  ) {
    this.text = text
    this.icon = icon
    this.active = active
    this.onClick = onClick ? onClick : undefined
    this.onLostFocus = onLostFocus ? onLostFocus : undefined
    this.className = className ? className : ''
  }
}

export class HeaderMenuSubMenuProps implements SubMenuProps {
  constructor(
    public text: string,
    public icon?: string,
    public disabled?: boolean,
    public selected?: boolean,
    public onMouseLeave?: () => void
  ) {
    this.text = text
  }
}

