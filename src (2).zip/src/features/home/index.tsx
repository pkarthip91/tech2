import { Home } from "./components/Home";

export {
  Home
}