import {
  Menu,
  MenuItem,
  AppTopNaviItem,
  AppMainContent,
  AppContainer,
  SidebarNaviTile,
  SidebarNavi,
  Icon,
  AppLeftPane,
  AppTopNavi,
  SubMenu,
} from '@abb/abb-common-ux-react';
import React, { useEffect, useState } from 'react';
import { useAppDispatch, useAppSelector } from '../../../app/hooks';
import { HeaderComponent } from '../../common/header';
import { PlantView } from '../../plantview';
import { UnitView } from '../../unitview';
import { dBListAction } from '../../common/header/setting/actions/DbListDataActions';
import { childViews, HeaderMenuAppTopNaviItemProps, HeaderMenuProps, HeaderMenuSubMenuProps } from './../HomeModels';
import plantIcon from '../../../../src/assest/img/ABB_Plant.png';
import IO from '../../../../src/assest/img/IOAllocation 2.png';
import ABBGraphics from '../../../../src/assest/img/ABB_graphics.png';
import ABBSimiulation from '../../../../src/assest/img/simiulation.png';
import { homeClickedAction, selectedCurrentDBAction, selectedViewAction } from "../../../features/home/reducer/HomeSlice"
// import { AppToolbarSearchField } from './../appToolbar/AppToolbarSearchField';
import { InformationBar } from '../../informationBar';
// import { FilterTreeNode } from './../appToolbar/FilterTreeNode';
// import { InputXML } from '../../importXML/components/InputXML';
import { IDbList, IDbListState } from '../../common/header/setting/interfacce';


// import { CCollapse, CButton } from '@coreui/bootstrap-react';
// import 'bootstrap/dist/css/bootstrap.min.css'



export const Home = () => {
  const dispatch = useAppDispatch();
  const { userToken } = useAppSelector((state: any) => state.auth)
  const { currentView } = useAppSelector((state: any) => state.home)
  const [activeItem, setActiveItem] = React.useState('(blank)');
  const { selectedUnit } = useAppSelector((state: any) => state.plantview)
  const { currentDB } = useAppSelector((state: any) => state.home)
  const { dbList } = useAppSelector<IDbListState>((state: any) => state.dbList)
  const [visible, setVisible] = useState(true)

  useEffect(() => { dispatch(dBListAction(userToken)) }, []);
  useEffect(() => {
    (currentView != childViews.plantview) &&
      dispatch(selectedViewAction(childViews.plantview))
  }, [currentDB]);

  useEffect(() => {
    if (!currentDB && dbList.length) {
      const defaultDB = dbList.find(db => db.default) || dbList[0]
      dispatch(selectedCurrentDBAction(defaultDB.dbName))
    }
  }, [dbList, currentDB]);

  const renderView = (view: childViews) => {
    switch (view) {
      case childViews.plantview:
        return <PlantView />
      case childViews.unitview:
        return <UnitView />
      default:
        return <PlantView />
    }
  }

  const handleViewChange = (view: childViews): any => {
    if (view === childViews.unitview && !(selectedUnit?.getPcsDdataKey())) {
      alert('Please select unit first!')
      view = childViews.plantview
    }
    dispatch(selectedViewAction(view))
  }

  let homeDiv: React.RefObject<HTMLDivElement> = React.createRef<HTMLDivElement>();

  return (
    <div ref={homeDiv} onClick={(e) => dispatch(homeClickedAction(e.target))}>
      <HeaderComponent />
      <AppContainer>
        <div className='AppContent'>
          <AppLeftPane>
            <SidebarNavi>
              <div className='tooltip-menu'>
                <SidebarNaviTile >
                  <span className="icon-16">
                    <img src={plantIcon} onClick={() => handleViewChange(childViews.plantview)} className="fetoolImg" alt="FETool" />
                  </span>
                  <span className="tooltipmenu-text">Home</span>
                </SidebarNaviTile>
              </div>

              <div className='tooltip-menu'>
                <SidebarNaviTile>
                  <span className="icon-16">
                    <Icon name="abb/tree-view" sizeClass={'small'} />
                  </span>
                  <span className="tooltipmenu-text">Tree</span>
                </SidebarNaviTile>
              </div>

              <div className='tooltip-menu'>
                <SidebarNaviTile >
                  <span className="icon-16">
                    <img src={IO} alt="FETool" />
                  </span>
                  <span className="tooltipmenu-text">Hardware</span>
                </SidebarNaviTile>
              </div>

              <div className='tooltip-menu'>
                <SidebarNaviTile >
                  <span className="icon-16">
                    <img src={ABBGraphics} alt="ABB Graphics" />
                  </span>
                  <span className="tooltipmenu-text">Graphics</span>
                </SidebarNaviTile>
              </div>

              <div className='tooltip-menu'>
                <SidebarNaviTile >
                  <span className="icon-16">
                    <img src={ABBSimiulation} alt="Simulation" />
                  </span>
                  <span className="tooltipmenu-text">Simulation</span>
                </SidebarNaviTile>
              </div>
            </SidebarNavi>
          </AppLeftPane>

          <div className="component-container">


            <div className={visible ? "currentView-main-height" : "currentView-main-height-collapse"}>
              {renderView(currentView)}
            </div>


            <div className='statusbar-main-section'>
              <div onClick={() => setVisible(!visible)}
                className={visible ? "collablebtn down-arrow" : "collablebtn btn-static up-arrow"}
              ></div>
              {visible && <div>
                <InformationBar />
              </div>
              }
            </div>
          </div>
        </div>


      </AppContainer>
    </div>
  )
}
