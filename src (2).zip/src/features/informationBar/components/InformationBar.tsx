import { useSelector } from "react-redux"
import { IInformationType } from '../interfaces/InformationInterface'
import React from "react"


export const InformationBar = () => {
  const { information } = useSelector((state: any) => state.informationBar)
  return (
    <>
      <div className='status-bar'>
        <ul>
          {information && information.map(((info: IInformationType, index: number) =>
            info.message && <li key={index}>
              <h5>{info.message}</h5>
              <p>{info.dateTime}</p>
            </li>
          ))}
        </ul>
      </div>
    </>
  )
}