export const INFORMATION_BAR_REDUCER = 'informationBar'
export const INFORMATION_BAR_ACTION = 'informationBarAction'
