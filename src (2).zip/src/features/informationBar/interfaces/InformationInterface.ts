export interface IInformationType { dateTime?: string | undefined, message: string, isNewGropu?: boolean }

export interface IInformationBar {
  information: Array<IInformationType>
}