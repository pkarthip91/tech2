import { PayloadAction, createSlice } from '@reduxjs/toolkit';
import { INFORMATION_BAR_ACTION, INFORMATION_BAR_REDUCER } from '../InformationBarConstant';
import { IInformationBar, IInformationType } from '../interfaces/InformationInterface'

const getCurrentDataTime = () => {
  return new Date().toLocaleString()
}
const initialState: IInformationBar = {
  information: new Array<IInformationType>()
}

export const InformationBarSlice = createSlice({
  name: `${INFORMATION_BAR_REDUCER}`,
  initialState,
  reducers: {
    setInformationAction: (state, action: PayloadAction<IInformationType>) => {
      if (!action.payload.dateTime) action.payload.dateTime = getCurrentDataTime()
      if (action.payload.isNewGropu != false) action.payload.isNewGropu = true
      if (action.payload.isNewGropu) {
        state.information = [action.payload]
      } else {
        state.information.unshift(action.payload)
      }
    }
  }
});
export const { setInformationAction } = InformationBarSlice.actions;
export default InformationBarSlice.reducer;
