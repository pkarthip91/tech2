import { InformationBar } from './components/InformationBar'
export {
  InformationBar
}