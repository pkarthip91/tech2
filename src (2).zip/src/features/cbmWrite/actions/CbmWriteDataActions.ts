import { createAsyncThunk } from "@reduxjs/toolkit";
import { Logger } from "../../../app/common/LoggerService";
import { CBM_WRITE_DATA_ACTION, CBM_WRITE_DATA_ACTION_FAIL, CBM_WRITE_REDUCER } from "../CbmWriteConstant";
import { cbmWriteService } from "../service/CbmWriteApiService";

export const cbmWriteDataAction = createAsyncThunk(
  `${CBM_WRITE_REDUCER}/${CBM_WRITE_DATA_ACTION}`,
  async ({ userToken, libPath, libXML }: any, { rejectWithValue }: any) => {
    let result = null
    try {
      const response = await cbmWriteService(userToken, libPath, libXML)
      Logger.info('cbm write api- ', response)
      if (response.status === 200 && response.data) {
        result = response.data
      } else {
        result = rejectWithValue(`${CBM_WRITE_DATA_ACTION_FAIL}`)
      }
    } catch (error: any) {
      Logger.error(`${CBM_WRITE_DATA_ACTION_FAIL}`)
      if (error.message || error.response.data) {
        result = rejectWithValue(error.message || error.response.data)
      } else {
        result = rejectWithValue(`${CBM_WRITE_DATA_ACTION_FAIL}`)
      }
    }
    return result
  }
)
