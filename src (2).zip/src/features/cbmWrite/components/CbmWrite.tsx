import { ChangeEvent, useState } from 'react';
import { useAppSelector, useAppDispatch } from '../../../app/hooks';
import { cbmWriteDataAction } from '../actions/CbmWriteDataActions';



export const CbmWrite = () => {
  const { userToken } = useAppSelector((state: any) => state.auth)
  const dispatch = useAppDispatch();
  const [libPath, setLibPath] = useState<string>('')
  const [libXML, setlibXML] = useState<File>();

  const { loading, error, cbmWriteData } = useAppSelector((state: any) => state.cbmWrite)

  const onChangeLibPath = (event: any) => {
    setLibPath(event.target.value);
  }

  const handleFileChange = (e: ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      setlibXML(e.target.files[0]);
    }
  };

  const onSubmit = (event: any) => {
    if (libPath && libXML)
      dispatch(cbmWriteDataAction({ userToken, libPath, libXML }));
    else
      alert('Please provide lib path & file!')
    event.preventDefault();
  }
  return (
    <div>
      <h3>CBM Write</h3>
      {loading ? "loading..." :
        (<div>
          <form onSubmit={(e) => onSubmit(e)}>
            <label>
              libPath<span style={{ 'color': 'red' }}>*</span>:
              <input type="text" name="libpath" value={libPath} onChange={(e) => onChangeLibPath(e)} />
            </label>
            <label>
              libXML<span style={{ 'color': 'red' }}>*</span>:
              <input type="file" name="libxml" onChange={(e) => handleFileChange(e)} />
            </label>
            <input type="submit" value="Submit" />
          </form>
        </div>)}
      {!loading ? (error ? <div style={{ 'color': 'red' }}>{error}</div> : <div>{cbmWriteData} </div>) : <></>}
    </div>
  );
}
