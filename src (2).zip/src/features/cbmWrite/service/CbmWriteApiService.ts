import { httpClient } from '../../../app/api/middlewareSecurity'

export const cbmWriteService = (userToken: string, libPath: string, libXML: File) => {
  return httpClient.post(`/CBM/diagram`, { libPath, libXML }, {
    headers: {
      "Authorization": `Bearer ${userToken}`,
      'Content-Type': 'multipart/form-data'
    }
  })
}