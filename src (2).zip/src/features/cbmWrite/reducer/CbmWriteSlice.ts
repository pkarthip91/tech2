import { createSlice } from '@reduxjs/toolkit';
import { cbmWriteDataAction } from '../actions/CbmWriteDataActions';
import { CBM_WRITE_REDUCER } from '../CbmWriteConstant';

interface IPlantViewState {
  loading: boolean,
  cbmWriteData: string,
  error: string | null
}
const initialState: IPlantViewState = {
  loading: false,
  cbmWriteData: '',
  error: null
}

export const cbmWriteSlice = createSlice({
  name: `${CBM_WRITE_REDUCER}`,
  initialState,
  reducers: {
  },
  extraReducers: (builder) => {
    builder
      .addCase(cbmWriteDataAction.pending, (state) => {
        state.loading = true;
      })
      .addCase(cbmWriteDataAction.fulfilled, (state, { payload }: any) => {
        state.loading = false;
        state.cbmWriteData = payload;
        state.error = null;
      })
      .addCase(cbmWriteDataAction.rejected, (state, { payload }: any) => {
        state.loading = false;
        state.error = payload
      });
  },
});
export default cbmWriteSlice.reducer;
