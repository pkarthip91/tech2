export const CBM_WRITE_REDUCER = 'cbmwrite'
export const CBM_WRITE_DATA_ACTION = 'cbmwriteDataAction'
export const CBM_WRITE_DATA_ACTION_FAIL = 'CBM write failed!'
