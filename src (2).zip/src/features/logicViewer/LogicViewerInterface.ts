export interface INodeData {
  id: number
  name: string,
  template: string
}

export interface IEdgeData {
  fromNode: number
  toNode: number
}

export interface IGraphData {
  nodesSource: INodeData[]
  edgesSource: IEdgeData[]
}

