import { useState } from 'react';
import { LogicViewerGraphComponent } from '../common/yFiles/components/LogicViewerGraphComponent';
import { graphData } from './LogicViewerModel';


export const LogicViewer = () => {

  const [graphState, setGraphState] = useState(graphData);

  return (
    <LogicViewerGraphComponent graphData={graphState} />
  )
}
