import CSS from 'csstype';

export const toolTip: CSS.Properties = {
  boxShadow: '0 2px 4px - 1px rgba(0, 0, 0, 0.2), 0 4px 5px 0 rgba(0, 0, 0, 0.14), 0 1px 10px 0 rgba(0, 0, 0, 0.12)',
  padding: '10px 24px',
  backgroundColor: 'white',
  borderRadius: '4px'
}