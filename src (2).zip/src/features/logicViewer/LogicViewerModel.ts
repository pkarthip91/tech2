import { IGraphData } from "./LogicViewerInterface";

const template = `<rect fill='#ff6c00' stroke='#662b00' stroke-width='1.5' rx='3.5' ry='3.5' width='{TemplateBinding width}' height='{TemplateBinding height}'></rect>
<text transform='translate(10 20)' data-content='{Binding name}' style='font-size:18px;'></text>`;
export var graphData: IGraphData = {
  nodesSource: [
    {
      id: 0,
      name: 'Node 0',
      template: template
    },
    {
      id: 1,
      name: 'Node 1',
      template: template
    },
    {
      id: 2,
      name: 'Node 2',
      template: template
    }
  ],
  edgesSource: [
    {
      fromNode: 0,
      toNode: 1
    },
    {
      fromNode: 0,
      toNode: 2
    }
  ]
}

