import { Button } from "@abb/abb-common-ux-react"
import React, { useEffect, useState } from 'react';
import Data from './Users.json';


const styles = {
  model: {
    display: 'none',
    zIndex: 999,
    left: 0,
    top: 0,
    width: '100%',
    height: '100%',
    overflow: 'auto',
    backgroundColor: 'rgba(0, 0, 0, 0.4)'
  },
  modalContent: {
    backgroundColor: '#fefefe',
    margin: 'auto',
    border: '1px solid #888',
    width: '35%',
    borderRadius: '8px'
  },
  close: {
    color: 'black',
    fontSize: '16px',
    fontWeight: 'bold',
    cursor: 'pointer',
    borderRadius: '100%',
    backgroundColor: 'whitesmoke',
    width: '30px',
    height: '30px',
    marginTop: '-5px'
  }
}



export const ModalPopup = (props: any) => {
  const [userName, setUserName] = useState('');
  const title: string = props.title || 'Modal Popup'
  const body: any = props.children || <></>
  const style: any = props.style || {}

  const ChangeUsername = (e: any) => {
    e.preventDefault();
    setUserName(e.target.value);
    var Mydrop: any = document.getElementById("myDrop");
    Mydrop.classList.add("show");
  }

  const myFunction = () => {
    var Mydrop: any = document.getElementById("myDrop");
    Mydrop.classList.toggle("show");
  }

  const Dopdownlist = (e: any) => {
    setUserName(e.target.innerText);
    var Mydrop: any = document.getElementById("myDrop");
    Mydrop.classList.remove('show');
  }

  return (
    <>
      <div className="model-popup" style={{ ...styles.model, position: 'fixed', display: props.isOpen ? 'flex' : 'none', ...style }}>
        <div className="model-popup-content" style={{ ...styles.modalContent }}>
          <div className="popup-header">
            <span onClick={() => { props.onClose() }} className="close-icon" style={{ ...styles.close, float: 'right' }}>&times;</span>
            <p className="PageTitle"><b>{`${title}`}</b></p>
          </div>

          <div className="popup-body">

            {body}
          </div>
          <div className="popup-footer">
            <Button
              text="Cancel"
              onClick={() => { props.onClose() }}
              sizeClass="small"
              type='discreet-black'
              className="cancle-btn font-small"
            />
            <Button
              text="Save"
              onClick={() => { props.onSave() }}
              sizeClass="small"
              type='primary-black'
              className="font-small"
              isLoading={false}
            />
          </div>
        </div>
      </div>
    </>
  )
}