import { IMap } from 'yfiles/*';
import axios from "axios";
import {IMappingCMParameter} from './../models/mappingCMParameterInterface';






export const mappingParameterDataService = (userToken: string) => {
  var httpClient = axios.create({
    baseURL: "http://localhost:5150/api/LogicViewer/",
    headers: {
      "Content-type": "application/json"
    }
  });
  return httpClient.get('/FECMParam', {
    headers: {
      "Authorization": `Bearer ${userToken}`,
      "Accept": "text/plain"
    }
  })
}

