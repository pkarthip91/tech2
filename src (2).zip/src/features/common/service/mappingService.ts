import axios from "axios";

export const mappingParameterDataService = (userToken: string) => {
  var httpClient = axios.create({
    baseURL: "http://localhost:5150/api/LogicViewer/",
    headers: {
      "Content-type": "application/json"
    }
  });
  return httpClient.get('/FEMapping', {
    headers: {
      "Authorization": `Bearer ${userToken}`,
      "Accept": "text/plain"
    }
  })
}

