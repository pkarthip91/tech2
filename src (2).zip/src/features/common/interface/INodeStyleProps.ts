export interface INodeStyleProps<TTag = any> {
  width: number
  height: number
  selected: boolean
  tag: TTag
}