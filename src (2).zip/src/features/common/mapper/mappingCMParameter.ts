import {IMappingCMParameter} from '../models/mappingCMParameterInterface';
import {MappingCMParameter} from '../models/mappingCMParameter';
import {CMParameterResponse} from '../models/mappingCMParameterApiResponse';

export const mapCMMappingParameter=(parameterResponse:CMParameterResponse[]):IMappingCMParameter[]=>{
    let mappedData: Array<IMappingCMParameter>=[];
    parameterResponse.map((responseElement:CMParameterResponse)=>{
        mappedData.push(new MappingCMParameter(responseElement.cM_ID,
            responseElement.cmName,
            responseElement.paramName,
            responseElement.direction,
            +responseElement.portIndex));    
    });
    return mappedData;
}