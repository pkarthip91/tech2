import { IMappingParameter } from '../models/mappingParameterInterfcae';
import { MappingParameter } from '../models/mappingParameterModel';
import { MappingParameterApiResponse } from '../models/mappingParameterApiResponse';

export const mapMappingParameter = (parameterResponse: MappingParameterApiResponse[]): IMappingParameter[] => {
    let mappedData: Array<IMappingParameter> = [];
    parameterResponse.map((responseElement: MappingParameterApiResponse) => {
        mappedData.push(new MappingParameter(responseElement.pcdL_CM_Type, responseElement.pcsD_CM_Parameter, responseElement.pcsD_Table, responseElement.paramName, responseElement.pcsD_IO_Alarm_Subtype));
    });
    return mappedData;
}