export const MAPPING_DATA='mappingData';
export const GET_MAPPING_PARAMETER='getMappingParameter';