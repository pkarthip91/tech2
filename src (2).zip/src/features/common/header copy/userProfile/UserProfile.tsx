import { useDispatch, useSelector } from 'react-redux'
import { AppDispatch } from '../../../../app/store'
import { userLogout } from '../../../auth/reducer/AuthSlice'
import { useNavigate } from "react-router-dom";
import { selectedCurrentDBAction, selectedViewAction } from '../../../home/reducer/HomeSlice';
import { childViews } from '../../../home/HomeModels';
import { plantViewDataAction } from '../../../plantview/actions/PlantViewActions';
import React from 'react';

const ProfileScreen = () => {
  const { userInfo, userToken } = useSelector((state: any) => state.auth)
  const { dbList, currentDB } = useSelector((state: any) => state.home)
  const dispatch = useDispatch<AppDispatch>()
  const navigate = useNavigate()

  const handleDBChange = (selectedDB: string) => {
    if (!(currentDB === selectedDB)) {
      dispatch(selectedCurrentDBAction(selectedDB))
      // dispatch(plantViewDataAction({ userToken, currentDB }))
      dispatch(selectedViewAction(childViews.plantview))
    }
  }
  //TO DO - In-line styles should be removed once UI finalized
  return (
    <div style={{ float: 'right', display: 'inline-flex' }} >
      {/* <div style={{ paddingRight: '100px' }} >
        Connect to Database:
        <select value={currentDB} onChange={(e) => handleDBChange(e.target.value)}>
          {dbList && dbList.length ? dbList.map((db: string, index: number) => {
            return <option key={index} value={db}>{db}</option>
          })
            : <option value={'CaFeDB1'}>CaFeDB1</option>}
        </select>
      </div> */}
      <div>
        <span className='userProfileName'>
           <strong>{userInfo?.userName}</strong>
        </span>
        {/* <button onClick={() => {
          dispatch(userLogout());
          navigate('/login');
        }}>
          Logout
        </button> */}
      </div>
    </div>
  )
}
export default ProfileScreen