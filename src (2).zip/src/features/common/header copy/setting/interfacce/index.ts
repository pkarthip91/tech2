import { IDbList, IDbListState } from './DbListInterface'
export type {
  IDbList,
  IDbListState
}