export interface IDbList {
  dbName: string,
  default: boolean
}

export interface IDbListState {
  loading: boolean,
  dbList: Array<IDbList>
  error: string | null
}