import { createSlice } from '@reduxjs/toolkit';
import { dBListAction } from '../actions/DbListDataActions';
import { DB_LIST_REDUCER } from '../SeetingConstant';
import { IDbList, IDbListState } from '../interfacce'


const initialState: IDbListState = {
  loading: false,
  dbList: new Array<IDbList>(),
  error: null
}

export const DbListSlice = createSlice({
  name: `${DB_LIST_REDUCER}`,
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(dBListAction.pending, (state) => {
        state.loading = true;
      })
      .addCase(dBListAction.fulfilled, (state, { payload }: any) => {
        state.loading = false;
        if (payload)
          state.dbList = payload;
      })
      .addCase(dBListAction.rejected, (state, { payload }: any) => {
        state.loading = false;
        state.error = payload
      });
  }
});

export default DbListSlice.reducer;
