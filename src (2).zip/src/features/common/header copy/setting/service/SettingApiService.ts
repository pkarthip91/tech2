import { httpClient } from '../../../../../app/api/middlewareSecurity'

export const dBListService = (userToken: string) => {
  return httpClient.get('/User/Database', {
    headers: {
      "Authorization": `Bearer ${userToken}`,
      "Accept": "text/plain"
    }
  })
}