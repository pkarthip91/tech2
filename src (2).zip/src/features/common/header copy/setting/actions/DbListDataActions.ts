import { createAsyncThunk } from "@reduxjs/toolkit";
import { Logger } from "../../../../../app/common/LoggerService";
import { DB_LIST_ACTION, DB_LIST_API_FAIL, SETTING_REDUCER } from "../SeetingConstant";
import { dBListService } from "../service/SettingApiService";
import { IDbList } from "../interfacce";

export const dBListAction = createAsyncThunk(
  `${SETTING_REDUCER}/${DB_LIST_ACTION}`,
  async (userToken: string, { rejectWithValue }: any) => {
    let result = null
    try {
      const response = await dBListService(userToken)
      if (response.status === 200 && response.data) {
        try {
          const dbList: IDbList[] = response.data
          result = dbList || []
        } catch (error: any) {
          Logger.error('DB List API response error:', error)
          result = rejectWithValue(DB_LIST_API_FAIL)
        }
      } else {
        result = rejectWithValue(DB_LIST_API_FAIL)
      }
    } catch (error: any) {
      Logger.error(DB_LIST_API_FAIL, error)
      if (error.response.data || error.message) {
        result = rejectWithValue(error.response.data || error.message)
      } else {
        result = rejectWithValue(DB_LIST_API_FAIL)
      }
    }
    return result
  }
)
