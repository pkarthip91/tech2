import settingmenuitems from 'assest/img/settings/settings.svg';
// setting_Dropdown
import DB_Connect from 'assest/img/settings/DB_Connect.svg';
import Configuration from 'assest/img/settings/Configuration.svg';
import LibraryConfiguration from 'assest/img/settings/Library_Configuration.svg';
import IOAllocation from 'assest/img/settings/IOAllocation.svg';
import simulation from 'assest/img/settings/simulation.svg';
import view from 'assest/img/settings/view.svg';
import General_Configuration from 'assest/img/settings/General_Configuration.svg';
import Import_Configuration from 'assest/img/settings/Import_Configuration.svg';
import Export_Configuration from 'assest/img/settings/Export_Configuration.svg';
import CA_Tree_view from 'assest/img/settings/CA_Tree_view.svg';

import { MenuItemsData } from 'features/common/menuBar/MenuItemDataClass';



const connectToDbMenu = (): MenuItemsData => {
  return new MenuItemsData('connectToDb', '', 'Connect to database', DB_Connect, [])
}

const configurationMenu = (): MenuItemsData => {
  return new MenuItemsData('', '', 'Configuration', Configuration, [
    new MenuItemsData('', '', 'General Configuration', General_Configuration, []),
    new MenuItemsData('', '', 'Import Configuration', Import_Configuration, []),
    new MenuItemsData('', '', 'Library Configuration', Export_Configuration, [])
  ])
}

const libraryMenu = (): MenuItemsData => {
  return new MenuItemsData('', '', 'Library Configuration', LibraryConfiguration, [])
}

const iOAllocationMenu = (): MenuItemsData => {
  return new MenuItemsData('', '', 'Hardware Configuration', IOAllocation, [])
}

const simulationMenu = (): MenuItemsData => {
  return new MenuItemsData('', '', 'Simulation Configuration', simulation, [])
}

const viewMenu = (): MenuItemsData => {
  return new MenuItemsData('', '', 'view', view, [
    new MenuItemsData('', '', 'CA Tree view', CA_Tree_view, [])
  ])
}

export const settingMenuItemsData: MenuItemsData[] = [
  new MenuItemsData('', "settings-icon", '', settingmenuitems,
    [
      connectToDbMenu(),
      configurationMenu(),
      libraryMenu(),
      iOAllocationMenu(),
      simulationMenu(),
      viewMenu()
    ]
  )
];