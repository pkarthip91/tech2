export const SETTING_REDUCER = 'setting'
export const SETTING_DATA_ACTION = 'settingDataAction'
export const SETTING_DATA_ACTION_FAIL = 'Setting API call failed!'

export const DB_LIST_REDUCER = 'dbList'
export const DB_LIST_ACTION = 'dbListAction'
export const DB_LIST_API_FAIL = 'DB list API call failed!'

