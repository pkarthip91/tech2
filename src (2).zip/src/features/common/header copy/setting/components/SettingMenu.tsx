import { useEffect } from "react";
import { useAppDispatch, useAppSelector } from "../../../../../app/hooks"
import { MenuBar } from "../../../menuBar/MenuBar";
import { IDbListState } from "../interfacce"
import { settingMenuItemsData } from "../SettingMenuItemsData";
import { MenuItemsData } from "features/common/menuBar/MenuItemDataClass";
import { selectedCurrentDBAction } from "features/home/reducer/HomeSlice";



export const SettingMenu = () => {
  const { dbList } = useAppSelector<IDbListState>((state: any) => state.dbList)
  const dispatch = useAppDispatch();

  useEffect(() => {
    if (dbList) {
      settingMenuItemsData.map((settingMenuItem: MenuItemsData) => {
        const connectToDbItems = settingMenuItem.subMenu.find(f => f.id === 'connectToDb')
        if (connectToDbItems) {
          connectToDbItems.subMenu.splice(0, connectToDbItems.subMenu.length)
          dbList.map((db) => connectToDbItems.subMenu.push(
            new MenuItemsData(db.dbName, '', db.dbName, null, [])))
        }
      })
    }
  }, [dbList])

  const handleClick = (item: MenuItemsData) => {
    if (dbList && dbList.find(db => db.dbName === item.id))
      dispatch(selectedCurrentDBAction(item.id));
  }
  return (
    <>
      <MenuBar handleClick={handleClick} menuItems={settingMenuItemsData} openLeft={true} />
    </>
  )
}