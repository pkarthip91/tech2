import {
  AppTopNavi,
  AppTopNaviItem,
  Menu,
  MenuItem,
  SubMenu,
  MenuItemDivider,
  AppTopNaviDivider,
  AppHeader
} from "@abb/abb-common-ux-react";

import React, { MouseEventHandler, useEffect, useState } from "react"
import { Link } from "react-router-dom"
import { useAppDispatch, useAppSelector } from "../../../app/hooks"
import { childViews, HeaderMenuAppTopNaviItemProps, HeaderMenuProps, HeaderMenuSubMenuProps } from "../../home/HomeModels"
import { selectedViewAction } from "../../home/reducer/HomeSlice"
import UserProfile from "./userProfile/UserProfile"
import ABBLogo from '../../../assest/img/ABB_logo.png'
import FETool from '../../../assest/img/FETool 1.png'
import { SettingMenu } from "./setting";
import { DbInfo } from "./DbInfo";
import { IPlantViewState } from "../../plantview/models/PlantViewInterface";
import { MenuBar } from "../menuBar/MenuBar";


export const HeaderComponent = (props: any) => {
  var userProfile: JSX.Element = <UserProfile />
  const { selectedUnit } = useAppSelector<IPlantViewState>((state: any) => state.plantview)
  const { clickedItem, currentView } = useAppSelector((state: any) => state.home)
  const [activeItem, setActiveItem] = useState('(blank)');
  const [isSettingMenuOpen, setIsSettingMenuOpen] = useState(false);
  const [clickedMenuItem, setClickedMenuItem] = useState({});
  const [clickedHomeItem, setClickedHomeItem] = useState(clickedItem);
  const [userMenuOpen] = React.useState(false);
  const [infoText, setInfoText] = useState('');

  useEffect(() => {
    try {
      (clickedItem == clickedMenuItem) ? setActiveItem('setting') : setActiveItem('(blank)')
    } catch { setActiveItem('(blank)') }
  }, [clickedMenuItem, clickedItem])

  const dispatch = useAppDispatch();

  useEffect(() => { setInfoText(getSelectedPlantUnitText()) }, [currentView])
  // Dropdown menu
  // const [open, setOpen] = React.useState(false);
  // const handleOpen = () => {
  //   setOpen(!open);
  // };

  // const [showDropdown, setShowDropdown] = React.useState(true);
  // const [selectedCity, setSelectedCity] = React.useState([]);
  // const [monochrome, setMonochrome] = React.useState(false);


  const handleViewChange = (view: childViews): any => {
    if (view === childViews.unitview && !(selectedUnit?.nodeData?.pcsDdataKey)) {
      alert('Please select unit first!')
      view = childViews.plantview
    }
    dispatch(selectedViewAction(view))
  }
  const getSelectedPlantUnitText = () => {
    let txt: string = ''
    try {
      if (currentView == childViews.unitview && (selectedUnit)) {
        txt = `: [${selectedUnit.nodeData?.plantName}, ${selectedUnit.name()}]`
      }
    } catch { }
    return txt
  }


  //TO DO - In-line styles should be removed once UI finalized
  return (
    <>
      <div className="headerTop" >

        <div className='MainWarpper'>
          <div className="headerContainer">
            {/* <AbbBar productName="CommonUX – Application layout"/> */}
            <div className='appHeader'>
              <AppTopNavi>
                <a href="#"><img src={ABBLogo} onClick={() => handleViewChange(childViews.plantview)} className="AbbLogo" alt="ABB Logo" /></a>
                <h4>ABB Ability <sup className="supClass">TM</sup> FE TOOL (All Features){infoText}</h4>
              </AppTopNavi>
              <DbInfo />
              <div className='alignRight'>
                {/* <UserProfile /> */}
                <span className="fetool">
                  <img src={FETool} className="fetoolImg" alt="FETool" />
                </span>
                {/* <AppTopNavi> */}
                <AppTopNaviItem icon="abb/help-circle-2" className="size-16 icon-custom" />
                <span>
                  <SettingMenu />
                </span>
                {/* <AppTopNaviItem {...new HeaderMenuAppTopNaviItemProps(
                    "", "abb/settings",
                    activeItem === 'setting',
                    false,
                    true,
                    (e) => { setClickedMenuItem(e.target) },
                    undefined,
                    'size-16')}>
                    {
                      activeItem === 'setting' &&

                      <SettingMenu onSelect={() => setActiveItem('')} />

                    }
                  </AppTopNaviItem> */}
                {/* </AppTopNavi> */}
                <UserProfile />
              </div>
            </div>
          </div>
        </div>

        <AppTopNavi>
          {/* Logo Add */}
          {/* <a href="#"><img src={ABBLogo} className="AbbLogo" alt="ABB Logo"/></a> 
        <h2>ABB Ability <sup>TM</sup> FE TOOL (All Features)</h2> */}

          {/* <AppTopNaviItem onClick={() => handleViewChange(childViews.plantview)}  text="Plant View" />
            <AppTopNaviItem onClick={() => handleViewChange(childViews.unitview)}  text="Unit View" /> */}
        </AppTopNavi>

        <div className="header-inner">

          {/* <div className="right-section">
          <span style={{ 'cursor': 'pointer' }} onClick={() => handleViewChange(childViews.plantview)}  >Plant View</span>
          &nbsp;&nbsp;&nbsp;&nbsp;
          <span style={{ 'cursor': 'pointer' }} onClick={() => handleViewChange(childViews.unitview)}>Unit View</span>
          </div> */}
        </div>


      </div>
    </>
  )
}