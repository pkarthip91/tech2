import { useAppSelector } from "../../../app/hooks"

export const DbInfo = () => {
  const { currentDB } = useAppSelector((state: any) => state.home)
  return (
    <div className="dbName">
      <span className="showDbName alginRight">Database :: {currentDB}</span>
    </div>
  )
}