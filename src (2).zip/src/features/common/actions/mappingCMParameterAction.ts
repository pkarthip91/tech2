import { createAsyncThunk } from "@reduxjs/toolkit";
import { Logger } from "../../../app/common/LoggerService";
import {mappingParameterDataService} from './../service/mappingCMService';
import {CMParameterResponse} from '../../common/models/mappingCMParameterApiResponse';
import {mapCMMappingParameter} from '../../common/mapper/mappingCMParameter';

export const getCMMappingParameter = createAsyncThunk('MappingParameter/CMParameter',
async (userToken:string,{rejectWithValue}:any)=>{
    let result=null;
    try {
        const response = await mappingParameterDataService(userToken)
        if (response.status == 200 && response.data) {
          try {
            const mappingParameterResponse: CMParameterResponse[] = response.data
            result = mappingParameterResponse.length > 0 ?
            mapCMMappingParameter(mappingParameterResponse) :
              []
          } catch (error: any) {
            Logger.error('Mapping CM Parameter API', error)
            result = rejectWithValue('Mapping CM Parameter API Failed')
          }
        } else {
          result = rejectWithValue('Mapping CM Parameter API Failed')
        }
      } catch (error: any) {
        Logger.error('Mapping CM Parameter API Failed')
        if (error.response.data || error.message) {
          result = rejectWithValue(error.response.data || error.message)
        } else {
          result = rejectWithValue('Mapping CM Parameter API Failed')
        }
      }    

    return result;

}

) 