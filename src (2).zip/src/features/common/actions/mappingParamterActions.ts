import { createAsyncThunk } from "@reduxjs/toolkit";
import { Logger } from "../../../app/common/LoggerService";
import { MAPPING_DATA, GET_MAPPING_PARAMETER } from './../mappingConstant';
import { mappingParameterDataService } from './../service/mappingService';
import { MappingParameterApiResponse } from '../../common/models/mappingParameterApiResponse';
import { mapMappingParameter } from '../../common/mapper/MappingParameterMapper';

export const getMappingParameter = createAsyncThunk(`${MAPPING_DATA}/${GET_MAPPING_PARAMETER}`,
  async (userToken: string, { rejectWithValue }: any) => {
    let result = null;
    try {
      const response = await mappingParameterDataService(userToken)
      if (response.status === 200 && response.data) {
        try {
          const mappingParameterResponse: MappingParameterApiResponse[] = response.data
          result = mappingParameterResponse.length > 0 ?
            mapMappingParameter(mappingParameterResponse) :
            []
        } catch (error: any) {
          Logger.error('Mapping Parameter API', error)
          result = rejectWithValue('Mapping Parameter API Failed')
        }
      } else {
        result = rejectWithValue('Mapping Parameter API Failed')
      }
    } catch (error: any) {
      Logger.error('Mapping Parameter API Failed')
      if (error.response.data || error.message) {
        result = rejectWithValue(error.response.data || error.message)
      } else {
        result = rejectWithValue('Mapping Parameter API Failed')
      }
    }

    return result;

  }

) 