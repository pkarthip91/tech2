
import type { INode, IRenderContext } from 'yfiles'
import { GraphComponent, NodeStyleBase, SvgVisual, Visual } from 'yfiles'
import { render, unmountComponentAtNode } from 'react-dom'
import { createElement, FunctionComponent } from 'react'
import { INodeStyleProps } from '../../interface/INodeStyleProps'




function dispose(context: IRenderContext, removedVisual: Visual, dispose: boolean): Visual | null {
  const gElement = (removedVisual as SvgVisual).svgElement as SVGGElement
  unmountComponentAtNode(gElement)
  return null
}

type RenderType<TTag> = FunctionComponent<INodeStyleProps<TTag>>

declare type Cache<TTag> = { cache: INodeStyleProps<TTag> }


export default class NodeStyle<TTag> extends NodeStyleBase {
  constructor(private readonly type: RenderType<TTag>) {
    super()
  }

  createProps(context: IRenderContext, node: INode): INodeStyleProps<TTag> {
    return {
      width: node.layout.width,
      height: node.layout.height,
      selected: (context.canvasComponent as GraphComponent).selection.selectedNodes.isSelected(
        node
      ),
      tag: node.tag as TTag
    }
  }

  createVisual(context: IRenderContext, node: INode): Visual | null {
    const gElement = document.createElementNS('http://www.w3.org/2000/svg', 'g')
    const props = this.createProps(context, node)
    const element = createElement(this.type, props)
    render(element, gElement)
    SvgVisual.setTranslate(gElement, node.layout.x, node.layout.y)
    const svgVisual = new SvgVisual(gElement) as SvgVisual & Cache<TTag>
    svgVisual.cache = props

    context.setDisposeCallback(svgVisual, dispose)
    return svgVisual
  }

  updateVisual(context: IRenderContext, oldVisual: Visual, node: INode): Visual | null {
    let oldSvgVisual = oldVisual as SvgVisual & Cache<TTag>
    const gElement = oldSvgVisual.svgElement as SVGGElement

    const props = this.createProps(context, node)

    const lastProps = oldSvgVisual.cache
    if (
      lastProps.width !== props.width ||
      lastProps.height !== props.height ||
      lastProps.selected !== props.selected ||
      lastProps.tag !== props.tag
    ) {
      const element = createElement(this.type, props)
      render(element, gElement)
      oldSvgVisual.cache = props
    }
    SvgVisual.setTranslate(gElement, node.layout.x, node.layout.y)
    return oldVisual
  }
}
