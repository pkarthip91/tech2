import { License } from 'yfiles';

import yFilesLicense from '../../../../yFiles/lib/license.json'

export const applyLicence = () => {
  if (License.value != yFilesLicense)
    License.value = yFilesLicense;
}