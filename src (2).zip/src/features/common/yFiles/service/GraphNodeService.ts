import { FreeNodePortLocationModel, IEdge, IGraph, INode, IPort, IPortLocationModelParameter, Point, Point2D, PolylineEdgeStyle, Rect } from 'yfiles';
import NodeStyle from './NodeStyleService';

export const createGraphNode = (
  graph: IGraph,
  template: any,
  xPos: number,
  yPos: number,
  width: number,
  height: number,
  tag: any): INode => {
  return graph.createNode({
    layout: new Rect(xPos, yPos, width, height),
    style: new NodeStyle(template),
    tag
  })
}

export const createNodePort = (
  graph: IGraph,
  node: INode,
  parameter: IPortLocationModelParameter,
  tag?: any): IPort => {
  return graph.addPort(node, parameter, null, tag)
}

export const createEdgeByPorts = (
  graph: IGraph,
  sPort: IPort,
  tPort: IPort): IEdge => {
  return graph.createEdge(sPort, tPort, new PolylineEdgeStyle({ stroke: '2px solid steelblue' }))
}

export const createEdgeByNodes = (
  graph: IGraph,
  sNode: INode,
  tNode: INode): IEdge => {
  return graph.createEdge(sNode, tNode)
}

export const createPortLocationparameter = (ratio: Point, offset: Point): IPortLocationModelParameter => {
  return FreeNodePortLocationModel.INSTANCE.createParameterForRatios(ratio, offset)
}

