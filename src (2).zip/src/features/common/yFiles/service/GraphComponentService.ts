import { GraphComponent, GraphInputMode, GraphViewerInputMode } from 'yfiles';

export const createGraphComponent = (): GraphComponent => {
  return new GraphComponent()
}

export const clearGraphComponent = (graphComponent: GraphComponent): void => {
  graphComponent.graph.clear()
}

export const setGraphInputMode = (graphComponent: GraphComponent, properties?: any) => {
  graphComponent.inputMode = new GraphViewerInputMode()
}

