import { GraphBuilder } from 'yfiles';

export const createGraphComponent = (): GraphBuilder => {
  return new GraphBuilder()
}

