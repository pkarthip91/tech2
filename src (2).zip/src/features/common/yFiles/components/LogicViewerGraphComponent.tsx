import { Component, createRef, RefObject } from 'react';

import {
  Arrow,
  Class,
  EdgesSource,
  GraphBuilder,
  GraphComponent,
  HierarchicLayout,
  LayoutExecutor,
  License,
  NodesSource,
  PolylineEdgeStyle,
  Size
} from 'yfiles';
import './LogicViewerGraphComponent.css';
import { IEdgeData, INodeData } from '../../../logicViewer/LogicViewerInterface';

import ReactComponentNodeStyle from './templates/ReactComponentNodeStyle';
import NodeTemplate from './templates/NodeTemplate';
import { IReactGraphComponentProps } from '../yFilesInterface';
import { applyLicence } from '../service/LicenceService';



export class LogicViewerGraphComponent extends Component<IReactGraphComponentProps> {

  private readonly div: RefObject<HTMLDivElement>;
  private readonly graphComponent: GraphComponent;
  private graphBuilder!: GraphBuilder;
  private nodesSource!: NodesSource<INodeData>;
  private edgesSource!: EdgesSource<IEdgeData>;

  constructor(props: IReactGraphComponentProps) {
    super(props);
    this.div = createRef<HTMLDivElement>();
    applyLicence();
    this.graphComponent = new GraphComponent();
    this.initializeDefaultStyles();
  }

  async componentDidMount(): Promise<void> {
    Class.ensure(LayoutExecutor);
    this.div.current!.appendChild(this.graphComponent.div);
    this.graphComponent.graph.clear();
    this.graphBuilder = this.createGraphBuilder();
    this.graphComponent.graph = this.graphBuilder.buildGraph();

    await this.graphComponent.morphLayout({ layout: new HierarchicLayout(), morphDuration: '1s' });

    await this.graphComponent.fitGraphBounds();
  }


  private createGraphBuilder(): GraphBuilder {
    const graphBuilder = new GraphBuilder(this.graphComponent.graph);
    this.nodesSource = graphBuilder.createNodesSource({
      data: this.props.graphData.nodesSource,
      id: 'id'
    })
    this.edgesSource = graphBuilder.createEdgesSource({
      data: this.props.graphData.edgesSource,
      sourceId: 'fromNode',
      targetId: 'toNode'
    })
    return graphBuilder
  }

  initializeDefaultStyles(): void {
    this.graphComponent.graph.nodeDefaults.size = new Size(200, 100);
    this.graphComponent.graph.nodeDefaults.style = new ReactComponentNodeStyle(NodeTemplate);
    this.graphComponent.graph.edgeDefaults.style = new PolylineEdgeStyle();
  }

  render() {
    return (
      <div className="graph-component-container" ref={this.div} />
    )
  }
}