import * as React from 'react'
import { Component, createRef, RefObject } from 'react'
import { Font, Size, TextRenderSupport, TextWrapping } from 'yfiles'

type SvgTextProps = {
  transform?: string
  text: string
  font?: string
  x?: number
  y?: number
  maxWidth?: number
  maxHeight?: number
  className?: string
  fill?: string
  style?: React.CSSProperties
}

export default class SvgText extends Component<SvgTextProps, {}> {
  private readonly textElement: RefObject<SVGTextElement>

  constructor(props: Readonly<SvgTextProps> | SvgTextProps) {
    super(props)
    this.textElement = createRef<SVGTextElement>()
  }

  static defaultProps = {
    maxHeight: Number.MAX_VALUE,
    maxWidth: Number.MAX_VALUE,
    text: '',
    className: '',
    font: 'normal 12px sans-serif',
    x: 0,
    y: 0
  }

  componentDidMount() {
    this.addText()
  }

  private addText() {
    // Append the text to the DOM
    TextRenderSupport.addText(
      this.textElement.current!,
      this.props.text,
      Font.from(this.props.font!),
      new Size(this.props.maxWidth!, this.props.maxHeight!),
      TextWrapping.WORD_ELLIPSIS
    )
  }

  componentDidUpdate(prevProps: Readonly<SvgTextProps>, prevState: Readonly<{}>, snapshot?: any) {
    let element = this.textElement.current!
    while (element.firstChild) {
      element.firstChild.remove()
    }
    this.addText()
  }

  render(): JSX.Element {
    const { x, y, className, fill, style } = this.props
    return (
      <text
        transform={`translate(${x}, ${y})`}
        ref={this.textElement}
        className={className}
        fill={fill}
        style={style}
      />
    )
  }
}
