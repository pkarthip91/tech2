/****************************************************************************
 ** @license
 ** This demo file is part of yFiles for HTML 2.5.
 ** Copyright (c) 2000-2022 by yWorks GmbH, Vor dem Kreuzberg 28,
 ** 72070 Tuebingen, Germany. All rights reserved.
 **
 ** yFiles demo files exhibit yFiles for HTML functionalities. Any redistribution
 ** of demo files in source code or binary form, with or without
 ** modification, is not permitted.
 **
 ** Owners of a valid software license for a yFiles for HTML version that this
 ** demo is shipped with are allowed to use the demo source code as basis
 ** for their own yFiles for HTML powered applications. Use of such programs is
 ** governed by the rights and conditions as set out in the yFiles for HTML
 ** license agreement.
 **
 ** THIS SOFTWARE IS PROVIDED ''AS IS'' AND ANY EXPRESS OR IMPLIED
 ** WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 ** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN
 ** NO EVENT SHALL yWorks BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 ** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
 ** TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 ** PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 ** LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 ** NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 ** SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 **
 ***************************************************************************/
import * as React from 'react'
import type { ReactComponentNodeStyleProps } from './ReactComponentNodeStyle'
import SvgText from '../SvgTextComponent'

export default function NodeTemplate({
  width,
  height,
  selected,
  tag
}: ReactComponentNodeStyleProps<{ blkName: string, cmType: string, inputPortsCol: string[], outputPortsCol: string[] }>) {
  return (
    <g>
      <rect
        style={{ fill: 'white', stroke: 'black', strokeWidth: 4 }}
        x={0}
        y={0}
        rx={10}
        ry={10}
        width={width}
        height={height}
      />
      <SvgText
        text={tag.blkName}
        font="bold italic 14px sans-serif"
        maxWidth={width}
        maxHeight={height}
        x={width / 2}
        y={0}
        fill="maroon"
        style={{ textAnchor: 'middle', dominantBaseline: 'middle' }}
      />
      <SvgText
        text={tag.cmType}
        font="bold 13px sans-serif"
        maxWidth={width}
        maxHeight={height}
        x={width / 2}
        y={14}
        fill="maroon"
        style={{ textAnchor: 'middle', dominantBaseline: 'middle' }}
      />

      {tag.inputPortsCol.map((p: string, i: number) =>
        <>
          <SvgText
            text={p}
            font="12px sans-serif"
            maxWidth={width}
            maxHeight={height}
            x={5}
            y={30 + (12 * i)}
            fill="darkblue"
            style={{ textAnchor: 'start', dominantBaseline: 'middle' }}
          />
          {tag.outputPortsCol.length > i &&
            <SvgText
              text={tag.outputPortsCol[i]}
              font="12px sans-serif"
              maxWidth={width}
              maxHeight={height}
              x={width}
              y={30 + (12 * i)}
              fill="darkblue"
              style={{ textAnchor: 'end', dominantBaseline: 'middle' }}
            />}
        </>
      )}
    </g>
  )
}
