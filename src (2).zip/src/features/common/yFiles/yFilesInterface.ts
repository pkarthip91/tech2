import { IGraphData } from "../../logicViewer/LogicViewerInterface";

export interface IReactGraphComponentProps {
  graphData: IGraphData
}