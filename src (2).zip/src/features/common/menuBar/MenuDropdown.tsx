import { MenuItemsData } from "./MenuItemDataClass";
import { MenuItems } from "./MenuItems";

export const MenuDropdown = ({ submenus, dropdown, depthLevel, handleClick }: any) => {
    depthLevel = depthLevel + 1;
    const dropdownClass = depthLevel > 1 ? "dropdown-submenu" : "";
    return (<ul className={`dropdown ${dropdownClass} ${dropdown ? "show" : ""}`}>
        {submenus.map((submenu: MenuItemsData, index: number) => (
            <MenuItems item={submenu} key={index} depthLevel={depthLevel} handleClick={handleClick} />
        ))}
    </ul>
    );
};