import React from "react";
import { useState, useEffect } from "react";

import { MenuDropdown } from "./MenuDropdown";
import { MenuItemsData } from "./MenuItemDataClass";




export const MenuItems = (props: any) => {
  const item: MenuItemsData = props.item
  const depthLevel = props.depthLevel
  const handleClick = props.handleClick

  const [dropdown, setDropdown] = useState<boolean>(false);
  let refli: React.RefObject<HTMLLIElement> = React.createRef<HTMLLIElement>();
  useEffect(() => {
    const handler = (event: any) => {
      if (dropdown && refli.current && !refli.current.contains(event.target)) {
        setDropdown(false);
      }
    };
    document.addEventListener("mousedown", handler);
    document.addEventListener("touchstart", handler);
    return () => {
      document.removeEventListener("mousedown", handler);
      document.removeEventListener("touchstart", handler);
    };

  }, [dropdown]);

  const onMouseEnter = () => { setDropdown(true); };

  const onMouseLeave = () => { setDropdown(false); };

  return (
    <li className="menu-items" ref={refli} onMouseEnter={onMouseEnter} onMouseLeave={onMouseLeave} >
      {
        item && (item.subMenu && item.subMenu.length ? (
          <>
            <button type="button" className={item.cssClass + " setting-menu menu-radius"} aria-haspopup="menu" aria-expanded={dropdown ? "true" : "false"}
              onClick={() => setDropdown((prev) => !prev)}>
              {item.icon && <span className="icon-14 menu-icons">
                <img src={item.icon} />
              </span>}
              {item.title} {""} {depthLevel > 0 ? <span className="right-arrow"></span> : item.title && <span className="arrow" />}
            </button>
            <MenuDropdown depthLevel={depthLevel} submenus={item.subMenu} dropdown={dropdown} handleClick={handleClick} />
          </>
        ) : (<a onClick={() => { (handleClick && handleClick(item)); }}>
          {item.icon && <span className="icon-14  menu-icons">
            <img src={item.icon} className="fetoolImg" alt="FETool" />
          </span>
          }{item.title} </a>))
      } </li>);
};
