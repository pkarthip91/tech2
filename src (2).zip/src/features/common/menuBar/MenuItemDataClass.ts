export class MenuItemsData {
  constructor(
    public id: string = '',
    public cssClass: string = '',
    public title: string = '',
    public icon: string | null = null,
    public subMenu: MenuItemsData[] = []
  ) { }
}