import React from 'react';
import './MenuBar.css'
import { MenuItemsData } from './MenuItemDataClass';
import { Navbar } from './Navbar';


export const MenuBar = (props: any) => {
  const menuItems: MenuItemsData[] = props.menuItems
  const openLeft: boolean = props.openLeft || false
  return (
    <>
      <header>
        <div className="nav-area">
          <Navbar menuItems={menuItems} handleClick={props.handleClick} openLeft={openLeft} />
        </div>
      </header></>
  )
}