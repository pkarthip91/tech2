import { MenuItemsData } from "./MenuItemDataClass";
import { MenuItems } from "./MenuItems";


export const Navbar = (props: any) => {
    const menuItems: MenuItemsData[] = props.menuItems
    const openLeft: boolean = props.openLeft
    return (
        <nav>
            <ul className={"menus" + (openLeft ? " setting-menu-main" : "")} > {
                menuItems?.map((menu: MenuItemsData, index: any) => {
                    const depthLevel = 0;
                    return <MenuItems
                        item={menu}
                        key={index}
                        depthLevel={depthLevel}
                        handleClick={props.handleClick}
                    />;
                })
            }
            </ul>
        </nav>

    );

};
