// Bluk Edit
import Bulk_Edit from '../../../assest/img/plant/Bulk_Edit.svg';
import Import_data from '../../../assest/img/plant/import_data.svg';
import Export_data from '../../../assest/img/plant/Export_data.svg';
import Import_Tag from '../../../assest/img/plant/Import_Tag.svg';
import Export_Tag from '../../../assest/img/plant/Export_Tag.svg';

import { MenuItemsData } from 'features/common/menuBar/MenuItemDataClass';

export const bulkEditMenuItemsData: MenuItemsData =
  new MenuItemsData('', "", 'Bulk Edit', Bulk_Edit,
    [
      new MenuItemsData('ImportData', '', 'Import Data', Import_data, []),
      new MenuItemsData('ExportData', '', 'Export Data', Export_data, []),
      new MenuItemsData('ImportTag', '', 'Import Tag', Import_Tag, []),
      new MenuItemsData('ExportTag', '', 'Export Tag', Export_Tag, [])
    ]
  );