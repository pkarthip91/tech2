import { MenuBar } from "features/common/menuBar/MenuBar"
import { ribbonMenuItemsData } from "../RibbonMenuItems"
import { InputXML } from "features/importXML/components/ImportXML"
import { useState } from "react";
import { MenuItemsData } from "features/common/menuBar/MenuItemDataClass";
import { CreateUM } from "features/createUM/components/CreateUM";

export const RibbonMenu = () => {
  const [onClickImportXML, setOnClickImportXML] = useState<boolean>(false);
  const [onClickCreateUM, setOnClickCreateUM] = useState<boolean>(false);

  const handleClick = (item: MenuItemsData) => {
    switch (item.id) {
      case 'importXML': setOnClickImportXML(true); break;
      case 'createUM': setOnClickCreateUM(true); break;
    }
  }
  return (
    <>
      <MenuBar menuItems={ribbonMenuItemsData} handleClick={handleClick} />
      <InputXML onClick={onClickImportXML} setToClose={() => setOnClickImportXML(false)} />
      <CreateUM onClick={onClickCreateUM} setToClose={() => setOnClickCreateUM(false)} />
    </>
  )
}