import Reports from '../../../assest/img/plant/Reports.svg';
import Import_Diff_Report from '../../../assest/img/plant/Import_Diff_Report.svg';
import Export_Diff_Report from '../../../assest/img/plant/Export_Diff_Report.svg';
import FS_Comparison from '../../../assest/img/plant/FS_Comparison.svg';
import External_Variable from '../../../assest/img/plant/External_Variable.svg';


import print from '../../../assest/img/plant/print.svg';

import { MenuItemsData } from 'features/common/menuBar/MenuItemDataClass';

export const reportMenuItemsData: MenuItemsData =
  new MenuItemsData('', "report-menu", 'Report', Reports,
    [
      new MenuItemsData('ImportDiffReport', '', 'Import Diff Report', Import_Diff_Report, []),
      new MenuItemsData('ExportDiffReport', '', 'Export Diff Report', Export_Diff_Report, []),
      new MenuItemsData('FSComparison', '', 'FS Comparison', FS_Comparison, []),
      new MenuItemsData('ExternalVariableCrossReference', '', 'External Variable Cross Reference', External_Variable, []),
      new MenuItemsData('PrintLogicViews', '', 'Print Logic Views', print, [])
    ]
  );