import Functional_Spec from '../../../assest/img/plant/Functional_Spec.svg';
import Import_FS from '../../../assest/img/plant/Import_FS.svg';
import Export_FS from '../../../assest/img/plant/Export_FS.svg';
import CE_Import from '../../../assest/img/plant/C&E_Import.svg';
import CE_Export from '../../../assest/img/plant/C&E_Export.svg';
import Import_XML_FS from '../../../assest/img/plant/Import_XML_FS.svg';
import FMLevel from '../../../assest/img/plant/FMLevel.svg';
import Reserve from '../../../assest/img/plant/Reserve.svg';

import { MenuItemsData } from 'features/common/menuBar/MenuItemDataClass';



const importFSMenu = (): MenuItemsData => {
  return new MenuItemsData('importFS', '', 'Import FS', Import_FS, [
    new MenuItemsData('', '', 'C&E Import', CE_Import, []),
    new MenuItemsData('', '', 'C&E Export', CE_Export, [])
  ])
}

const exportFSMenu = (): MenuItemsData => {
  return new MenuItemsData('exportFS', '', 'Export FS', Export_FS, [
  ])
}

const importXMLFS = (): MenuItemsData => {
  return new MenuItemsData('importXML', '', 'Import XML FS', Import_XML_FS, [
  ])
}

const levelMenu = (): MenuItemsData => {
  return new MenuItemsData('levelMenu', 'level-menu', '5+', FMLevel, [
    new MenuItemsData('', '', '1', '', []),
    new MenuItemsData('', '', '2', '', []),
    new MenuItemsData('', '', '2+', '', []),
    new MenuItemsData('', '', '3', '', []),
    new MenuItemsData('', '', '3+', '', []),
    new MenuItemsData('', '', '4', '', []),
    new MenuItemsData('', '', '4+', '', []),
    new MenuItemsData('', '', '5', '', []),
    new MenuItemsData('', '', '5+', '', [])
  ])
}

const reserveMenu = (): MenuItemsData => {
  return new MenuItemsData('reserveMenu', '', 'Reserve', Reserve, [
  ])
}

export const functionalSpecMenuItemsData: MenuItemsData =
  new MenuItemsData('', "", 'Functional Spec', Functional_Spec,
    [
      importFSMenu(),
      exportFSMenu(),
      importXMLFS(),
      levelMenu(),
      reserveMenu()
    ]
  )
  ;