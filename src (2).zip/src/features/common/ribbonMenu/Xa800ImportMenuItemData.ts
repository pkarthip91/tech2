import Transfrom from '../../../assest/img/plant/800xA.svg';
import Import_800xA from '../../../assest/img/plant/Import_800xA.svg';
import ObjectConfig from '../../../assest/img/plant/object-config.svg';



import { MenuItemsData } from 'features/common/menuBar/MenuItemDataClass';

export const xA800ImportMenuItemsData: MenuItemsData =
  new MenuItemsData('', "", '800xA Import', Import_800xA,
    [
      new MenuItemsData('ImportTo800xA', '', 'Import to 800xA', Import_800xA, []),
      new MenuItemsData('ObjectConfiguration', '', 'Object Configuration', ObjectConfig, [])
    ]
  );