import { MenuItemsData } from "../menuBar/MenuItemDataClass";
import { bulkEditMenuItemsData } from "./BulkEditMenuItemData";
import { createNewObjectMenuItemsData } from "./CreateNewObjectMenuItemData";
import { deleteObjectMenuItemsData } from "./DeleteObjectMenuItemData";
import { functionalSpecMenuItemsData } from './FunctionalSpecMenuItemData'
import { reportMenuItemsData } from "./ReportMenuItemData";
import { xA800ImportMenuItemsData } from "./Xa800ImportMenuItemData";


export const ribbonMenuItemsData: MenuItemsData[] = [
  functionalSpecMenuItemsData,
  createNewObjectMenuItemsData,
  bulkEditMenuItemsData,
  xA800ImportMenuItemsData,
  reportMenuItemsData,
  deleteObjectMenuItemsData
];
