import DeleteObject from '../../../assest/img/plant/delete.svg';

import { MenuItemsData } from 'features/common/menuBar/MenuItemDataClass';

export const deleteObjectMenuItemsData: MenuItemsData =
  new MenuItemsData('', "", 'Delete Object', DeleteObject,
    [

    ]
  );