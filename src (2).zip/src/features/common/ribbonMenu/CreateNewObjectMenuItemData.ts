import Create_New_Object from 'assest/img/plant/Create_New_Object.svg';
import UM from 'assest/img/plant/UM.svg';
import UM_IO_List from 'assest/img/plant/UM_IO_List.svg';
import SIM from 'assest/img/plant/SIM.svg';
import EM from 'assest/img/plant/EM.svg';
import CMT from 'assest/img/plant/CMT.svg';
import CA from 'assest/img/plant/CA.svg';

import { MenuItemsData } from 'features/common/menuBar/MenuItemDataClass';

export const createNewObjectMenuItemsData: MenuItemsData =
  new MenuItemsData('', "", 'Create New Object', Create_New_Object,
    [
      new MenuItemsData('createUM', '', 'UM', UM, []),
      new MenuItemsData('UMFromIOList', '', 'UM From IO List', UM_IO_List, []),
      new MenuItemsData('SIM', '', 'SIM', SIM, []),
      new MenuItemsData('EM', '', 'EM', EM, []),
      new MenuItemsData('CMT', '', 'CMT', CMT, []),
      new MenuItemsData('CA', '', 'CA', CA, []),
    ]
  );