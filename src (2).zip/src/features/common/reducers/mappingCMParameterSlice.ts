import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { getCMMappingParameter } from '../actions/mappingCMParameterAction';
import { IMappingCMParameter } from '../models/mappingCMParameterInterface';

interface IMappingParameterState {
  loading: boolean,
  mappingCMParameter: IMappingCMParameter[] | null,
  error: string | null
}
const initialState: IMappingParameterState = {
  loading: true,
  mappingCMParameter: null,
  error: null
}

export const mappingCMParameterReducer = createSlice({
  name: 'MappingParameterReducer',
  initialState,
  reducers: {
  },
  extraReducers: (builder) => {
    builder
      .addCase(getCMMappingParameter.pending, (state) => {
        state.loading = true;
      })
      .addCase(getCMMappingParameter.fulfilled, (state, { payload }: any) => {
        state.loading = false;
        state.mappingCMParameter = payload;
      })
      .addCase(getCMMappingParameter.rejected, (state, { payload }: any) => {
        state.loading = false;
        state.error = payload
      });
  },
});
export default mappingCMParameterReducer.reducer;