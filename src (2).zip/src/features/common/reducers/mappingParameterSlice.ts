import { createSlice } from '@reduxjs/toolkit';
import { getMappingParameter } from '../actions/mappingParamterActions';
import { IMappingParameter } from '../models/mappingParameterInterfcae';

interface IMappingParameterState {
  loading: boolean,
  mappingParameter: IMappingParameter[] | null,
  error: string | null
}
const initialState: IMappingParameterState = {
  loading: true,
  mappingParameter: null,
  error: null
}

export const mappingParameterReducer = createSlice({
  name: 'MappingParameterReducer',
  initialState,
  reducers: {
  },
  extraReducers: (builder) => {
    builder
      .addCase(getMappingParameter.pending, (state) => {
        state.loading = true;
      })
      .addCase(getMappingParameter.fulfilled, (state, { payload }: any) => {
        state.loading = false;
        state.mappingParameter = payload;
      })
      .addCase(getMappingParameter.rejected, (state, { payload }: any) => {
        state.loading = false;
        state.error = payload
      });
  },
});
export default mappingParameterReducer.reducer;