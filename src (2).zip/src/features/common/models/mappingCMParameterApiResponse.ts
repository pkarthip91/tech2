export type CMParameterResponse={
    cM_ID : string;
    paramName : string;
    direction : string;
    portIndex: string;
    cmName: string;
    fdPort: string;
}