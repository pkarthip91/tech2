export interface IMappingCMParameter{
    cmId : string;
    cmType : string;
    paramName : string;
    direction : string;
    portIndex : number;
}