export interface IMappingParameter {
    cmType: string;
    cmParameter: string;
    cmElement: string;
    feTable: string;
    feParameter: string;
    alertSubtype: string;
}
