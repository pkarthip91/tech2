import {IMappingCMParameter} from './mappingCMParameterInterface';

class MappingCMParameter implements IMappingCMParameter{
    cmId: string;
    cmType: string;
    paramName: string;
    direction: string;
    portIndex: number;
    constructor(cmId:string,
        cmType:string,
        paramName:string,
        direction:string,
        portIndex:number){
            this.cmId=cmId;
            this.cmType=cmType;
            this.paramName=paramName;
            this.direction=direction;
            this.portIndex=portIndex;
        }
}
export {MappingCMParameter}