export type  MappingParameterApiResponse={
    pcdL_CM_Type : string;
    pcsD_CM_Parameter : string;
    pcsD_IO_Alarm_Subtype : string;
    pcsD_Table : string;
    paramName : string;
}