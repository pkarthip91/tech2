import { IMappingParameter } from './mappingParameterInterfcae';
class MappingParameter implements IMappingParameter {
    constructor(cmType: string = '',
        cmParameter: string = '',
        feTable: string = '',
        feParameter: string = '',
        alertSubtype: string = ''
    ) {
        this.cmType = cmType;
        this.cmParameter = cmParameter;
        this.cmElement = cmType;
        this.feTable = feTable;
        this.feParameter = feParameter;
        this.alertSubtype = alertSubtype;
    }

    cmType: string;
    cmParameter: string;
    cmElement: string;
    feTable: string;
    feParameter: string;
    alertSubtype: string;
}

export { MappingParameter }