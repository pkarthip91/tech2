import { createAsyncThunk } from "@reduxjs/toolkit";
import { Logger } from "../../../app/common/LoggerService";
import { PlantTreeResponseType } from "../models/PlantViewResponseType";
import { PLANT_VIEW_DATA_ACTION, PLANT_VIEW_DATA_ACTION_FAIL, PLANT_VIEW_REDUCER } from "../PlantViewConstant";
import { plantViewDataService } from "../service/PlantViewApiService";

export const plantViewDataAction = createAsyncThunk(
  `${PLANT_VIEW_REDUCER}/${PLANT_VIEW_DATA_ACTION}`,
  async ({ userToken, currentDB }: any, { rejectWithValue }: any) => {
    let result = null
    try {
      const response = await plantViewDataService(userToken, currentDB)
      Logger.info('Plant api- ', response)
      if (response.status === 200 && response.data) {
        try {
          const plantViewResponseData: { pscdInfo: PlantTreeResponseType[], dbMessage: string } = response.data
          result = plantViewResponseData
        } catch (error: any) {
          Logger.error(PLANT_VIEW_DATA_ACTION, error)
          result = rejectWithValue(PLANT_VIEW_DATA_ACTION_FAIL)
        }
      } else {
        result = rejectWithValue(PLANT_VIEW_DATA_ACTION_FAIL)
      }
    } catch (error: any) {
      Logger.error(PLANT_VIEW_DATA_ACTION_FAIL)
      if (error.response.data || error.message) {
        result = rejectWithValue(error.response.data || error.message)
      } else {
        result = rejectWithValue(PLANT_VIEW_DATA_ACTION_FAIL)
      }
    }
    return result
  }
)
