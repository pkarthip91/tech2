import { PlantView } from "./components/PlantView";

export {
  PlantView
}