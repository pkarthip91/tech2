import React, { useState, useEffect } from 'react';
import { NodeHeader } from './NodeHeader';
import { PlantTreeNodeViewModel } from '../models/PlantViewModel';
import { useAppDispatch } from '../../../app/hooks';
import { selectedNodeAction } from '../reducer/PlantViewSlice';

export const NodeViewer = (props: any) => {
  const node: PlantTreeNodeViewModel = props.node;
  const [isOpen, setIsOpen] = useState(false);
  const dispatch = useAppDispatch()

  const onToggle = () => { setIsOpen(!isOpen); dispatch(selectedNodeAction(node)) }

  return (
    <>
      {node && <div className='nodeViewer'>
        <NodeHeader className='table-section_main' node={node} isOpen={isOpen} onToggle={onToggle} handleDoubleClick={props.handleDoubleClick} />
        <div className='node-full-hover'>
          {
            isOpen && node.nodeChild?.length &&
            <div className='table-section'>
              <div className='Collapsible-hasChildren'>
                {node.nodeChild.map((child: PlantTreeNodeViewModel, i: number) => (
                  <NodeViewer key={i} node={child} handleDoubleClick={props.handleDoubleClick} />
                ))}
              </div>
            </div>
          }
        </div>
      </div>}
    </>
  );
}