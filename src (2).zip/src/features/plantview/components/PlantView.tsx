import { useEffect, useState } from 'react';
import { useAppSelector, useAppDispatch } from '../../../app/hooks'

import { NodeViewer } from './NodeViewer';
import { plantviewBody, plantviewHeader, plantviewWrapper } from '../styles/PlantViewStyle';
import { plantViewDataAction } from '../actions/PlantViewActions';
import { IPlantViewState } from '../models/PlantViewInterface';
import { mapPlantViewDataAction, selectedUnitAction } from '../reducer/PlantViewSlice';
import { selectedViewAction } from '../../home/reducer/HomeSlice';
import { childViews } from '../../home/HomeModels';
import { getMappingParameter } from '../../common/actions/mappingParamterActions';
import { getCMMappingParameter } from '../../common/actions/mappingCMParameterAction';
import { setInformationAction } from '../../informationBar/reducer/InformationBarSlice';

import { Table } from '@abb/abb-common-ux-react';
import { mapPlantTreeResponseData } from '../service/PlantViewHelperService';
import { IImportXMLInsertState } from '../../importXML/interface/ImportXMLInterface';
import { PlantTreeNodeViewModel } from '../models/PlantViewModel';
import { RibbonMenu } from '../../common/ribbonMenu/components/RibbonMenu';
import { FilterTreeNode } from '../../home/appToolbar/FilterTreeNode'
import { AppToolbarSearchField } from '../../home/appToolbar/AppToolbarSearchField';
import { InputXML } from '../../importXML/components/ImportXML';

import React from 'react';
import { ICreateUmInsertState } from 'features/createUM/interface/CreateUmInterface';

export const PlantView = () => {
  const { userToken } = useAppSelector((state: any) => state.auth)
  const { currentDB, filterTreeNodeSelection } = useAppSelector((state: any) => state.home)
  const { loading, plantViewData, PlantResponseData, dbMessage } = useAppSelector<IPlantViewState>((state: any) => state.plantview)
  const { xmlInsertData } = useAppSelector<IImportXMLInsertState>((state: any) => state.importXMLInsert)
  const { createUmInsertData } = useAppSelector<ICreateUmInsertState>((state: any) => state.createUmInsert)
  const [isShowDbMessage, setIsShowDbMessage] = useState<boolean>(true)

  const dispatch = useAppDispatch();

  const updatePlantVIew = () => { currentDB && dispatch(plantViewDataAction({ userToken, currentDB })) }

  useEffect(() => { updatePlantVIew(); setIsShowDbMessage(true); }, [currentDB]);
  useEffect(() => {
    if (xmlInsertData || createUmInsertData) {
      setIsShowDbMessage(false);
      updatePlantVIew();
    }
  }, [xmlInsertData, createUmInsertData])

  useEffect(() => {
    PlantResponseData &&
      dispatch(mapPlantViewDataAction(mapPlantTreeResponseData(
        filterTreeNodeSelection == 'ALL' ?
          PlantResponseData :
          PlantResponseData.filter((p: any) => p.eMorUM == filterTreeNodeSelection)
      )))
  }, [PlantResponseData, filterTreeNodeSelection]);

  useEffect(() => {
    if (isShowDbMessage) {
      dispatch(setInformationAction({ message: dbMessage }));
    }
  }, [dbMessage]);

  useEffect(() => { plantViewData && dispatch(getMappingParameter(userToken)) }, [plantViewData]);
  useEffect(() => { plantViewData && dispatch(getCMMappingParameter(userToken)) }, [plantViewData]);

  const handleDoubleClick = (selectedUnit: PlantTreeNodeViewModel) => {
    dispatch(selectedUnitAction(selectedUnit));
    dispatch(selectedViewAction(childViews.unitview));
  }

  return (
    <div className='plantView_main'>
       <div className='ribbon-menus'>
              <RibbonMenu />
            </div>

            <div className='app-content'>
      {loading ? "loading..." :
        (<div style={plantviewWrapper}>

<div className='search-toolbar'>
              <div className='d-line-block toobar-all toobar-radius mr-1'>
                <FilterTreeNode />
              </div>
              <div className='d-line-block toobar-radius toobar-main'>
                <AppToolbarSearchField />
              </div>
            </div>

          <div style={plantviewHeader}>
            <Table>
              <thead>
                <tr>
                  <th>Object Name</th>
                  <th>Object Module Name</th>
                  <th>Description</th>
                  <th>Date/Time</th>
                  <th>File Path</th>
                </tr>
              </thead>
            </Table>

          </div>

          <div className='nodeBody' style={plantviewBody}>
            <div className='nodeSection'>
              {
                (plantViewData && plantViewData.length) ?
                  plantViewData.map((plant: PlantTreeNodeViewModel, i: number) => (
                    <div className='nodeMain-row' key={i} >
                      <NodeViewer node={plant} handleDoubleClick={handleDoubleClick} />
                    </div>
                  )
                  ) :
                  (!loading && "No Plant data available!")
              }
            </div>
          </div>
        </div>)}
        </div>
    </div>
  );
}
