import { PlantTreeNodeViewModel } from "../models/PlantViewModel";
import { Table, Icon } from '@abb/abb-common-ux-react';
import { nodeHeader } from "../styles/PlantViewStyle";

import { dateTimeFormatter } from "../../../app/utility";
import { TreeNodeUnitType } from "../models/Enums";
import { useAppSelector } from "../../../app/hooks";
import { IPlantViewState } from "../models/PlantViewInterface";
import React from "react";


export const NodeHeader = (props: any) => {
  const node: PlantTreeNodeViewModel = props.node;
  const isOpen: boolean = props.isOpen;
  const onToggle: any = props.onToggle;
  const handleDoubleClick = props.handleDoubleClick;
  const { selectedNode } = useAppSelector<IPlantViewState>((state: any) => state.plantview)

  return (
    <>
      {node && <div className="nodeHeader" style={{ ...nodeHeader, backgroundColor: node === selectedNode ? '#E0F0FF' : 'transparent' }} onClick={onToggle}
        onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#ebebeb'}
        onMouseLeave={(e) => !(node === selectedNode) && (e.currentTarget.style.backgroundColor = 'transparent')}
      >
        {node.nodeChild?.length ?
          <div className="p-left-20">
            <span className={isOpen ? "nodeOpen" : "nodeClose"}></span>
            <img src={node.icon() || undefined} className="node-plant-icon" alt="" />
            <span className="col" >{node.name()}</span>
          </div> :
          <div className="tableSection1" onDoubleClick={() => handleDoubleClick(node)}>
            <Table>
              <tbody className="inside-module">
                <tr>
                  <td className="moduleName">
                    <img src={node.icon() || undefined} className="node-icons" alt="" />
                    <span>{node.name()}
                      <Icon className="dot-icons node-plant-icon" name="abb/more" sizeClass={'small'} />
                    </span>
                  </td>
                  <td><span>{node.moduleName()}</span></td>
                  <td><span>{node.description()}</span></td>
                  <td><span dangerouslySetInnerHTML={{ __html: node.lastModifiedDate()?.replace(',', '&nbsp&nbsp') || "" }}></span></td>
                  <td><span>{node.filePath()}</span></td>
                </tr>
              </tbody>
            </Table>
          </div>
        }
      </div>}
    </>
  );
}