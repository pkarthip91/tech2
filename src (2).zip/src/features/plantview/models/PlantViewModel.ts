import { randomString } from "../../../app/utility";
import { getTreeNodeIcon } from "../service/PlantViewImageService";
import { PlantTreeNodeType, TreeNodeUnitType } from "./Enums";
import { PlantTreeResponseType } from "./PlantViewResponseType";

export class PlantTreeNodeDataModel {
  // public eMorUM: string = '';
  // public fileName: string = '';
  // public objName: string = '';
  // public dateTime: Date | null = null;
  // public filePath: string = '';
  // public plantName: string = '';
  // public unitName: string = '';
  // public description: string = '';
  // public dtnseqName: string = '';
  // public reservedBy: string = '';
  // public pcsDdataKey: number | null = null;
  // public designerName: string = '';
  // public revNumber: string = '';
  // public revComment: string = '';
  // public unitStatus: string = '';
  // public lastUpdated: Date | null = null;
  // public lastTransformed: Date | null = null;
  // public areaName: string = '';
  // public cellName: string = '';
  // public isUMinst: boolean | null = null;
  // public published: boolean | null = null;
  // public isMultiuse: boolean | null = null;
  // public relatedDataKey: number | null = null;
  // public templateName: string = '';
  constructor(public data: PlantTreeResponseType) {

  }
}

export class PlantTreeNodeViewModel {
  constructor(
    public nodeId: string = randomString(),
    public nodeType: PlantTreeNodeType | null = null,
    public nodeData: PlantTreeResponseType | null = null,
    public nodeChild: PlantTreeNodeViewModel[] | null = null
  ) { }

  public name = (): string | undefined | null => {
    let name: string | undefined | null = null
    switch (this.nodeType) {
      case PlantTreeNodeType.plant: name = this.nodeData?.plantName; break;
      case PlantTreeNodeType.unit: name = this.nodeData?.unitName; break;
      case PlantTreeNodeType.cell: name = this.nodeData?.cellName; break;
      case PlantTreeNodeType.area: name = this.nodeData?.areaName; break;
    }
    return name;
  }

  public description = (): string | undefined | null => {
    let description: string | undefined | null = null
    description = this.nodeData?.description
    return description
  }

  public moduleName = (): string | undefined | null => {
    let moduleName: string | undefined | null = null
    moduleName = new Array(this.nodeData?.objName, this.nodeData?.objType).filter(f => f).join(', ')
    return moduleName
  }

  public lastModifiedDate = (): string | undefined | null => {
    let lastModifiedDate: string | undefined | null = null
    if (this.nodeData?.lastUpdated) {
      lastModifiedDate = new Date(this.nodeData?.lastUpdated).toLocaleString()
    }
    return lastModifiedDate
  }

  public filePath = (): string | undefined | null => {
    let filePath: string | undefined | null = null
    filePath = this.nodeData?.filePath
    return filePath
  }

  public icon = (): string | undefined | null => {

    let icon: string | undefined | null = null
    if (this.nodeType) {
      if (this.nodeType != PlantTreeNodeType.unit) {
        icon = getTreeNodeIcon(this.nodeType)
      } else {
        let unitType: TreeNodeUnitType | null = this.unitType()
        if (unitType) {
          icon = getTreeNodeIcon(this.nodeType, unitType)
        }
      }
    }
    return icon
  }

  private unitType = (): TreeNodeUnitType | null => {
    let type: TreeNodeUnitType | null = null
    let pData = this.nodeData
    if (pData) {
      if (pData.eMorUM == "EM") {
        if (pData.published) {
          type = TreeNodeUnitType.equipmentApproved
        }
        else {
          type = TreeNodeUnitType.equipmentUnApproved
        }
      }
      else if (pData.unitName?.endsWith("SIM")) {
        if (pData.isUMinstance && pData.published) {
          type = TreeNodeUnitType.multiuseApproveSIMdAppType
        }
        else {
          type = TreeNodeUnitType.unApproved
        }
      }
      else {
        if (pData.isUMinstance) {
          if (pData.published) {
            type = TreeNodeUnitType.multiuseApprovedAppType
          }
          else {
            type = TreeNodeUnitType.multiuseUnApproved
          }
        }
        else {
          if (pData.published) {
            if (pData.isMultiuse) {
              type = TreeNodeUnitType.multiuseApprovedObjectType
            }
            else {
              type = TreeNodeUnitType.approved
            }
          }
          else {
            type = TreeNodeUnitType.unApproved
          }
        }
      }
    }

    return type
  }

}
