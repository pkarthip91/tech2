export enum PlantTreeNodeType {
  plant = 1,
  area,
  cell,
  unit
}

export enum TreeNodeUnitType {
  approved = 1,
  unApproved,
  multiuseApprovedObjectType,
  multiuseApprovedAppType,
  multiuseApproveSIMdAppType,
  multiuseUnApproved,
  simulation,
  equipmentApproved,
  equipmentUnApproved
}