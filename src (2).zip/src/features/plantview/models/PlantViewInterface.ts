import { PlantTreeNodeViewModel } from "./PlantViewModel";
import { PlantTreeResponseType } from "./PlantViewResponseType";

export interface IPlantViewState {
  loading: boolean,
  PlantResponseData: PlantTreeResponseType[] | null,
  dbMessage: string,
  plantViewData: PlantTreeNodeViewModel[] | null,
  selectedUnit: PlantTreeNodeViewModel | null,
  selectedNode: PlantTreeNodeViewModel | null,
  error: string | null
}