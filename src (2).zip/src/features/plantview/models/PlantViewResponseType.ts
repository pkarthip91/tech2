

export type PlantTreeResponseType = {
  pcsDdataKey: number,
  eMorUM: string,
  pcsdName: string | null,
  objName: string,
  objType: string | null,
  dateTime: Date | null,
  filePath: string,
  fileName: string,
  description: string,
  dtnseqName: string,
  reservedBy: string,
  plantName: string,
  areaName: string,
  cellName: string,
  unitName: string | null,
  designerName: string,
  revNumber: number | null,
  revComment: string,
  unitStatus: string,
  published: boolean,
  isUMinstance: boolean,
  isMultiuse: boolean,
  templateName: string,
  lastTransformed: Date | null,
  lastUpdated: Date | null
}