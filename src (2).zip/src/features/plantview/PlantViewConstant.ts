export const PLANT_VIEW_REDUCER = 'plantview'
export const PLANT_VIEW_DATA_ACTION = 'plantViewDataAction'
export const PLANT_VIEW_DATA_ACTION_FAIL = 'Plant View data loding failed!'
