import CSS from 'csstype';

export const plantviewWrapper: CSS.Properties = {
  width: '100%',
  fontSize: '12px'
}

export const plantviewHeader: CSS.Properties = {
  backgroundColor: 'grey',
  display: 'flex',
  color: 'white'
}

export const plantviewBody: CSS.Properties = {
}

export const fieldName: CSS.Properties = {
  // width: '250px'
  display: 'inline-flex'
}

export const fieldModuleName: CSS.Properties = {
 // width: '150px'
 display: 'inline-flex'
}
export const fieldFilePath: CSS.Properties = {
  width: '350px'
}
export const nodeViewer: CSS.Properties = {
  position: 'relative'
}

export const nodeChild: CSS.Properties = {
  paddingLeft: '20px'
}

export const nodeHeader: CSS.Properties = {
  position: 'relative',
  cursor: 'pointer',
  padding: '0px 15px',
  display: 'block',
}

export const nodeTitle: CSS.Properties = {
  // width: '150px',
  display: 'inline-flex'
}

export const nodeFields: CSS.Properties = {
  // width: '150px',
  display: 'inline-flex'
}
export const nodeFieldFilePath: CSS.Properties = {
  // width: '350px',
  display: 'inline-flex'
}
export const nodeOpen: CSS.Properties = {
  width: 0,
  height: 0,
  borderLeft: "5px solid transparent",
  borderRight: "5px solid transparent",
  borderTop: "10px solid grey",
  display: 'inline-grid'
}

export const nodeClose: CSS.Properties = {
  width: 0,
  height: 0,
  borderTop: "5px solid transparent",
  borderBottom: "5px solid transparent",
  borderLeft: "10px solid grey",
  display: 'inline-grid'
}