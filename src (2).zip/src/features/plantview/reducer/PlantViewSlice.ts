import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { plantViewDataAction } from '../actions/PlantViewActions';
import { IPlantViewState } from '../models/PlantViewInterface';
import { PLANT_VIEW_REDUCER } from '../PlantViewConstant';
import { PlantTreeNodeViewModel } from '../models/PlantViewModel';


const initialState: IPlantViewState = {
  loading: true,
  PlantResponseData: null,
  dbMessage: '',
  plantViewData: null,
  selectedUnit: null,
  selectedNode: null,
  error: null
}

export const plantviewSlice = createSlice({
  name: `${PLANT_VIEW_REDUCER}`,
  initialState,
  reducers: {
    selectedUnitAction: (state, action: PayloadAction<PlantTreeNodeViewModel>) => {
      state.selectedUnit = action.payload
    },
    mapPlantViewDataAction: (state, action: PayloadAction<PlantTreeNodeViewModel[]>) => {
      state.plantViewData = action.payload
    },
    selectedNodeAction: (state, action: PayloadAction<PlantTreeNodeViewModel>) => {
      state.selectedNode = action.payload
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(plantViewDataAction.pending, (state) => {
        state.loading = true;
        state.plantViewData = null;
        state.selectedUnit = null;
        state.dbMessage = 'Connecting to Database...'
      })
      .addCase(plantViewDataAction.fulfilled, (state, { payload }: any) => {
        state.loading = false;
        state.PlantResponseData = payload.pcsdInfo
        state.dbMessage = payload.dbMessage
      })
      .addCase(plantViewDataAction.rejected, (state, { payload }: any) => {
        state.loading = false;
        state.error = payload
      });
  },
});
export const { selectedUnitAction, mapPlantViewDataAction, selectedNodeAction } = plantviewSlice.actions;
export default plantviewSlice.reducer;
