import plantNodeImage from '../../../assest/img/plant/800xA.svg'
import areaNodeImage from '../../../assest/img/plant/area.svg'
import cellNodeImage from '../../../assest/img/plant/cell 1.svg'

import approvedUnitNodeImage from '../../../assest/img/plant/reactor 1.svg'
import unApprovedUnitNodeImage from '../../../assest/img/plant/reactor_not_approved.svg'
import multiuseApprovedObjectTypeNodeImage from '../../../assest/img/plant/reactor_BlueWithTLetter.svg'
import multiuseApprovedAppTypeNodeImage from '../../../assest/img/plant/reactor_BlueWithXLetter.svg'
import multiuseApprovedSIMAppTypeNodeImage from '../../../assest/img/plant/reactor_SIM_BlueWithXLetter.svg'
import multiuseUnApprovedNodeImage from '../../../assest/img/plant/reactor_not_approved_BlueWithXLetter.svg'
import simulationNodeImage from '../../../assest/img/plant/reactor_SIM 1.svg'
import equipmentApprovedNodeImage from '../../../assest/img/plant/module_approved.svg'
import equipmentUnApprovedNodeImage from '../../../assest/img/plant/module_not_approved.svg'

import { PlantTreeNodeType, TreeNodeUnitType } from '../models/Enums'

export const getTreeNodeIcon = (nodeType: PlantTreeNodeType, unitIconType?: TreeNodeUnitType): string => {
  let icon: string = ''

  switch (nodeType) {
    case PlantTreeNodeType.plant: icon = plantNodeImage; break;
    case PlantTreeNodeType.area: icon = areaNodeImage; break;
    case PlantTreeNodeType.cell: icon = cellNodeImage; break;
    case PlantTreeNodeType.unit: icon = getUnitNodeIcon(unitIconType); break;
  }
  return icon
}

const getUnitNodeIcon = (unitIconType?: TreeNodeUnitType): string => {
  let icon: string = ''

  switch (unitIconType) {
    case TreeNodeUnitType.approved: icon = approvedUnitNodeImage; break;
    case TreeNodeUnitType.unApproved: icon = unApprovedUnitNodeImage; break;
    case TreeNodeUnitType.equipmentApproved: icon = equipmentApprovedNodeImage; break;
    case TreeNodeUnitType.equipmentUnApproved: icon = equipmentUnApprovedNodeImage; break;
    case TreeNodeUnitType.multiuseApprovedAppType: icon = multiuseApprovedAppTypeNodeImage; break;
    case TreeNodeUnitType.multiuseApproveSIMdAppType: icon = multiuseApprovedSIMAppTypeNodeImage; break;
    case TreeNodeUnitType.multiuseApprovedObjectType: icon = multiuseApprovedObjectTypeNodeImage; break;
    case TreeNodeUnitType.multiuseUnApproved: icon = multiuseUnApprovedNodeImage; break;
    case TreeNodeUnitType.simulation: icon = simulationNodeImage; break;
  }

  return icon
}

