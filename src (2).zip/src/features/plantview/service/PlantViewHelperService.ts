import { PlantTreeNodeType } from "../models/Enums";
import { PlantTreeNodeViewModel } from "../models/PlantViewModel";
import { PlantTreeResponseType } from "../models/PlantViewResponseType";

// const sortByName = (objArray: IPlantViewModel[]): void => {
//   objArray.sort((a, b) => (a.getName() == b.getName()) ? 0 : ((a.getName() > b.getName()) ? 1 : -1))
//   objArray.map((obj => sortByName(obj.getChildView() || [])))
// }

const createPlantTreeNode = (type: PlantTreeNodeType, data: PlantTreeResponseType): PlantTreeNodeViewModel => {
  let node = new PlantTreeNodeViewModel()
  node.nodeType = type
  node.nodeData = data
  return node
}

const mapPlantTreeResponseData = (plantTreeResponseData: PlantTreeResponseType[]): PlantTreeNodeViewModel[] => {
  let mappedPlantTree: PlantTreeNodeViewModel[] = [];
  plantTreeResponseData.map((plantData: PlantTreeResponseType) => {
    let plant = JSON.parse(JSON.stringify(plantData))
    plant.plantName = plant.plantName || 'Default'
    plant.unitName = plant.unitName || plant.pcsdName
    !plant.unitName && (plant.objName = 'Default')

    let plantNode: PlantTreeNodeViewModel | null = null
    let areaNode: PlantTreeNodeViewModel | null = null
    let cellNode: PlantTreeNodeViewModel | null = null

    let mappedPlantNode = mappedPlantTree.find((p) => p.nodeData?.plantName == plant.plantName) || null
    if (!mappedPlantNode) {
      plantNode = createPlantTreeNode(PlantTreeNodeType.plant, plant)
      mappedPlantTree.push(plantNode)
    } else {
      plantNode = mappedPlantNode
    }

    if (plant.areaName && plant.areaName != '') {
      let areaExist = plantNode?.nodeChild?.find(
        (child: PlantTreeNodeViewModel) => child.nodeData?.areaName == plant.areaName) || null
      if (!areaExist) {
        areaNode = createPlantTreeNode(PlantTreeNodeType.area, plant)
        if (areaNode) {
          if (plantNode.nodeChild) {
            plantNode?.nodeChild?.push(areaNode)
          } else {
            plantNode.nodeChild = new Array(areaNode)
          }
        }
      } else {
        areaNode = areaExist
      }
    }

    if (plant.cellName && plant.cellName != '') {
      let cellExist = null
      let areas = plantNode?.nodeChild || []
      for (let i = 0; i < areas.length; i++) {
        cellExist = areas[i].nodeChild?.find(
          (cell: PlantTreeNodeViewModel) => cell.nodeData?.cellName === plant.cellName)
        if (cellExist) break
      }
      if (!cellExist) {
        let areaExist = plantNode?.nodeChild?.find(
          (area: PlantTreeNodeViewModel) => area.nodeData?.areaName === plant.areaName)
        if (areaExist) {
          cellNode = createPlantTreeNode(PlantTreeNodeType.cell, plant)
          if (cellNode) {
            if (areaExist.nodeChild) {
              areaExist.nodeChild?.push(cellNode)
            } else {
              areaExist.nodeChild = new Array(cellNode)
            }

          }
        }
      } else {
        cellNode = cellExist
      }
    }

    if (plant.unitName && plant.unitName != '') {
      let unitObject = createPlantTreeNode(PlantTreeNodeType.unit, plant)
      if (unitObject) {
        let childNode = cellNode ? cellNode :
          (areaNode ? areaNode : (plantNode ? plantNode : null))
        if (childNode) {
          if (childNode.nodeChild) {
            if (!childNode.nodeChild?.find(c => c.nodeData?.unitName === plant.unitName))
              childNode.nodeChild?.push(unitObject)
          } else {
            childNode.nodeChild = new Array(unitObject)
          }
        }
      }
    }

  })

  if (mappedPlantTree.length)
    mappedPlantTree = sortTree(mappedPlantTree)

  return mappedPlantTree;
}

const sortTree1 = (mappedPlantTree: PlantTreeNodeViewModel[]): PlantTreeNodeViewModel[] => {
  for (let p = 0; p < mappedPlantTree.length; p++) {
    let plant = mappedPlantTree[p]
    if (plant.nodeChild) {
      let areas = mappedPlantTree[p].nodeChild
      if (areas) {
        for (let a = 0; a < areas.length; a++) {
          let cells = areas[a].nodeChild
          if (cells) {
            for (let c = 0; c < cells.length; c++) {
              let units = cells[c].nodeChild
              if (units) {
                units = sortUnitByType(units)
              }
            }
          }
        }
      }
    }
  }
  return mappedPlantTree
}

const sortTree = (mappedPlantTree: PlantTreeNodeViewModel[]): PlantTreeNodeViewModel[] => {
  for (let p = 0; p < mappedPlantTree.length; p++) {
    let plant = mappedPlantTree[p]
    if (plant.nodeChild) {
      let plantChild = plant.nodeChild
      if (plantChild) {
        plantChild = sortChild(plantChild)
        for (let a = 0; a < plantChild.length; a++) {
          let areaChild = plantChild[a].nodeChild
          if (areaChild) {
            areaChild = sortChild(areaChild)
            for (let c = 0; c < areaChild.length; c++) {
              let units = areaChild[c].nodeChild
              if (units) {
                units = sortUnitByType(units)
              }
            }
          }
        }
      }
    }
  }
  return mappedPlantTree
}

const sortChild = (child: PlantTreeNodeViewModel[]): PlantTreeNodeViewModel[] => {
  let areas: PlantTreeNodeViewModel[] = []
  let cells: PlantTreeNodeViewModel[] = []
  let units: PlantTreeNodeViewModel[] = []
  for (let c = 0; c < child.length; c++) {
    switch (child[c].nodeType) {
      case PlantTreeNodeType.area: areas.push(child[c]); break;
      case PlantTreeNodeType.cell: cells.push(child[c]); break;
      case PlantTreeNodeType.unit: units.push(child[c]); break;
    }
  }
  units = sortUnitByType(units)
  child.splice(0, child.length)
  child.push(...areas, ...cells, ...units)
  return child
}

const sortUnitByType = (units: PlantTreeNodeViewModel[]): PlantTreeNodeViewModel[] => {

  let simUnits = []
  for (let u = 0; u < units.length; u++) {
    if (units[u].nodeData?.unitName?.endsWith('SIM')) {
      simUnits.push(units[u])
      units.splice(units.indexOf(units[u]), 1)
    }
  }
  for (let um = 0; um < units.length; um++) {
    if (units) {
      let simUnit = simUnits.find(
        s => units && (s.nodeData?.unitName === units[um].nodeData?.unitName + 'SIM'))
      if (simUnit) {
        units.splice(um + 1, 0, simUnit)
        simUnits.splice(simUnits.indexOf(simUnit), 1)
      }
    }
  }
  if (simUnits.length) {
    for (let sm = 0; sm < simUnits.length; sm++) {
      units.push(simUnits[sm])
    }
  }
  return units
}

export { mapPlantTreeResponseData }