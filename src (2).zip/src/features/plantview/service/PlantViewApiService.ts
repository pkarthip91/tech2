import { httpClient } from '../../../app/api/middlewareSecurity'

export const plantViewDataService = (userToken: string, currentDB: string) => {
  return httpClient.get(`/plant/${currentDB}`, {
    headers: {
      "Authorization": `Bearer ${userToken}`,
      "Accept": "text/plain"
    }
  })
}

