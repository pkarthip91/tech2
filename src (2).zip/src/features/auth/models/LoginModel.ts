export interface ILogin {
  userName: string | undefined,
  password: string | undefined,
  rememberMe: boolean
}