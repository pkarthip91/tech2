import { createAsyncThunk } from "@reduxjs/toolkit";
import { appConstant } from "../../../app/common/Constant";
import { ClientStorage } from "../../../app/utility/ClientStorageUtility";
import { authConstant } from "../AuthConstant";
import { userLoginService } from "../login/service/LoginService";
import { ILogin } from "../models/LoginModel";

export const userLoginAction = createAsyncThunk(
  `${authConstant.AUTH_REDUCER}/${authConstant.USER_LOGIN_ACTION}`,
  async ({ userName, password, rememberMe }: ILogin, { rejectWithValue }: any) => {
    let result: any = null
    try {
      const { data } = await userLoginService({ userName, password, rememberMe })
      if (data) {
        ClientStorage.add(appConstant.USER_DATA, JSON.stringify({ userToken: data, userInfo: { userName } }))
        result = { userToken: data, userInfo: { userName } }
      } else {
        result = rejectWithValue(authConstant.LOGIN_FAIL_MESSAGE)
      }
    } catch (error: any) {
      if (error.response.data || error.message) {
        result = rejectWithValue(error.response.data || error.message)
      } else {
        result = rejectWithValue(authConstant.LOGIN_FAIL_MESSAGE)
      }
    }
    return result
  }
)
