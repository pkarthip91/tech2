export const authConstant: any = {
  LOGIN_FAIL_MESSAGE: "Login failed! Please try again!",
  AUTH_REDUCER: 'auth',
  USER_LOGIN_ACTION: 'userLoginAction'
}