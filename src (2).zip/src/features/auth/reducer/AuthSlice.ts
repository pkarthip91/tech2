
import { createSlice } from '@reduxjs/toolkit'
import { appConstant } from '../../../app/common/Constant'
import { ClientStorage } from '../../../app/utility/ClientStorageUtility'
import { userLoginAction } from '../actions/AuthActions'
import { authConstant } from '../AuthConstant'

const userData: string | null = ClientStorage.get(appConstant.USER_DATA)

const initialState = {
  loading: false,
  userInfo: userData ? JSON.parse(userData)?.userInfo : null,
  userToken: userData ? JSON.parse(userData)?.userToken : null,
  error: null
}
const authSlice = createSlice({
  name: authConstant.AUTH_REDUCER,
  initialState,
  reducers: {
    userLogout: (state) => {
      ClientStorage.remove(appConstant.USER_DATA)
      state.loading = false
      state.userInfo = null
      state.userToken = null
      state.error = null
    }
  },
  extraReducers: (builder) => {
    builder
      .addCase(userLoginAction.pending, (state) => {
        state.loading = true;
      })
      .addCase(userLoginAction.fulfilled, (state, { payload }: any) => {
        state.loading = false;
        state.userToken = payload?.userToken;
        state.userInfo = payload?.userInfo;
      })
      .addCase(userLoginAction.rejected, (state, { payload }: any) => {
        state.loading = false;
        state.error = payload
      });
  },
})

export const { userLogout } = authSlice.actions
export default authSlice.reducer