import { LoginScreen } from "@abb/abb-common-ux-react";
import { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import { appConfig } from "../../../../app/appConfig/AppConfig";
import { AppDispatch } from "../../../../app/store";
import { userLoginAction } from "../../actions/AuthActions";
import { ILogin } from "../../models/LoginModel";
import { userLogout } from "../../reducer/AuthSlice";
import { useSearchParams } from 'react-router-dom';

export const LoginComponent = (props: any) => {
  const dispatch = useDispatch<AppDispatch>()
  const navigate = useNavigate()
  const [searchParams] = useSearchParams();
  //force user to logout, if token expired
  useEffect(() => {
    const token_expired = searchParams.get('token_expired');
    if (token_expired) {
      dispatch(userLogout());
    }
  }, [])

  const { loading, userToken, userInfo, error } = useSelector((state: any) => state.auth)

  //On Login button click
  const onLogin = (
    username: string | undefined,
    password: string | undefined,
    rememberMe: boolean) => {
    const data: ILogin = { userName: username, password, rememberMe }
    dispatch(userLoginAction(data))
  }

  //Navigate to Home page, if change in userData
  useEffect(() => { if (userToken && userInfo) { navigate('/') } }, [navigate, userToken, userInfo])

  //TO DO - Remove in-line styles, onece final UI done
  return (
    <>
      <div className="margins shadows browser-reset" style={{ width: '100%', display: 'flex', justifyContent: 'center' }}>

        <LoginScreen
          productName={appConfig.productName}
          productSubName={appConfig.productSubName}
          loading={loading}
          footerText={appConfig.lawText}
          onLogin={onLogin}
          customContent={() => {
            return (
              <div
                style={{
                  color: "red"
                }}
              >
                <p>{error}</p>
              </div>
            );
          }}
        />

      </div>
    </>
  );
}