import { httpClient } from '../../../../app/api/middlewareSecurity'
import { ILogin } from '../../models/LoginModel';

export const userLoginService = (loginData: ILogin) => {
  return httpClient.post('/login',
    { userName: loginData.userName, password: loginData.password });
}