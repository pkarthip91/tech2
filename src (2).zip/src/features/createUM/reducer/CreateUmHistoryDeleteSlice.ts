import { createSlice } from '@reduxjs/toolkit';
import { createUmHistoryDeleteAction } from '../actions/createUmHistoryDeleteAction';
import { CREATE_UM_HISTORY_DELETE_REDUCER } from '../CreateUMConstant';
import { ICreateUmHistoryDeleteState } from '../interface/CreateUmInterface';


const initialState: ICreateUmHistoryDeleteState = {
  createUmHistoryDeleteLoading: null,
  createUmHistoryDeleteData: null,
  createUmHistoryDeleteError: null
}

export const createUmHistoryDeleteSlice = createSlice({
  name: `${CREATE_UM_HISTORY_DELETE_REDUCER}`,
  initialState,
  reducers: {
    resetCreateUmHistoryDeleteStore: (state) => {
      state = initialState
    }
  },
  extraReducers: (builder) => {
    builder
      .addCase(createUmHistoryDeleteAction.pending, (state) => {
        state.createUmHistoryDeleteLoading = true;
        state.createUmHistoryDeleteError = null;
        state.createUmHistoryDeleteData = null;
      })
      .addCase(createUmHistoryDeleteAction.fulfilled, (state, { payload }: any) => {
        state.createUmHistoryDeleteLoading = false;
        state.createUmHistoryDeleteError = null;
        state.createUmHistoryDeleteData = payload
      })
      .addCase(createUmHistoryDeleteAction.rejected, (state, { payload }: any) => {
        state.createUmHistoryDeleteLoading = false;
        state.createUmHistoryDeleteError = payload;
        state.createUmHistoryDeleteData = null;
      });
  },
});
export const { resetCreateUmHistoryDeleteStore } = createUmHistoryDeleteSlice.actions
export default createUmHistoryDeleteSlice.reducer;
