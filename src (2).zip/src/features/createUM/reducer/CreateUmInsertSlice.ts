import { createSlice } from '@reduxjs/toolkit';
import { createUmInsertAction } from '../actions/CreateUmInsertAction';
import { ICreateUmInsertState } from '../interface/CreateUmInterface';
import { CREATE_UM_INSERT_REDUCER } from '../CreateUMConstant';


const initialState: ICreateUmInsertState = {
  createUmInsertLoading: null,
  createUmInsertData: null,
  createUmInsertError: null
}

export const createUmInsertSlice = createSlice({
  name: `${CREATE_UM_INSERT_REDUCER}`,
  initialState,
  reducers: {
  },
  extraReducers: (builder) => {
    builder
      .addCase(createUmInsertAction.pending, (state) => {
        state.createUmInsertLoading = true;
        state.createUmInsertError = null;
        state.createUmInsertData = null;
      })
      .addCase(createUmInsertAction.fulfilled, (state, { payload }: any) => {
        state.createUmInsertLoading = false;
        state.createUmInsertError = null;
        state.createUmInsertData = payload
      })
      .addCase(createUmInsertAction.rejected, (state, { payload }: any) => {
        state.createUmInsertLoading = false;
        state.createUmInsertError = payload;
        state.createUmInsertData = null;
      });
  },
});
export default createUmInsertSlice.reducer;
