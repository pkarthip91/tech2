import { createSlice } from '@reduxjs/toolkit';
import { createUmHistoryAction } from '../actions/CreateUmHistoryAction';
import { CREATE_UM_HISTORY_REDUCER } from '../CreateUMConstant';
import { ICreateUmHistoryState } from '../interface/CreateUmInterface';


const initialState: ICreateUmHistoryState = {
  createUmHistoryLoading: null,
  createUmHistoryData: null,
  createUmHistoryError: null
}

export const createUmHistorySlice = createSlice({
  name: `${CREATE_UM_HISTORY_REDUCER}`,
  initialState,
  reducers: {
    resetCreateUmHistoryStore: (state) => {
      state = initialState
    }
  },
  extraReducers: (builder) => {
    builder
      .addCase(createUmHistoryAction.pending, (state) => {
        state.createUmHistoryLoading = true;
        state.createUmHistoryData = null;
        state.createUmHistoryError = null;
      })
      .addCase(createUmHistoryAction.fulfilled, (state, { payload }: any) => {
        state.createUmHistoryLoading = false;
        state.createUmHistoryError = null;
        state.createUmHistoryData = payload
      })
      .addCase(createUmHistoryAction.rejected, (state, { payload }: any) => {
        state.createUmHistoryLoading = false;
        state.createUmHistoryError = payload;
        state.createUmHistoryData = null;
      });
  },
});
export const { resetCreateUmHistoryStore } = createUmHistorySlice.actions
export default createUmHistorySlice.reducer;
