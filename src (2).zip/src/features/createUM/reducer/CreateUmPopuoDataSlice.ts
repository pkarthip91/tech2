import { createSlice } from '@reduxjs/toolkit';
import { createUmPopupDataAction } from '../actions/CreateUmPopupDataAction';
import { CREATE_UM_GET_POPUP_DATA_REDUCER } from '../CreateUMConstant';
import { ICreateUmPopuoDataState } from '../interface/CreateUmInterface'


const initialState: ICreateUmPopuoDataState = {
  popupDataLoading: null,
  popupData: null,
  popupDataLoadingError: null
}

export const createUmPopupDataSlice = createSlice({
  name: `${CREATE_UM_GET_POPUP_DATA_REDUCER}`,
  initialState,
  reducers: {
    resetCreateUmPopupDataStore: (state) => {
      state = initialState
    }
  },
  extraReducers: (builder) => {
    builder
      .addCase(createUmPopupDataAction.pending, (state) => {
        state.popupDataLoading = true;
        state.popupDataLoadingError = null;
        state.popupData = null;
      })
      .addCase(createUmPopupDataAction.fulfilled, (state, { payload }: any) => {
        state.popupDataLoading = false;
        state.popupDataLoadingError = null;
        state.popupData = payload
      })
      .addCase(createUmPopupDataAction.rejected, (state, { payload }: any) => {
        state.popupDataLoading = false;
        state.popupDataLoadingError = payload || '';
        state.popupData = null;
      });
  },
});
export const { resetCreateUmPopupDataStore } = createUmPopupDataSlice.actions
export default createUmPopupDataSlice.reducer;
