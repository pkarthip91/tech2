export interface ICreateUmPopuoDataState {
  popupDataLoading: boolean | null,
  popupData: any | null,
  popupDataLoadingError: string | null
}

export interface ICreateUmHistory {
  confirmationMessage: string | null,
  pcsdDataKey: number,
  pcsdDataKey_SIM: number,
  reservedBy: string | null
}

export interface ICreateUmHistoryState {
  createUmHistoryLoading: boolean | null,
  createUmHistoryData: ICreateUmHistory | null,
  createUmHistoryError: string | null
}

export interface ICreateUmHistoryDelete {
  deleted: boolean
}

export interface ICreateUmHistoryDeleteState {
  createUmHistoryDeleteLoading: boolean | null,
  createUmHistoryDeleteData: ICreateUmHistoryDelete | null
  createUmHistoryDeleteError: string | null
}

export interface ICreateUmInsert {
  confirmationMessage: string | null,
  pcsdDataKey: number,
  simDataKey: number,
  sisDataKey: number
}

export interface ICreateUmInsertState {
  createUmInsertLoading: boolean | null,
  createUmInsertData: any | null,
  createUmInsertError: string | null
}

export interface ICreateUmInsertRequst {
  plantName: string,
  areaName: string,
  cellName: string,
  unitName: string,
  unitDesc: string,
  unitDescALL: string,
  multiuse: boolean,
  template: string,
  designerName: string,
  unitStatus: string,
  revNumber: string,
  revComment: string,
  tagNamePrefix: string,
  isCMTUnit: boolean
}