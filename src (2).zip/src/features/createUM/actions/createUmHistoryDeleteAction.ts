import { createAsyncThunk } from "@reduxjs/toolkit";
import { Logger } from "../../../app/common/LoggerService";
import { CREATE_UM_HISTORY_DELETE_REDUCER, CREATE_UM_HISTORY_DELETE_ACTION, CREATE_UM_HISTORY_DELETE_ACTION_FAIL } from "../CreateUMConstant";
import { createUmHistoryDeleteService } from "../service/CreateUmApiService"

export const createUmHistoryDeleteAction = createAsyncThunk(
  `${CREATE_UM_HISTORY_DELETE_REDUCER}/${CREATE_UM_HISTORY_DELETE_ACTION}`,
  async ({ userToken, pcsdDataKey }: any, { rejectWithValue }: any) => {
    let result = null
    try {
      const response = await createUmHistoryDeleteService(userToken, pcsdDataKey)
      Logger.info('Create UM HistoryDelete api response- ', response)
      if (response.status === 200 && response.data) {
        result = response.data || false
      } else if (response.status === 400) {
        if (response.data && response.data.errors && response.data.errors.Error0?.length) {
          result = rejectWithValue(response.data.errors.Error0[0])
        }
      }
    } catch (error: any) {
      Logger.error(`${CREATE_UM_HISTORY_DELETE_ACTION_FAIL}`)
      if (error.message || error.response.data) {
        result = rejectWithValue(error.message || error.response.data)
      }
    }
    return result || rejectWithValue(`${CREATE_UM_HISTORY_DELETE_ACTION_FAIL}`)
  }
)
