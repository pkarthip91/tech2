import { createAsyncThunk } from "@reduxjs/toolkit";
import { Logger } from "../../../app/common/LoggerService";
import { CREATE_UM_GET_POPUP_DATA_REDUCER, CREATE_UM_GET_POPUP_DATA_ACCTION, CREATE_UM_GET_POPUP_DATA_ACCTION_FAIL } from "../CreateUMConstant";
import { createUmPopupDataService } from "../service/CreateUmApiService"

export const createUmPopupDataAction = createAsyncThunk(
  `${CREATE_UM_GET_POPUP_DATA_REDUCER}/${CREATE_UM_GET_POPUP_DATA_ACCTION}`,
  async ({ userToken, plantName, areaName, cellName }: any, { rejectWithValue }: any) => {
    let result = null
    try {
      const response = await createUmPopupDataService(userToken, plantName, areaName, cellName)
      Logger.info('Create UM popup data api response- ', response)

      if (response.status === 200 && response.data) {
        result = response.data
      } else if (response.status === 400) {
        if (response.data && response.data.errors && response.data.errors.Error0?.length) {
          result = rejectWithValue(response.data.errors.Error0[0])
        }
      } else if (response.status === 500) {
        if (response.data && response.data.errorDetail && response.data.errorDetail.length) {
          result = rejectWithValue(response.data.errorDetail[0].error)
        }
      }
    } catch (error: any) {
      Logger.error(`${CREATE_UM_GET_POPUP_DATA_ACCTION_FAIL}`)
      if (error.message || error.response.data) {
        result = rejectWithValue(error.message || error.response.data)
      }
    }
    return result || rejectWithValue(`${CREATE_UM_GET_POPUP_DATA_ACCTION_FAIL}`)
  }
)
