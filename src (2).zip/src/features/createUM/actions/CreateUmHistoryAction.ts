import { createAsyncThunk } from "@reduxjs/toolkit";
import { Logger } from "../../../app/common/LoggerService";
import { CREATE_UM_HISTORY_ACTION, CREATE_UM_HISTORY_ACTION_FAIL, CREATE_UM_HISTORY_REDUCER } from "../CreateUMConstant";
import { createUmHistoryService } from "../service/CreateUmApiService"

export const createUmHistoryAction = createAsyncThunk(
  `${CREATE_UM_HISTORY_REDUCER}/${CREATE_UM_HISTORY_ACTION}`,
  async ({ userToken, plantName, unitName }: any, { rejectWithValue }: any) => {
    let result = null
    try {
      const response = await createUmHistoryService(userToken, plantName, unitName)
      Logger.info('Create UM History api response- ', response)
      if (response.status === 200 && response.data) {
        result = {
          confirmationMessage: response.data.confirmationMessage || null,
          pcsdDataKey: response.data.pcsdDataKey || 0,
          pcsdDataKey_SIM: response.data.pcsdDataKey_SIM || 0,
          reservedBy: response.data.reservedBy || null
        }
      } else if (response.status === 400) {
        if (response.data && response.data.errors && response.data.errors.Error0?.length) {
          result = rejectWithValue(response.data.errors.Error0[0])
        }
      } else if (response.status === 500) {
        if (response.data && response.data.errorDetail && response.data.errorDetail.length) {
          result = rejectWithValue(response.data.errorDetail[0].error)
        }
      }
    } catch (error: any) {
      Logger.error(`${CREATE_UM_HISTORY_ACTION_FAIL}`)
      if (error.message || error.response.data) {
        result = rejectWithValue(error.message || error.response.data)
      }
    }
    return result || rejectWithValue(`${CREATE_UM_HISTORY_ACTION_FAIL}`)
  }
)
