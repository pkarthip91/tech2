export const CREATE_UM_POPUP_TITLE = 'Enter object Information (UM)'

export const CREATE_UM_GET_POPUP_DATA_REDUCER = 'createUmGetPopupData'
export const CREATE_UM_GET_POPUP_DATA_ACCTION = 'createUmGetPopupDataAction'
export const CREATE_UM_GET_POPUP_DATA_ACCTION_FAIL = 'Create UM data loading failed!'

export const CREATE_UM_HISTORY_REDUCER = 'createUmHistory'
export const CREATE_UM_HISTORY_ACTION = 'createUmHistoryAction'
export const CREATE_UM_HISTORY_ACTION_FAIL = 'Create UM History failed!'

export const CREATE_UM_HISTORY_DELETE_REDUCER = 'createUmHistoryDelete'
export const CREATE_UM_HISTORY_DELETE_ACTION = 'createUmHistoryDeleteAction'
export const CREATE_UM_HISTORY_DELETE_ACTION_FAIL = 'Create UM History deletee failed!'

export const CREATE_UM_INSERT_REDUCER = 'createUmInsert'
export const CREATE_UM_INSERT_ACTION = 'createUmInsertAction'
export const CREATE_UM_INSERT_ACTION_FAIL = 'Create UM insert failed!'

export const CREATE_UM_CANCELED = 'Create UM canceled'
export const CREATE_UM_FAILED = 'Create UM failed'

export const CREATE_UM_HISTORY_LOADING = 'Checking history...'
export const CREATE_UM_HISTORY_LOADING_COMPLETE = 'Checking history complete'
export const CREATE_UM_HISTORY_LOADING_FAILED = 'Checking history failed'
export const CREATE_UM_REPLACE_OBJECT = 'Replace Object'

export const CREATE_UM_HISTORY_DELETE_LOADING = 'Deleting history...'
export const CREATE_UM_HISTORY_DELETE_LOADING_COMPLETE = 'Deleting history complete'
export const CREATE_UM_HISTORY_DELETE_LOADING_FAILED = 'Deleting history failed'

export const CREATE_UM_INSERT_LOADING = 'Creating UM object...'
export const CREATE_UM_INSERT_COMPLETE = 'New unit # created'
export const CREATE_UM_INSERT_FAILED = 'Creating UM object failed'

export const CREATE_UM_TAKE_OVER_RESERVATION = 'Take Over Reservation'
export const CREATE_UM_RESERVATION_CANCELED = 'Reservation canceled'