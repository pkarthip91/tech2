export enum fieldKey {
  plantName = 'plantName',
  areaName = 'areaName',
  cellName = 'cellName',
  unitName = 'unitName',
  multiuse = 'multiuse',
  template = 'template',
  unitStatus = 'unitStatus',
  unitDesc = 'unitDesc',
  designerName = 'designerName',
  revNumber = 'revNumber',
  revComment = 'revComment',
  unitDescALL = 'unitDescALL',
  tagNamePrefix = 'tagNamePrefix',
  fileName = 'fileName'
}