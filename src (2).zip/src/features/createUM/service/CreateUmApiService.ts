import { httpClient } from '../../../app/api/middlewareSecurity'
import { ICreateUmInsertRequst } from '../interface/CreateUmInterface'

export const createUmPopupDataService = (userToken: string, plantName: string, areaName: string, cellName: string) => {

  return httpClient.post(`/Object/um/popup`, { plantName, areaName, cellName }, {
    headers: {
      "Authorization": `Bearer ${userToken}`
    }
  })
}

export const createUmHistoryService = (userToken: string, plantName: string, unitName: string) => {
  return httpClient.post(`/object/history`, { plantName, unitName }, {
    headers: {
      "Authorization": `Bearer ${userToken}`
    }
  })
}

export const createUmHistoryDeleteService = (

  userToken: string,
  pcsdDataKey: number
) => {
  return httpClient.delete(`/object/history/${pcsdDataKey}`,
    {
      headers: {
        "Authorization": `Bearer ${userToken}`
      }
    })
}

export const createUmInsertService = (userToken: string, data: ICreateUmInsertRequst) => {
  let mapData = Object.assign(data,
    { multiuse: data.multiuse ? true : false },
    { isCMTUnit: false })
  return httpClient.post(`/object/um/create`, { ...mapData }, {
    headers: {
      "Authorization": `Bearer ${userToken}`
    }
  })
}