export const isXmlFile = (file: File): boolean => {
  try {
    return file.type.replace(/(.*)\//g, '').toLowerCase() === 'xml' ? true : false
  } catch {
    return false
  }
}