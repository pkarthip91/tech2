import { Dropdown, DropdownOption } from "@abb/abb-common-ux-react"
import { fieldName } from "features/plantview/styles/PlantViewStyle"
import { useEffect, useState } from "react"

interface IOptionType {
  value: string,
  label: string,
  isNew: boolean
}

export const CreateUmDropdown = (props: { fieldName: string, options: any[], selectedOption: any, onChange: any }) => {


  const mapOptions = (options: any[]) => {
    let mappedOptions: IOptionType[] = new Array<IOptionType>()
    if (options) {
      options.map(opt => { return mappedOptions.push({ value: opt.toString(), label: opt.toString(), isNew: false }) })
    }
    return mappedOptions
  }


  const handleNewValue = (selection: IOptionType) => {
    setDropDownOptions(options => [...options, selection]);
    handleUpdate(selection);
  }

  const handleUpdate = (selection: IOptionType) => {
    setSelectedValue(selection);
    props.onChange(props.fieldName, selection.value)
  }

  const [dropDownOptions, setDropDownOptions] = useState<IOptionType[]>(mapOptions(props.options))
  const [selectedValue, setSelectedValue] = useState<IOptionType | undefined>(dropDownOptions.find(o => o.value == props.selectedOption.toString()))

  useEffect(() => { console.log(fieldName, props.options); setDropDownOptions(mapOptions(props.options)) }, [props.options])


  return (
    <>
      <Dropdown
        {...{
          value: selectedValue ? [selectedValue] : undefined,
          onChange: (selection) => {
            selection[0].isNew ?
              handleNewValue(selection[0]) :
              handleUpdate(selection[0])
          },
          allowAdd: true,
          searchable: true
        }}
      >
        {dropDownOptions && dropDownOptions.map(o =>
          <DropdownOption
            key={o.value}
            value={o.value}
            label={o.label}
          />)
        }
      </Dropdown >
    </>
  )
}