import { useEffect, useState } from "react"
import { ModalPopup } from "../../common/modalPopup/ModalPopup"
import { fieldKey } from "../CreateUmEnum"
import { CreateUmDropdown } from "./CreateUmDropdown"
import { ICreateUmInsertRequst } from "../interface/CreateUmInterface"
import React from "react"
import NewModel from '../../../assest/img/open-new-window.svg';

const labelStyle = { width: '35%' }
const inputStyle = { width: '55%' }
const btnCommentStyle = { width: '15%', marginLeft: '20px' }
const fieldStyle = { width: '100%', display: 'inline-flex', justifyContent: 'flex-end', margin: '2px 0px 2px 0px' }

export const CreateUmModal = ({ popupData, onChange }: any) => {
  const [data, setData] = useState<any>(popupData);

  useEffect(() => { setData(popupData) }, [popupData])




  const getValue = (key: fieldKey, selectedPlant?: string) => {
    let value: any;
    switch (key) {
      case fieldKey.areaName:
      case fieldKey.cellName:
        try { value = getList(key)[0] } catch { }
        break;
      default:
        try { value = data[key].toString(); } catch { }
    }
    return value! ? value : ''
  }

  const [formData, setFormData] = useState<ICreateUmInsertRequst>({
    plantName: getValue(fieldKey.plantName),
    areaName: '',
    cellName: '',
    unitName: getValue(fieldKey.unitName),
    unitDesc: getValue(fieldKey.unitDesc),
    unitDescALL: getValue(fieldKey.unitDescALL),
    multiuse: getValue(fieldKey.multiuse),
    template: getValue(fieldKey.template),
    designerName: getValue(fieldKey.designerName),
    unitStatus: getValue(fieldKey.unitStatus),
    revNumber: getValue(fieldKey.revNumber),
    revComment: getValue(fieldKey.revComment),
    tagNamePrefix: getValue(fieldKey.tagNamePrefix),
    isCMTUnit: false
  })

  useEffect(() => {
    setFormData(values => ({
      ...values,
      plantName: getValue(fieldKey.plantName),
      areaName: '',
      cellName: '',
      unitName: getValue(fieldKey.unitName),
      unitDesc: getValue(fieldKey.unitDesc),
      unitDescALL: getValue(fieldKey.unitDescALL),
      multiuse: getValue(fieldKey.multiuse),
      template: getValue(fieldKey.template),
      designerName: getValue(fieldKey.designerName),
      unitStatus: getValue(fieldKey.unitStatus),
      revNumber: getValue(fieldKey.revNumber),
      revComment: getValue(fieldKey.revComment),
      tagNamePrefix: getValue(fieldKey.tagNamePrefix),
      isCMTUnit: false
    }))
  }, [popupData])

  const [commentModalOpen, setCommentModalOpen] = useState<boolean>(false);

  // popup open add and remove class
  if (commentModalOpen == true) {
    document.body.classList.add('modal-open-width');
  }
  else {
    document.body.classList.remove('modal-open-width');
  }

  useEffect(() => { onChange && onChange(formData) }, [formData])
  const [externalComment, setExternalComment] = useState<string>(formData.revComment);

  const fieldInfo = [
    { label: 'Plant Name', key: fieldKey.plantName },
    { label: 'Area Name', key: fieldKey.areaName },
    { label: 'Process Cell Name', key: fieldKey.cellName },
    { label: 'Object Name', key: fieldKey.unitName },
    { label: 'Object Description', key: fieldKey.unitDesc },
    { label: 'Object In Multiuse', key: fieldKey.multiuse },
    { label: 'Object Template', key: fieldKey.template },
    { label: 'Object Designer Name', key: fieldKey.designerName },
    { label: 'Object Status', key: fieldKey.unitStatus },
    { label: 'Object Revision Number', key: fieldKey.revNumber },
    { label: 'Object Revision Comment', key: fieldKey.revComment }
  ]

  const handleChange = (event: any) => {
    const name = event.target.name;
    const value = event.target.value;
    if (name === 'externalComment')
      setExternalComment(value)
    else
      setFormData(values => ({ ...values, [name]: value }))
  }

  const handleDropdownChange = (name: string, value: string) => {
    switch (name) {
      case fieldKey.plantName:
        setAreaList(getList(fieldKey.areaName, value));
        setCellList(getList(fieldKey.cellName, value));
        break;
    }
    if (name) {
      value = value || ''
      setFormData(values => ({ ...values, [name]: value }))
    }
  }

  const getList = (key: fieldKey, selectedPlant?: string) => {
    let list: any[] = []
    let l = JSON.parse(JSON.stringify(data))
    switch (key) {
      case fieldKey.plantName:
        try {
          if (l.plantMapper && l.plantMapper instanceof Array) {
            l.plantMapper.map((m: any) => {
              m[key] && list.push(m[key])
            })
          }
        } catch { list = [] }
        break;
      case fieldKey.areaName:
      case fieldKey.cellName:
        let plantValue = selectedPlant || getValue(fieldKey.plantName)
        if (plantValue) {
          if (l.plantMapper && l.plantMapper instanceof Array) {
            l.plantMapper.map((m: any) => {
              if (m.plantName === plantValue) {
                list.splice(0, list.length)
                m[key] && list.push(m[key])
              }
            })
          }
        }
        return list;
      default:
        try { list = l[key + 'List']; } catch { list = [] }
    }
    let selectedOption = getValue(key)
    if (selectedOption && list && !(list.filter((o: any) => o.toString() == selectedOption.toString()).length)) {
      list.push(selectedOption.toString())
    }
    return list
  }

  const [areaList, setAreaList] = useState<string[]>(getList(fieldKey.areaName, getValue(fieldKey.plantName)));
  const [cellList, setCellList] = useState<string[]>(getList(fieldKey.cellName, getValue(fieldKey.plantName)));

  const getField = (key: fieldKey, selectedPlant?: string) => {
    switch (key) {
      case fieldKey.areaName:
        return popupData && <CreateUmDropdown fieldName={key} options={areaList} selectedOption={''} onChange={handleDropdownChange} />;
      case fieldKey.cellName:
        return popupData && <CreateUmDropdown fieldName={key} options={cellList} selectedOption={''} onChange={handleDropdownChange} />;
      case fieldKey.plantName:
      case fieldKey.unitName:
      case fieldKey.multiuse:
      case fieldKey.template:
      case fieldKey.unitStatus:
        return popupData && <CreateUmDropdown fieldName={key} options={getList(key)} selectedOption={getValue(key)} onChange={handleDropdownChange} />;
      case fieldKey.unitDesc:
        return <textarea  className="text-area-custom" name={fieldKey.unitDesc} value={formData.unitDesc} onChange={handleChange} />
      case fieldKey.designerName:
        return <input className="input-custom" type="text" name={fieldKey.designerName} value={formData.designerName} style={{ width: '97%' }} onChange={handleChange} />
      case fieldKey.revNumber:
        return <input  className="input-custom" type="text" name={fieldKey.revNumber} value={formData.revNumber} style={{ width: '97%' }} onChange={handleChange} />
      case fieldKey.revComment:
        return <div className="popup-text-area">
          <textarea className="text-area-custom"
            name={fieldKey.revComment}
            value={formData.revComment}
            onChange={(event) => handleChange(event)}
          />
          <button onClick={() => { setExternalComment(formData.revComment); setCommentModalOpen(true); }} className="btn-custom-openwindow" ><img src={NewModel} className="icon-window" /></button>
        </div>
    }
  }
  return (
    <div className="popup-reserver">
      {popupData ? fieldInfo.map((field, index) =>
        <div key={index} className="custom-form-field">
          <span className="custom-label">{field.label}</span>
          <span className="popup-input">
            {getField(field.key as fieldKey)}
          </span>
        </div>
      ) : 'Loading...'}

      <ModalPopup
        onSave={() => { setFormData(values => ({ ...values, revComment: externalComment })); setCommentModalOpen(false) }}
        onClose={() => { setExternalComment(formData.revComment); setCommentModalOpen(false) }}
        isOpen={commentModalOpen}
        title='Enter Object Revision Comment (UM)'
        style={{ zindex: 1000 }}
      >
        <div style={{ width: '100%' }}>
          <span style={{ width: '100%' }}>
            <textarea
              className="text-area-reverse"
              name='externalComment'
              value={externalComment}
              onChange={(event) => handleChange(event)}
            />
          </span>
        </div>
      </ModalPopup>
    </div>
  )
}