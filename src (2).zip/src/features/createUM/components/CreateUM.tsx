import { ModalPopup } from "features/common/modalPopup/ModalPopup";
import { useEffect, useState } from "react";
import { useAppDispatch, useAppSelector } from "../../../app/hooks";
import { CREATE_UM_CANCELED, CREATE_UM_FAILED, CREATE_UM_HISTORY_DELETE_LOADING, CREATE_UM_HISTORY_DELETE_LOADING_COMPLETE, CREATE_UM_HISTORY_DELETE_LOADING_FAILED, CREATE_UM_HISTORY_LOADING, CREATE_UM_HISTORY_LOADING_COMPLETE, CREATE_UM_HISTORY_LOADING_FAILED, CREATE_UM_INSERT_COMPLETE, CREATE_UM_INSERT_LOADING, CREATE_UM_POPUP_TITLE, CREATE_UM_REPLACE_OBJECT } from "../CreateUMConstant";
import { ICreateUmHistoryDeleteState, ICreateUmHistoryState, ICreateUmInsertRequst, ICreateUmInsertState, ICreateUmPopuoDataState } from "../interface/CreateUmInterface";
import { createUmPopupDataAction } from "../actions/CreateUmPopupDataAction";
import { setInformationAction } from "features/informationBar/reducer/InformationBarSlice";
import { IPlantViewState } from "features/plantview/models/PlantViewInterface";
import { PlantTreeNodeType } from "features/plantview/models/Enums";
import { CreateUmModal } from "./CreateUmModel";
import { createUmHistoryAction } from "../actions/CreateUmHistoryAction";
import { resetCreateUmPopupDataStore } from "../reducer/CreateUmPopuoDataSlice";
import { createUmInsertAction } from "../actions/CreateUmInsertAction";
import { resetCreateUmHistoryStore } from "../reducer/CreateUmHistorySlice";
import { resetCreateUmHistoryDeleteStore } from "../reducer/CreateUmHistoryDeleteSlice";
import { createUmHistoryDeleteAction } from "../actions/createUmHistoryDeleteAction";

export const CreateUM = ({ onClick, setToClose }: any) => {
  const [objectInfoModalOpen, setObjectInfoModalOpen] = useState<boolean>(false);
  const { userToken } = useAppSelector((state: any) => state.auth)
  const { popupDataLoading, popupData, popupDataLoadingError } = useAppSelector<ICreateUmPopuoDataState>((state: any) => state.createUmPopupData)
  const { createUmHistoryLoading, createUmHistoryData, createUmHistoryError } = useAppSelector<ICreateUmHistoryState>((state: any) => state.createUmHistory)

  const { selectedNode } = useAppSelector<IPlantViewState>((state: any) => state.plantview)
  const dispatch = useAppDispatch()

  useEffect(() => {
    if (onClick) {
      setToClose()
      if (selectedNode) {
        let plantName = selectedNode.nodeData?.plantName || ''
        let areaName = selectedNode.nodeType != PlantTreeNodeType.plant ? selectedNode.nodeData?.areaName || '' : ''
        let cellName = ((selectedNode.nodeType != PlantTreeNodeType.plant) && (selectedNode.nodeType != PlantTreeNodeType.area)) ? selectedNode.nodeData?.cellName || '' : ''
        dispatch(createUmPopupDataAction({ userToken, plantName, areaName, cellName }))
      } else {
        alert('Please select tree node to create UM object!')
      }
    }
  }, [onClick])

  useEffect(() => {
    popupDataLoading != null &&
      (popupDataLoading ? dispatch(setInformationAction({ message: 'Loading...' })) :
        !popupDataLoadingError && dispatch(setInformationAction({ message: 'Data Loaded' })))
  }, [popupDataLoading])

  useEffect(() => {
    if (popupDataLoadingError != null) {
      dispatch(setInformationAction({ message: popupDataLoadingError || 'Failed', isNewGropu: false }))
    }
  }, [popupDataLoadingError])

  useEffect(() => { popupData && setObjectInfoModalOpen(true) }, [popupData])

  useEffect(() => {
    createUmHistoryLoading != null &&
      (createUmHistoryLoading ? dispatch(setInformationAction({ message: CREATE_UM_HISTORY_LOADING, isNewGropu: false })) :
        dispatch(setInformationAction({ message: CREATE_UM_HISTORY_LOADING_COMPLETE, isNewGropu: false })))
  }, [createUmHistoryLoading])

  useEffect(() => {
    if (createUmHistoryError != null) {
      dispatch(resetCreateUmPopupDataStore())
      dispatch(setInformationAction({ message: createUmHistoryError || CREATE_UM_HISTORY_LOADING_FAILED, isNewGropu: false }))
      dispatch(setInformationAction({ message: CREATE_UM_FAILED, isNewGropu: false }))
    }
  }, [createUmHistoryError])

  const createUM = () => {
    let data: ICreateUmInsertRequst = { ...formData }
    dispatch(createUmInsertAction({ userToken, data }))
  }

  const [historyModalOpen, setHistoryModalOpen] = useState<boolean>(false);
  useEffect(() => {
    createUmHistoryData &&
      (createUmHistoryData.confirmationMessage ? setHistoryModalOpen(true) : createUM())
  }, [createUmHistoryData])


  const { createUmInsertLoading, createUmInsertData, createUmInsertError } = useAppSelector<ICreateUmInsertState>((state: any) => state.createUmInsert)
  useEffect(() => {
    createUmInsertLoading != null &&
      (createUmInsertLoading && dispatch(setInformationAction({ message: CREATE_UM_INSERT_LOADING, isNewGropu: false }))
      )
  }, [createUmInsertLoading])

  useEffect(() => {
    if (createUmInsertError != null) {
      dispatch(resetCreateUmPopupDataStore())
      dispatch(resetCreateUmHistoryStore())
      dispatch(resetCreateUmHistoryDeleteStore())
      dispatch(setInformationAction({ message: createUmInsertError || CREATE_UM_FAILED, isNewGropu: false }))
      dispatch(setInformationAction({ message: CREATE_UM_FAILED, isNewGropu: false }))
    }
  }, [createUmInsertError])

  useEffect(() => {
    (createUmInsertData ?
      dispatch(setInformationAction({ message: CREATE_UM_INSERT_COMPLETE.replace('#', formData.unitName), isNewGropu: false })) :
      dispatch(setInformationAction({ message: CREATE_UM_FAILED, isNewGropu: false })))
  }, [createUmInsertData])

  const { createUmHistoryDeleteLoading, createUmHistoryDeleteError, createUmHistoryDeleteData } = useAppSelector<ICreateUmHistoryDeleteState>((state: any) => state.createUmHistoryDelete)
  useEffect(() => {
    createUmHistoryDeleteLoading != null &&
      (createUmHistoryDeleteLoading ?
        dispatch(setInformationAction({ message: CREATE_UM_HISTORY_DELETE_LOADING, isNewGropu: false })) :
        dispatch(setInformationAction({ message: CREATE_UM_HISTORY_DELETE_LOADING_COMPLETE, isNewGropu: false })))
  }, [createUmHistoryDeleteLoading])

  useEffect(() => {
    if (createUmHistoryDeleteError != null) {
      dispatch(resetCreateUmPopupDataStore())
      dispatch(resetCreateUmHistoryStore())
      dispatch(setInformationAction({ message: createUmHistoryDeleteError || CREATE_UM_HISTORY_DELETE_LOADING_FAILED, isNewGropu: false }))
      dispatch(setInformationAction({ message: CREATE_UM_FAILED, isNewGropu: false }))
    }
  }, [createUmHistoryDeleteError])

  useEffect(() => { createUmHistoryDeleteData && createUM() }, [createUmHistoryDeleteData])


  const [formData, setFormData] = useState<any>({});
  const handleChange = (formData: ICreateUmInsertRequst) => { setFormData(formData) }
  return (
    <>
      <ModalPopup
        onSave={() => {
          dispatch(createUmHistoryAction({ userToken, plantName: formData.plantName, unitName: formData.unitName }));
          setObjectInfoModalOpen(false)
        }}
        onClose={() => {
          dispatch(resetCreateUmPopupDataStore())
          dispatch(setInformationAction({ message: CREATE_UM_CANCELED, isNewGropu: false }));
          setObjectInfoModalOpen(false)
        }}
        isOpen={objectInfoModalOpen}
        title={CREATE_UM_POPUP_TITLE}>
        {popupData && <CreateUmModal popupData={popupData} onChange={handleChange} />}
      </ModalPopup>

      <ModalPopup
        onSave={() => {
          setHistoryModalOpen(false)
          dispatch(createUmHistoryDeleteAction({
            userToken,
            pcsdDataKey: createUmHistoryData?.pcsdDataKey
          }))
        }}
        onClose={() => {
          dispatch(resetCreateUmPopupDataStore())
          dispatch(resetCreateUmHistoryStore())
          dispatch(setInformationAction({ message: CREATE_UM_CANCELED, isNewGropu: false }));
          setHistoryModalOpen(false)
        }}
        isOpen={historyModalOpen}
        title={CREATE_UM_REPLACE_OBJECT}>
        <div>{createUmHistoryData?.confirmationMessage}</div>
      </ModalPopup>
    </>
  )
}