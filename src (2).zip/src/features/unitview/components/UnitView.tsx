
import { useEffect, useState } from 'react';
import { useAppSelector, useAppDispatch } from '../../../app/hooks';

import { unitViewTreeDataAction } from './../actions/UnitViewActions';
import { unitViewPCSDDataAction } from './../actions/UnitViewPCSDdataActions';
import { childViews } from './../models/UnitViewEnums';
import { IUnitViewTreeModel } from './../models/UnitViewTreeInterface';
import { SfcEditor } from './../sfcEditor/components/SfcEditor';
import { unitviewWrapper } from './../styles/UnitViewStyle';
import { UnitLogicViewer } from './../unitLogicViewer/UnitLogicViewer';
import { UnitPropertyViewer } from './../unitProperyViewer/UnitPropertyViewer';
import { UnitViewTree } from './../unitviewTree';
import { IPlantViewState } from '../../plantview/models/PlantViewInterface';
import React from 'react';

import {
  Button
} from '@abb/abb-common-ux-react';
import Headers from '../unitviewTree/header/Header';

import FilterUpdown from '../../../assest/img/unity/content/filter-updown.svg';
import DataEditor from '../../../assest/img/unity/content/data-editor.svg';
import TreeNetwork from '../../../assest/img/unity/content/network.svg';
import TableData from '../../../assest/img/unity/content/table.svg';
import TreeSeparate from '../../../assest/img/unity/content/tree-2.svg';
import CE from '../../../assest/img/unity/content/CE.svg';
import Pin from '../../../assest/img/unity/content/pin.svg';
import Print from '../../../assest/img/unity/content/print.svg';
import { AppToolbarSearchField } from '../../home/appToolbar/AppToolbarSearchField';


export const UnitView = () => {
  const { userToken } = useAppSelector((state: any) => state.auth)
  const { selectedUnit } = useAppSelector<IPlantViewState>((state: any) => state.plantview)
  const dispatch = useAppDispatch();

  const unitId = selectedUnit?.nodeData?.pcsDdataKey;
  const unitName = selectedUnit?.moduleName();

  const [currentView, setCurrentView] = useState(childViews.properties)

  useEffect(() => { dispatch(unitViewTreeDataAction({ userToken, unitId, unitName })) }, []);
  useEffect(() => { dispatch(unitViewTreeDataAction({ userToken, unitId, unitName })) }, []);
  useEffect(() => { dispatch(unitViewPCSDDataAction({ userToken, unitId })) }, []);

  const { loading, unitViewTreeData } = useAppSelector((state: any) => state.unitview)

  const [selectedSubTree, setSelectedSubTree] = useState(unitViewTreeData)
  const [sfcEditorOpen, setSfcEditorOpen] = useState(false)

  const renderView = (view: childViews) => {
    switch (view) {
      case childViews.properties:
        return <div>{selectedSubTree ? <UnitPropertyViewer selectedSubTree={selectedSubTree} /> : <p className="no-properites">Please select node to view property!</p>}</div>;
      case childViews.logicview:
        return <UnitLogicViewer selectedNode={selectedSubTree} />
      default:
        return <div>{"No Selection Made"}</div>;
    }
  }

  const handleClickOnTree = (subTree: IUnitViewTreeModel) => {

    setSelectedSubTree(subTree);
  }

  return (
    <div className='UnitView_main'>
       <div className='ribbon-menus'>
        <Headers/>
      </div>
      {
        loading ? 'Loading...' :
          <div className='unity-main-warpper'>
           <div className='sidebar-tree ui-widget-content' id="resizable">
              <div className='unity-tree-search search-toolbar'>
              <div className='d-line-block toobar-radius toobar-search-tree'>
                  <AppToolbarSearchField />
                </div>
                <span className='filter-btn-updown'>
                  <img src={FilterUpdown} alt="filter-Updown" />
                </span>
              </div>
              <div className='nodeSection'>
              {unitViewTreeData && <UnitViewTree treeData={unitViewTreeData} onClick={handleClickOnTree} />}
              </div>
            </div>

            <div className='unity-data-content'>
              <div className='top-toolbar'>
                <div className='left-panel'>
                  <div className='list-tool'>
                    <ul>
                      <li className='tooltip-menu'>
                        <a style={{ 'cursor': 'pointer' }} onClick={() => setCurrentView(childViews.properties)}>
                          <img src={DataEditor} alt="DataEditor" />
                        </a>
                        <span className="tooltipmenu-text">Property View</span>
                      </li>
                      <li className='tooltip-menu'>
                        <a href='#'>
                          <img src={TableData} alt="Table Data" />
                        </a>
                        <span className="tooltipmenu-text">Step Effect Viewer</span>
                      </li>
                      <li className='tooltip-menu'>
                        <a href='#' onClick={() => { if (!sfcEditorOpen) { setSfcEditorOpen(true) } }}>
                          <img src={TreeNetwork} alt="TreeNetwork" />
                        </a>
                        <span className="tooltipmenu-text">SFC Builder</span>
                      </li>
                      <li className='tooltip-menu'>
                        <a onClick={() => setCurrentView(childViews.logicview)}>
                          <img src={TreeSeparate} alt="Logic Viewer" />
                        </a>
                        <span className="tooltipmenu-text">Logic Viewer</span>
                      </li>
                      <li className='tooltip-menu'>
                        <a href='#'>
                          <img src={CE} alt="CE" />
                        </a>
                        <span className="tooltipmenu-text">Cause & Effect Viewer</span>
                      </li>
                      <li>
                        <div className='left-search unity-tree-search search-toolbar toobar-radius'>
                          <div className='toobar-radius toobar-main'>
                            <AppToolbarSearchField />
                          </div>
                        </div>
                      </li>
                    </ul>
                  </div>
                </div>
                {/* <!--Left Panel end */}

                <div className='right-panel'>
                  <div className='list-tool'>
                    <ul>
                      <li>
                        <a href='#'>
                          <img src={Print} alt="Print" />
                        </a>
                      </li>
                      <li>
                        <a href='#'>
                          <img src={Pin} alt="Pin" />
                        </a>
                      </li>

                      <li>
                        <Button
                          target="_blank"
                          text="Reset"
                          shape={'pill'}
                          sizeClass={"small"}
                          type={'discreet-black'} />
                      </li>
                      <li>
                        <Button
                          target="_blank"
                          text="Save"
                          shape={'pill'}
                          sizeClass={"small"}
                          type={'primary-black'} />
                      </li>
                    </ul>
                  </div>
                </div>
                {/* <!--Left Panel end */}
              </div>
              {/* <div style={{ 'width': '100%', 'display': 'inline-block' }} >
                <span style={{ 'cursor': 'pointer' }} onClick={() => setCurrentView(childViews.properties)}>Property Viewer</span> &nbsp; &nbsp; &nbsp; &nbsp;
                <span style={{ 'cursor': 'pointer' }} onClick={() => setCurrentView(childViews.logicview)}>Logic Viewer</span> &nbsp; &nbsp; &nbsp; &nbsp;
                <span style={{ 'cursor': 'pointer' }} onClick={() => { if (!sfcEditorOpen) { setSfcEditorOpen(true) } }}>SFC Editor</span>
              </div> */}
              {renderView(currentView)}
            </div>
          </div>
      }
      <SfcEditor isOpen={sfcEditorOpen} close={() => setSfcEditorOpen(false)} />
    </div>
  );
}
