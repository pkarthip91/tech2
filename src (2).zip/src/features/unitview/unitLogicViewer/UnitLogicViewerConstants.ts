export const RECT_HEIGHT = 70
export const RECT_WIDTH = 100
export const INIT_Y_POSITION = 5
export const INIT_X_POSITION = 200
export const MINIMUM_EDGE_TO_EDGE_DISTANCE = 15;
export const MINIMUM_LAST_SEGMENT_LENGTH = 30;
export const MINIMUM_NODE_TO_EDGE_DISTANCE = 10;