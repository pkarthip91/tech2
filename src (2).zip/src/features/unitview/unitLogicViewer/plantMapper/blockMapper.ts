import { IUnitViewTreeModel } from './../../models/UnitViewTreeInterface';
import {Block} from '../models/Block';

export class BlcokMapper{
    createBlock(selectedNode:IUnitViewTreeModel):Block{
    let block = new Block();
    block.name=selectedNode.amlNodeTag.cmName;
    block.cmType=selectedNode.amlNodeTag.cmType;
    return block;
    }    
}