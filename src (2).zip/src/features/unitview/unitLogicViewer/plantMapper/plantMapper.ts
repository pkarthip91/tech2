import { Plant } from '../models/Plant';
import { PlantMapperHelper } from '../plantMapper/plantMapperHelper';
import { IUnitViewTreeModel } from './../../models/UnitViewTreeInterface';
import { IMappingParameter } from '../../../common/models/mappingParameterInterfcae';
import { IMappingCMParameter } from '../../../common/models/mappingCMParameterInterface';
import { BlcokMapper } from './blockMapper';
import { PinMapper } from './pinMapper';
import { ConnectionMapper } from './connectionMapper';
import { TagName } from '../models/Block';

export class PlantMapper {

    constructor(private unitViewPCSDdata: any) {

    }

    mapPlant(selectedNode: IUnitViewTreeModel,
        mappingParameters: Array<IMappingParameter>,
        mappingCMParameter: Array<IMappingCMParameter>): Plant {

        let plant = new Plant();
        let plantMapperHelper = new PlantMapperHelper();
        let connectionMapper = new ConnectionMapper()
        const PLANT_NAME: string = 'ABB';
        const AREA_NAME: string = 'WhiteField';
        const CELL_NAME: string = 'Hall'

        let blockMapper: BlcokMapper = new BlcokMapper();
        let pinTransformer = new PinMapper(this.unitViewPCSDdata);
        let connectionPinsStr = '';
        let unitKey = plantMapperHelper.getUnitKey(PLANT_NAME, AREA_NAME, CELL_NAME, selectedNode.amlNodeTag.parentName);
        plant.unitKey = unitKey;



        selectedNode.getChildView().forEach(currentNode => {

            if (plantMapperHelper.isLogicViewerEnabled(selectedNode.amlNodeTag.parentName))
                return;
            if (plantMapperHelper.isBlockAlreadyAdded(plant, currentNode.amlNodeTag.cmName))
                return;
            let block = blockMapper.createBlock(currentNode);
            if (currentNode.getChildView().length > 0) {
                currentNode.getChildView().forEach(leafNode => {
                    connectionPinsStr = pinTransformer.createPin(block, leafNode, mappingParameters, mappingCMParameter);
                    connectionMapper.createConnection(block, connectionPinsStr);
                    let tagName: TagName = new TagName();
                    tagName.tagname = leafNode.amlNodeTag.tagName;
                    tagName.name = leafNode.amlNodeTag.tagName;
                    block.Tags.push(tagName);
                });
                plant.units.push(block);
            }
            else {
                connectionPinsStr = pinTransformer.createPin(block, currentNode, mappingParameters, mappingCMParameter);
                connectionMapper.createConnection(block, connectionPinsStr);
                let tagName: TagName = new TagName();
                tagName.tagname = currentNode.amlNodeTag.tagName;
                tagName.name = currentNode.amlNodeTag.tagName;
                block.Tags.push(tagName);
                plant.units.push(block);
            }
        });

        return plant;
    }
}