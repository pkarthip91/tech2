import { Block, ConnectInfo } from "../models/Block";

export class ConnectionMapper {

    createConnection = ((block: Block, connectionPinsStr: string = '') => {
        connectionPinsStr.split(',').forEach(connStrItem => {
            if (connStrItem && connStrItem.split(':').length > 0) {

                const pinDelimeter = " : ";
                let connectInfo: ConnectInfo = new ConnectInfo();

                connectInfo.sourceOutputPort = 'Out';
                connectInfo.sourceBlockName = connStrItem.split(':')[1];
                connectInfo.destinationBlockName = block.name;
                connectInfo.destinationInputPort = connStrItem.split(':')[0] + pinDelimeter + connStrItem.split(':')[1];

                block.connectionInfos.push(connectInfo);
            }
        });

    })
}