import { Plant } from '../models/Plant';
import { IUnitViewTreeModel } from './../../models/UnitViewTreeInterface';
import { IMappingParameter } from '../../../common/models/mappingParameterInterfcae';
import { MappingParameter } from '../../../common/models/mappingParameterModel';
import { IMappingCMParameter } from '../../../common/models/mappingCMParameterInterface';
import { Block, Pin } from '../models/Block';

export class PinManager {

    createPin(block: Block,
        leafNodeType: string,
        mappingCMParamItem: IMappingCMParameter | null,
        feParamString: string,
        feParamValueStr: string) {
        if (feParamValueStr) {
            let pin = new Pin();
            const pinDelimeter: string = " : ";

            if (leafNodeType != '') {
                pin.pinType = leafNodeType;
            }

            pin.name = feParamString + pinDelimeter + feParamValueStr;
            if (mappingCMParamItem) {
                pin.direction = mappingCMParamItem.direction;
            }
            pin.portIndex = mappingCMParamItem ? mappingCMParamItem.portIndex : 0;


            block.Pins.push(pin);
        }

    }
}

