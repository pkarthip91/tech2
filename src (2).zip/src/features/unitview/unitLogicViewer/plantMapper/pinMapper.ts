import { IUnitViewTreeModel } from './../../models/UnitViewTreeInterface';
import { IMappingParameter } from '../../../common/models/mappingParameterInterfcae';
import { MappingParameter } from '../../../common/models/mappingParameterModel';
import { IMappingCMParameter } from '../../../common/models/mappingCMParameterInterface';
import { AMLnodeTag } from '../../models/UnitViewTreeModel';
import { PinManager } from './pinManager';
import { DictionaryElementTwoLevel, DictionyElement, PCSDData, PlantMapperHelper } from './plantMapperHelper';
import { Block } from '../models/Block';

export class PinMapper {
    constructor(private unitViewPCSDdata: any) { }

    connectionPinsParams: Array<string> = ['Measurement_PV',
        'Output',
        'Setpoint_default_or_from_higher_level',
        'Extern_setpoint_eg_ACANDO',
        'Connected_1',
        'Connected_2',
        'Connected_3',
        'Connected_4'];

    createPin(
        block: Block,
        leafNode: IUnitViewTreeModel,
        mappingData: Array<IMappingParameter>,
        mappingCMData: Array<IMappingCMParameter>): string {

        let returnConnectionPins = '';
        let childTreeNodeAMLTag: AMLnodeTag = leafNode.amlNodeTag;
        let tabName = childTreeNodeAMLTag.pcsdTable.replace('_FE', '');
        let tagName = childTreeNodeAMLTag.tagName;
        let pcsdTable = ((tabName !== undefined) && tabName.split('_').length > 0) ? tabName.split('_')[0] : '';
        let pinManager: PinManager = new PinManager();
        let plantMapperHelper = new PlantMapperHelper();

        plantMapperHelper.fillDictionary(childTreeNodeAMLTag);
        pcsdTable = (tabName == "A_Op_Inp") ? "AOI" : pcsdTable;
        let isCTable: boolean = (pcsdTable == "C") ? true : false;
        let leafNodeType = '';
        let treeNodeTextColl: Array<string> = leafNode.getNodeText().split(',');

        if (treeNodeTextColl.length > 0) {
            leafNodeType = treeNodeTextColl[0];
        }
        let filteredLegacyMappingList = mappingData.filter(x => x.cmType == childTreeNodeAMLTag.cmType && x.feTable == pcsdTable);

        // when we have feparameters like IN01;In10-- we need to parse into 10 different pins IN01;IN02;IN03;IN04:IN05;IN06;IN07;IN08;IN09;IN10
        filteredLegacyMappingList = this.parseManuallyDelimitedColumns(filteredLegacyMappingList);
        let filteredCMParameterList = mappingCMData.filter(x => x.cmType == childTreeNodeAMLTag.cmType && x.portIndex > -1);
        if (filteredLegacyMappingList.length == 0 && childTreeNodeAMLTag.cmType != "EqCore")
            return '';

        if (isCTable) {
            filteredLegacyMappingList = filteredLegacyMappingList.filter(x => x.alertSubtype == childTreeNodeAMLTag.cmElement);
        }
        filteredCMParameterList = filteredCMParameterList.sort(x => x.portIndex);
        let groupedCMParameter = plantMapperHelper.groupBy(filteredLegacyMappingList, (mappingParameter) => mappingParameter.cmParameter);

        // let pcsdData: PCSDData = new PCSDData();
        let pcsdData: any = this.unitViewPCSDdata;
        let tagData = pcsdData.find((x: any) => x.key.toUpperCase() == tabName.toUpperCase());
        if (childTreeNodeAMLTag.cmType == "EqCore") {
            let mappingCMParamItems: IMappingCMParameter | null = filteredCMParameterList.find(x => x.paramName == "Name") || null;
            let tagData_UnitModuleName: string = '';//tagData[childTreeNodeAMLTag.cmName]["Unit_Module_Name"]
            let tagData_EMDescription: string = '';//tagData[childTreeNodeAMLTag.CMname]["EM_Description"])
            pinManager.createPin(block,
                leafNodeType,
                mappingCMParamItems,
                "Name", tagData_UnitModuleName);
            pinManager.createPin(block,
                leafNodeType,
                mappingCMParamItems,
                "Description",
                tagData_EMDescription);
        }
        if (tagData != null) {
            let fieldData = tagData.value.find((x: any) => x.key.toUpperCase() == tagName.toUpperCase());
            if (fieldData != null) {
                filteredCMParameterList.forEach(mappingCMParamItem => {
                    let mappedLegacyItem: MappingParameter | null = new MappingParameter();
                    mappedLegacyItem = filteredLegacyMappingList.find(x => x.feParameter == mappingCMParamItem.paramName) ?? filteredLegacyMappingList.find(x => x.feParameter.includes(mappingCMParamItem.paramName) && x.feParameter.includes(";")) ?? null;
                    if (mappedLegacyItem == null) {
                        return;
                    }
                    let feParamValue = fieldData?.value.find((x: any) => x.key == mappedLegacyItem?.cmParameter);
                    if (!feParamValue) {
                        let amlVlaue = plantMapperHelper.amlDictionary.find(t => t.key == mappedLegacyItem?.cmParameter);
                        if (amlVlaue) {
                            try {
                                feParamValue.key = amlVlaue.key;
                                feParamValue.value = amlVlaue.value;
                            } catch { }
                        }
                    }
                    if (!feParamValue)
                        return;
                    let feParamString: string = mappedLegacyItem?.feParameter || '';
                    let feParamValueStr: string = feParamValue ? feParamValue.value : '';
                    try {
                        let multiPinParamColl: Array<string> = feParamString.split(',');//(new char[] { ',', ';' }).ToList<string>();
                        let multiPinValueColl: Array<string> = feParamValueStr.split(',');//(new char[] { ',', ';' }).ToList<string>();
                        if (multiPinParamColl.length > 1) {// && multiPinValueColl.Count > 1) // && (multiPinValueColl.Count == multiPinParamColl.Count)){
                            let cmParamIndex: number = multiPinParamColl.indexOf(mappingCMParamItem.paramName);
                            if (cmParamIndex >= 0) {
                                feParamString = multiPinParamColl[cmParamIndex];
                                feParamValueStr = (multiPinValueColl.length - 1 >= cmParamIndex) //If There is NO Param Value for the Respective Param Pin, then add the Pin with Empty Value
                                    ? multiPinValueColl[cmParamIndex] //Eg: Before feParamValueStr = "MAC_VENT_SS,FY1319_OUT,,PDIC1319_AUTO" || After feParamValueStr = "FY1319_OUT"
                                    : '';
                            }
                        }
                        else if (//groupedCMParameter .ContainsKey(mappedLegacyItem?.cmParameter) &&
                            groupedCMParameter[mappedLegacyItem?.cmParameter].length > 1) {
                            let cmParamIndex: number = groupedCMParameter[mappedLegacyItem?.cmParameter].indexOf(mappedLegacyItem);
                            feParamValueStr = (multiPinValueColl.length - 1 >= cmParamIndex) //If There is NO Param Value for the Respective Param Pin, then add the Pin with Empty Value
                                ? multiPinValueColl[cmParamIndex] //Eg: Before feParamValueStr = "MAC_VENT_SS,FY1319_OUT,,PDIC1319_AUTO" || After feParamValueStr = "FY1319_OUT"
                                : '';
                        }
                    }
                    catch (Exception) {
                        //Log Error
                    }
                    if (feParamValueStr) {
                        if (isCTable && (feParamValue?.key == "Alarm_Setpoint" || feParamValue?.key == "Severity")) {
                            feParamValueStr = feParamValueStr.includes('(') ? feParamValueStr.substring(0, feParamValueStr.indexOf('(')) : feParamValueStr;
                        }
                    }

                    if (this.connectionPinsParams.includes(mappedLegacyItem.cmParameter)) {
                        //Added code to support multiple connections separated by semi colon : e.g., output->x,y,z
                        // let connectionTags: Array<string> = feParamValueStr.split(';');
                        // connectionTags.forEach(connTag => {
                        //     if (connTag)
                        //         returnConnectionPins += feParamString + ":" + connTag + ",";
                        // })
                        returnConnectionPins += feParamString + ":" + feParamValueStr + ","; //" \n " + childTreeNodeAMLTag.CMtype 
                    }
                    //Logic of selecting the Output Pins
                    /*if (this.connectionPinsParams?.keys.(this.toolID) && connectionPinsParams[this.toolID].Contains(mappedLegacyItem.CM_Parameter)){
                        //Added code to support multiple connections separated by semi colon : e.g., output->x,y,z
                        let connectionTags : Array<string> = feParamValueStr.split(';');
                        connectionTags.forEach(connTag=>{
                            if (connTag)
                            returnConnectionPins += feParamString + ":" + connTag + ",";
                        })
                        //returnConnectionPins += feParamString + ":" + feParamValueStr + ","; //" \n " + childTreeNodeAMLTag.CMtype 
                    }*/
                    //Include Connection Pins Data
                    pinManager.createPin(block, leafNodeType, mappingCMParamItem, feParamString, feParamValueStr);
                })
                //Add Space Only for Alaram
                if (isCTable) {
                    //Add Empty Entry for Leaf Node Break
                    //xmlLeafNodeColl.Add(new KeyValuePair<int, XmlNode>());
                }

            }
        }

        return returnConnectionPins;

    }


    parseManuallyDelimitedColumns(filteredLegacyMappingList: Array<IMappingParameter>): Array<IMappingParameter> {
        let parsedCollectionList: Array<IMappingParameter> = []

        filteredLegacyMappingList.forEach((viewerLegacyMappingData) => {
            //let delimeterSeparatedCollection = viewerLegacyMappingData.feParameter.split([',',';']).ToList<string>(); to - do
            let delimeterSeparatedCollection = viewerLegacyMappingData.feParameter.split(/[,;]+/);

            if (delimeterSeparatedCollection.length <= 1)
                parsedCollectionList.push(viewerLegacyMappingData);
            else {
                let logicViewerLegacyMappingDataobject: MappingParameter = new MappingParameter(
                    viewerLegacyMappingData.cmType,
                    viewerLegacyMappingData.cmElement,
                    viewerLegacyMappingData.feTable,
                    viewerLegacyMappingData.cmParameter
                );
                //Call Parsing method
                var result = this.parseManualFEParameterData(delimeterSeparatedCollection);
                logicViewerLegacyMappingDataobject.feParameter = result == '' || result == null ? viewerLegacyMappingData.feParameter : result;
                parsedCollectionList.push(logicViewerLegacyMappingDataobject);
            }

        });
        return parsedCollectionList;
    }

    parseManualFEParameterData(delimeterSeparatedCollection: Array<string>): string {
        return '';

        /*
        var intList = new List<int>();
        bool formatFlag = false;
        var concatenatedString = new StringBuilder();

        //Extract strings
        //foreach (string s in delimeterSeparatedCollection)
        //{
        //    var result = Regex.Split(s, @"\d+$");
        //    characterList.Add(result[0]);
        //}
        var characterList = delimeterSeparatedCollection.Select(s => Regex.Split(s, @"\d+$")).Select(result => result[0]).ToList();

        var duplicateKeys = characterList.GroupBy(x => x)
          .Where(g => g.Count() == 2)
          .Select(y => y.Key)
          .ToList();

        //Extract digits
        foreach (var s in delimeterSeparatedCollection)
        {
            var result = Regex.Match(s, @"\d+$").Value;
            if (!string.IsNullOrEmpty(result))
            {
                if (!formatFlag)
                    formatFlag = result.Length == 1;
                intList.Add((Convert.ToInt32(result)));
            }
        }
        intList.Sort();

        if (intList.Count == 2)
            for (var i = intList[0]; i <= intList[1]; i++)
            {
                if (duplicateKeys.Count > 0)
                {
                    concatenatedString.Append(duplicateKeys[0]);
                    var strFormat = formatFlag ? "D1" : "D2";
                    concatenatedString.Append(i.ToString(strFormat));
                    concatenatedString.Append(";");
                }
                else
                {
                    return string.Empty;
                }
            }

        foreach (var item in delimeterSeparatedCollection)
        {
            if (duplicateKeys.Count > 0)
            {
                if (item.Contains(duplicateKeys[0])) continue;
                concatenatedString.Append(item);
                concatenatedString.Append(";");
            }
            else
            {
                concatenatedString.Append(item);
                concatenatedString.Append(";");
            }
        }

        return concatenatedString.ToString();
        */
    }
}



