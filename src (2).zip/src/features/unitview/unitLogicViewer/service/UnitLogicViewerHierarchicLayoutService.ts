import { BridgeCrossingPolicy, BridgeManager, ComponentArrangementPolicy, EdgeRouter, EdgeRouterBusDescriptor, EdgeRouterData, FixPortLocationStage, FixPortLocationStageData, GraphComponent, GraphObstacleProvider, HierarchicLayout, HierarchicLayoutData, IEdge, LayoutOrientation, PartitionGrid, PartitionGridData, PortConstraint, PortSide, TabularLayout, TabularLayoutPolicy } from "yfiles"
import { MINIMUM_EDGE_TO_EDGE_DISTANCE, MINIMUM_LAST_SEGMENT_LENGTH, MINIMUM_NODE_TO_EDGE_DISTANCE } from "../UnitLogicViewerConstants"
import { junctionHandler } from "./UnitLogicViewerEdgeJunctionHandlerService"

export const applyHierarchicLayout = (graphComponent: GraphComponent) => {
  let hierarchicLayout = new HierarchicLayout()
  hierarchicLayout.automaticEdgeGrouping = false
  hierarchicLayout.orthogonalRouting = true
  hierarchicLayout.layoutOrientation = LayoutOrientation.LEFT_TO_RIGHT
  hierarchicLayout.nodeToNodeDistance = MINIMUM_NODE_TO_EDGE_DISTANCE
  hierarchicLayout.nodeToEdgeDistance = MINIMUM_NODE_TO_EDGE_DISTANCE
  hierarchicLayout.edgeToEdgeDistance = MINIMUM_EDGE_TO_EDGE_DISTANCE
  hierarchicLayout.minimumLayerDistance = 30
  hierarchicLayout.componentLayoutEnabled = false
  hierarchicLayout.recursiveGroupLayering = true
  hierarchicLayout.componentArrangementPolicy = ComponentArrangementPolicy.COMPACT

  hierarchicLayout.edgeLayoutDescriptor.minimumLastSegmentLength = 80

  let hierarchicLayoutData = new HierarchicLayoutData({
    sourcePortConstraints: () => PortConstraint.create(PortSide.EAST, true),
    targetPortConstraints: () => PortConstraint.create(PortSide.WEST, true),
    reduceCriticalEdgeCrossings: true
  })

  graphComponent.graph.applyLayout(hierarchicLayout, hierarchicLayoutData)

  var bridgeManager = new BridgeManager({
    bridgeCrossingPolicy: BridgeCrossingPolicy.HORIZONTAL_BRIDGES_VERTICAL
  })
  bridgeManager.addObstacleProvider(new GraphObstacleProvider());
  bridgeManager.canvasComponent = graphComponent

  junctionHandler(graphComponent)
}


