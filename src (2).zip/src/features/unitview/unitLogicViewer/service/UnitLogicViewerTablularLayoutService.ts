import { BridgeCrossingPolicy, BridgeManager, EdgeRouter, EdgeRouterBusDescriptor, EdgeRouterData, FixPortLocationStage, FixPortLocationStageData, GraphComponent, GraphObstacleProvider, IEdge, PartitionGrid, PartitionGridData, PortConstraint, PortSide, TabularLayout, TabularLayoutPolicy } from "yfiles"
import { MINIMUM_EDGE_TO_EDGE_DISTANCE, MINIMUM_LAST_SEGMENT_LENGTH, MINIMUM_NODE_TO_EDGE_DISTANCE } from "../UnitLogicViewerConstants"
import { junctionHandler } from "./UnitLogicViewerEdgeJunctionHandlerService"

export const applyTabularLayout = (graphComponent: GraphComponent) => {
  const nodeCount = graphComponent.graph.nodes.size
  let partitionGrid = new PartitionGrid(3, 4)
  partitionGrid.rows.forEach(row => {
    row.minimumHeight = 200
    row.topInset = 20
    row.bottomInset = 20
  })
  partitionGrid.columns.forEach(column => {
    column.minimumWidth = 200
    column.leftInset = 20
    column.rightInset = 20
  })

  let tblLayout = new TabularLayout()
  tblLayout.layoutPolicy = TabularLayoutPolicy.FIXED_SIZE
  let edgeRouterData: EdgeRouterData = new EdgeRouterData({ partitionGridData: new PartitionGridData({ grid: partitionGrid }) })

  let fixPortLocationStage = new FixPortLocationStage({ coreLayout: tblLayout, keepCalculatedPorts: false });

  var fixPortLocationStageData = new FixPortLocationStageData({
    sourcePortConstraints: () => PortConstraint.create(PortSide.EAST, true),
    targetPortConstraints: () => PortConstraint.create(PortSide.WEST, true)
  })

  let edgeRouterLayout = new EdgeRouter(fixPortLocationStage)
  edgeRouterLayout.defaultEdgeLayoutDescriptor.minimumEdgeToEdgeDistance = MINIMUM_EDGE_TO_EDGE_DISTANCE
  edgeRouterLayout.defaultEdgeLayoutDescriptor.minimumLastSegmentLength = MINIMUM_LAST_SEGMENT_LENGTH
  edgeRouterLayout.minimumNodeToEdgeDistance = MINIMUM_NODE_TO_EDGE_DISTANCE

  let edgesWithSameOnwer: { [key: string]: IEdge[] }[] = []
  graphComponent.graph.edges.forEach((edge: IEdge) => {
    let isExist = edgesWithSameOnwer.find((g) => {
      for (const key in g) {
        if (g.hasOwnProperty(key))
          return key == edge.sourcePort?.owner?.tag.blkName
      }
    })
    if (!isExist) {
      isExist = {}
      isExist[edge.sourcePort?.owner?.tag.blkName] = []
      edgesWithSameOnwer.push(isExist)
    }
    isExist[edge.sourcePort?.owner?.tag.blkName].push(edge)
  })

  edgesWithSameOnwer.forEach((item: { [key: string]: IEdge[] }) => {
    for (const key in item) {
      if (item.hasOwnProperty(key)) {
        let bus: EdgeRouterBusDescriptor = new EdgeRouterBusDescriptor({ automaticEdgeGrouping: false, multipleBackboneSegments: false });
        edgeRouterData.buses.add(bus).items = item[key]
      }
    }
  })

  graphComponent.graph.applyLayout(edgeRouterLayout, fixPortLocationStageData.combineWith(edgeRouterData))

  var bridgeManager = new BridgeManager({
    considerCurves: true,
    bridgeCrossingPolicy: BridgeCrossingPolicy.MORE_VERTICAL_BRIDGES_LESS_VERTICAL
  })
  bridgeManager.addObstacleProvider(new GraphObstacleProvider());
  bridgeManager.canvasComponent = graphComponent


  junctionHandler(graphComponent)

}


