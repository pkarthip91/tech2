import { IUnitViewTreeModel } from "../../models/UnitViewTreeInterface";
import { BlockDataInfo, BlockInfoDataModel } from "../models/BlockInfoDataModel";
import { blockInfoDataModel_xmtrs } from "../models/BlockInfoDataModel_xmtrs";

// export const mapToLogicViewerData = (node: IUnitViewTreeModel): BlockInfoDataModel | null => {
//   let mappedData: BlockInfoDataModel | null = null
//   if (node.getNodeTextArray().includes('Xmtrs')) {
//     mappedData = loadDataFromFile('xmtrs')
//   } else if (node.getChildView()?.length > 0) {
//     mappedData = new BlockInfoDataModel()
//     //let newBlock = createBlock(node.getNodeTextArray().join(','))
//     //mappedData.blockCollection.push(newBlock)
//     node.getChildView()?.map((child: IUnitViewTreeModel) => {
//       if (child.getChildView()?.length > 0) {
//         let newBlock = createBlock(child.getNodeText())
//         mappedData?.blockCollection.push(newBlock)
//       }
//     })
//   }
//   return mappedData
// }

const createBlock = (blkName: string, cmType: string = '', inputPortsCol: string[] = [], outputPortsCol: string[] = []): BlockDataInfo => {
  let block = new BlockDataInfo()
  block.blkName = blkName
  block.cmType = cmType
  block.inputPortsCol = inputPortsCol
  block.outputPortsCol = outputPortsCol
  return block
}

const loadDataFromFile = (filename: string) => {
  let mappedData: BlockInfoDataModel | null = new BlockInfoDataModel()
  let rowData = blockInfoDataModel_xmtrs
  rowData.map(d => {
    let newBlock = createBlock(d.BlkName, d.CmType, d.InputPortsCol, d.OutputPortsCol)
    mappedData?.blockCollection.push(newBlock)
  })
  return mappedData
}