import {
  GraphComponent, IBend, IEdge, IPoint, Rect, ShapeNodeShape, ShapeNodeStyle
} from "yfiles"

export const junctionHandler = (graphComponent: GraphComponent) => {
  createDotJunction(graphComponent)
}

const createDotJunction = (graphComponent: GraphComponent) => {
  let edgesWithSameOnwer: { [key: string]: IEdge[] }[] = []
  graphComponent.graph.edges.forEach((edge: IEdge) => {
    let isExist = edgesWithSameOnwer.find((g) => {
      for (const key in g) {
        if (g.hasOwnProperty(key))
          return key == edge.sourcePort?.owner?.tag.blkName
      }
    })
    if (!isExist) {
      isExist = {}
      isExist[edge.sourcePort?.owner?.tag.blkName] = []
      edgesWithSameOnwer.push(isExist)
    }
    isExist[edge.sourcePort?.owner?.tag.blkName].push(edge)
  })
  edgesWithSameOnwer.forEach((item: { [key: string]: IEdge[] }) => {
    for (const key in item) {
      if (item.hasOwnProperty(key)) {
        item[key].forEach((fEdge: IEdge, index: number) => {
          item[key].forEach((sEdge: IEdge, index: number) => {
            if (!(fEdge === sEdge)) {
              let bend = compareEdges(fEdge, sEdge);
              if (bend) {
                let style: ShapeNodeStyle = new ShapeNodeStyle({
                  shape: ShapeNodeShape.ROUND_RECTANGLE,
                  fill: 'black'
                });
                graphComponent.graph.createNode(new Rect(bend.location.x - 5,
                  bend.location.y - 5, 10, 10), style, "DotNode");
              }
            }
          })
        })
      }
    }
  })
}

const compareEdges = (firstEdge: IEdge, secondEdge: IEdge): IBend => {
  let overlapBend!: IBend;
  let firstEdgeBend!: IBend;
  firstEdge.bends.forEach((bend: IBend) => {
    if (!firstEdgeBend) {
      var isExistBend = secondEdge.bends
        .find(q => (q.location.x == bend.location.x) && (q.location.y == bend.location.y));
      if (isExistBend) {
        overlapBend = bend;
      }
      else {
        firstEdgeBend = bend;
      }
    }
  })
  let secondEdgeBend!: IBend;
  secondEdge.bends.forEach((bend: IBend) => {
    if (!secondEdgeBend) {
      var isExistBend = firstEdge.bends
        .find(q => (q.location.x == bend.location.x) && (q.location.y == bend.location.y));
      if (!isExistBend) {
        secondEdgeBend = bend;
      }
    }
  })

  return getBend(overlapBend, firstEdgeBend, secondEdgeBend, firstEdge);
}

const getBend = (overlapBend: IBend, firstBend: IBend, secondBend: IBend, edge: IEdge): IBend => {
  if (firstBend == null && secondBend == null) {
    return overlapBend;
  }
  else if (firstBend != null && secondBend == null) {
    return firstBend;
  }
  else if (firstBend == null && secondBend != null) {
    return secondBend;
  }
  else if (firstBend?.location.x == secondBend?.location.x) {
    return getYAxisBend(overlapBend, firstBend, secondBend, edge);
  }
  else if (firstBend?.location.y == secondBend?.location.y) {
    return getXAxisBend(overlapBend, firstBend, secondBend, edge);
  }

  return overlapBend;
}

const getYAxisBend = (overlapBend: IBend, firstBend: IBend, secondBend: IBend, edge: IEdge): IBend => {
  let point: IPoint | undefined = overlapBend == null ? edge.sourcePort?.location : overlapBend.location;
  if (point) {
    if (point.y > firstBend.location.y && point.y > secondBend?.location.y) {
      return (firstBend.location.y < secondBend.location.y) ? secondBend : firstBend;
    }
    else if (point.y < firstBend.location.y && point.y < secondBend.location.y) {
      return (firstBend.location.y < secondBend.location.y) ? firstBend : secondBend;
    }
  }
  return overlapBend;
}

const getXAxisBend = (overlapBend: IBend, firstBend: IBend, secondBend: IBend, edge: IEdge): IBend => {

  let point: IPoint | undefined = overlapBend == null ? edge.sourcePort?.location : overlapBend.location;
  if (point) {
    if (point.x > firstBend.location.x && point.x > secondBend?.location.x) {
      return (firstBend.location.x < secondBend.location.x) ? secondBend : firstBend;
    }
    else if (point.x < firstBend.location.x && point.x < secondBend.location.x) {
      return (firstBend.location.x < secondBend.location.x) ? firstBend : secondBend;
    }
  }
  return overlapBend;
}