import {Block} from './Block';

class Plant{
    _units :Array<Block>=[];
    get units(){
        return this._units;
    }
    set units(value){
        this._units=value;
    }

    _unitKey:string='';
    get unitKey(){
        return this._unitKey
    }
    set unitKey(value){
        this._unitKey=value;
    }
    constructor(other?:Plant){
        if(other!==undefined){
            other.units.forEach(element => {
                this.units.push(element);
            });
        }
    }
}

export {Plant}
