import {PortsModel} from './PortsModel';

class PreviewBlockInfo{
    _xPos:number=0;
    get xPos(){
        return this._xPos;
    }
    set xPos(value){
        this._xPos=value;
    }

    _yPos:number=0;
    get yPos(){
        return this._yPos;
    }
    set yPos(value){
        this._yPos=value;
    }   
    
    _blockName:string='';
    get blockName(){
        return this._blockName;
    } 
    set blockName(value){
        this._blockName=value;
    }

    _blockDesc:string='';
    get blockDesc(){
        return this._blockDesc;
    } 
    set blockDesc(value){
        this._blockDesc=value;
    } 
    
    _rectLabel:string='';
    get rectLabel(){
        return this._rectLabel;
    } 
    set rectLabel(value){
        this._rectLabel=value;
    } 
    
    _cmType:string='';
    get cmType(){
        return this._cmType;
    } 
    set cmType(value){
        this._cmType=value;
    }     

    _isLinkNode:boolean=false;
    get isLinkNode(){
        return this._isLinkNode;
    }
    set isLinkNode(value){
        this._isLinkNode=value;
    }

    _isExternalVariable:boolean=false;
    get isExternalVariable(){
        return this._isExternalVariable;
    }
    set isExternalVariable(value){
        this._isExternalVariable=value;
    }    

    _headerHeight:number=0;
    get headerHeight(){
        return this._headerHeight;
    }
    set headerHeight(value){
        this._headerHeight=value;
    }
    
    _ports:Array<PortsModel>=[];
    get ports(){
        return this._ports;
    }
    set ports(value){
        this._ports=value;
    }
}

export{PreviewBlockInfo}