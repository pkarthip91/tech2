class BlockConnectionInfoDataModel{
    _blockConnectionInos:Array<BlockConnectionInfo>=[];
    get blockConnectionInfos(){
        return this._blockConnectionInos;
    }
    set blockConnectionInfos(value){
        this._blockConnectionInos=value;
    }
}

class BlockConnectionInfo{
    _sourceName:string='';
    get sourceName(){
        return this._sourceName;
    }
    set sourceName(value){
        this._sourceName=value;
    }

    _destinationName:string='';
    get destinationName(){
        return this._destinationName;
    }   
    set destinationName(value){
        this._destinationName=value;
    }

    _sourceOutputPort:string=''
    get sourceOutputPort(){
        return this._sourceOutputPort;
    }
    set sourceOutputPort(value){
        this._sourceOutputPort=value;
    }

    _destinationInputPort:string=''
    get destinationInputPort(){
        return this._destinationInputPort;
    }
    set destinationInputPort(value){
        this._destinationInputPort=value;
    }
}

export{BlockConnectionInfo,BlockConnectionInfoDataModel};