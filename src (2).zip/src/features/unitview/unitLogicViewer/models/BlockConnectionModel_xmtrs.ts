export const ConnectBlkCol_xmtrs = [{
  "SrcBlkName": "Aqtk1AqTk1TankLT",
  "SrcOutputPort": "OUT :",
  "DestBlkName": "Aqtk1pw1",
  "DestInputPort": "In : AqTk1TankLT_IO"
}, {
  "SrcBlkName": "tt123",
  "SrcOutputPort": "OUT :",
  "DestBlkName": "Aqtk1pw2",
  "DestInputPort": "In : tt123"
}, {
  "SrcBlkName": "Aqtk1T456",
  "SrcOutputPort": "OUT :",
  "DestBlkName": "Aqtk1Total1",
  "DestInputPort": "In : Aqtk1T456_IO"
}, {
  "SrcBlkName": "tt123",
  "SrcOutputPort": "OUT :",
  "DestBlkName": "Aqtk1txsel",
  "DestInputPort": "In1 : tt123"
}, {
  "SrcBlkName": "Aqtk1T456",
  "SrcOutputPort": "OUT :",
  "DestBlkName": "Aqtk1txsel",
  "DestInputPort": "In2 : Aqtk1t456_io"
}, {
  "SrcBlkName": "tt123",
  "SrcOutputPort": "OUT :",
  "DestBlkName": "Aqtk1txsel2",
  "DestInputPort": "In1 : tt123"
}, {
  "SrcBlkName": "Aqtk1T456",
  "SrcOutputPort": "OUT :",
  "DestBlkName": "Aqtk1txsel2",
  "DestInputPort": "In2 : Aqtk1t456_io"
}]