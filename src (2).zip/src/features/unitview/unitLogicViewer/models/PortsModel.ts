class PortsModel{

    _inputPort :string='';
    get inputPort() {
      return this._inputPort;
    }
    set inputPort(value) {
      this._inputPort = value;
    }

    _outputPort :string='';
    get outputPort() {
      return this._outputPort;
    }
    set outputPort(value) {
      this._outputPort = value;
    }

}

export {PortsModel}