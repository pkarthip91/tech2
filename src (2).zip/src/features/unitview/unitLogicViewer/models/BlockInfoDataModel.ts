class BlockInfoDataModel
{
    /// <summary>
    /// Gets or sets interlock dictionary
    /// </summary>

    _blockCollection:Array<BlockDataInfo>=[]
    get blockCollection(){
        return this._blockCollection;
    }
    set blockCollection(value){
        this._blockCollection=value;
    } 
}

    /// <summary>
    /// Class to hold Block Name and Description
    /// </summary>
    class BlockInfo
    {
        /// <summary>
        /// Gets or sets Block Name
        /// </summary>
        _blkName:string=''
        get blkName(){
            return this._blkName;
        }
        set blkName(value){
            this._blkName=value;
        }

        /// <summary>
        /// Gets or sets Block Description
        /// </summary>
        _blkDescription:string=''
        get blkDescription(){
            return this._blkDescription;
        }
        set blkDescription(value){
            this._blkDescription=value;
        }

        /// <summary>
        /// Gets or sets CmType
        /// </summary>
        _cmType:string=''
        get cmType(){
            return this._cmType;
        }
        set cmType(value){
            this._cmType=value;
        }

        /// <summary>
        /// Gets or sets Is Link Node
        /// </summary>
        _isLinkNode:boolean=false;
        get isLinkNode(){
            return this._isLinkNode;
        }
        set isLinkNode(value){
            this._isLinkNode=value;
        }        

        /// <summary>
        /// Gets or sets is external variable
        /// </summary>
        _isExternalVariable:boolean=false;
        get isExternalVariable(){
            return this._isExternalVariable;
        }
        set isExternalVariable(value){
            this._isExternalVariable=value;
        }   
    }   


class BlockDataInfo extends BlockInfo
{
    /// <summary>
    /// Property for holding list of inputPortsCol
    /// </summary>
    _inputPortsCol:Array<string>=[]
    get inputPortsCol(){
        return this._inputPortsCol;
    }
    set inputPortsCol(value){
        this._inputPortsCol=value;
    }    


    /// <summary>
    /// Property for holding list of outputPortsCol
    /// </summary>
    _outputPortsCol:Array<string>=[]
    get outputPortsCol(){
        return this._outputPortsCol;
    }
    set outputPortsCol(value){
        this._outputPortsCol=value;
    }        
}

export{BlockDataInfo,BlockInfo,BlockInfoDataModel}