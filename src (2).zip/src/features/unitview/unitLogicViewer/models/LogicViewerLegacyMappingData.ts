class LogicViewerLegacyMappingData{
        /// <summary>
        /// Holds the value for [PCDL_CM_Type] DB Column
        /// </summary>
        cmType :string=''

        /// <summary>
        /// Holds the value for [PCSD_CM_Parameter] DB Column
        /// </summary>
        cm_Parameter :string=''

        /// <summary>
        /// Holds the value for [PCSD_CM_Element] DB Column
        /// </summary>
        cm_Element :string=''

        /// <summary>
        /// Holds the value for [PCSD_Table] DB Column
        /// </summary>
        feTable:string=''

        /// <summary>
        /// Holds the value for [PCDL_CM_Parameter] DB Column
        /// </summary>
        fe_Parameter :string=''
}
export {LogicViewerLegacyMappingData}