import {Plant} from './Plant';
import {TreeNode,AMLNodeTag} from './TreeNode';
//import {LVTransformer} from '../LogicViewerTransformer/LVTransformer';
import {LogicViewerLegacyMappingData} from './LogicViewerLegacyMappingData';
import {LVLegacyCMParameterData} from './LVLegacyCMParameterData';


class TransformationService{

    transformTree(treeNode:TreeNode):Plant{
        var dummyPlantService=new DummyPlantService();
        //var lvTransormation=new LVTransformer();
        //return lvTransormation.transformTreeNode(treeNode,'MyPlant','MyArea','MyCell',dummyPlantService.getMappingData(),dummyPlantService.getMappingCMParameterData());
        return new Plant();
    }
}
class DummyPlantService{
    getPlan():Plant{
        var plant=new Plant();
        plant.unitKey='My Key';
        return plant;
    }
    getMappingData():Array<LogicViewerLegacyMappingData>{
        var mappingData:Array<LogicViewerLegacyMappingData>=[];

        var logicViewerLegacyMappingData=new LogicViewerLegacyMappingData();
        logicViewerLegacyMappingData.cmType='Transmitter6DH'
        logicViewerLegacyMappingData.cm_Parameter='Description';
        logicViewerLegacyMappingData.cm_Element='Description';
        logicViewerLegacyMappingData.feTable='A';
        logicViewerLegacyMappingData.fe_Parameter='Description';

        mappingData.push(logicViewerLegacyMappingData);

        var logicViewerLegacyMappingData1=new LogicViewerLegacyMappingData();
        logicViewerLegacyMappingData1.cmType='Transmitter6DH'
        logicViewerLegacyMappingData1.cm_Parameter='CM_NAME';
        logicViewerLegacyMappingData1.cm_Element='Name';
        logicViewerLegacyMappingData1.feTable='A';
        logicViewerLegacyMappingData1.fe_Parameter='Name';

        mappingData.push(logicViewerLegacyMappingData1);

        return mappingData;
    }

    getMappingCMParameterData():Array<LVLegacyCMParameterData>{
        var mappingData:Array<LVLegacyCMParameterData>=[];
        var mapping=new LVLegacyCMParameterData();
        mapping.cmType='Transmitter6DH';
        mapping.cm_ID='8291';
        mapping.direction='in';
        mapping.paramName='AEHFilterTimeOff';
        mapping.portIndex=2210;

        var mapping1=new LVLegacyCMParameterData();
        mapping1.cmType='Transmitter6DH';
        mapping1.cm_ID='8291';
        mapping1.direction='out';
        mapping1.paramName='Out';
        mapping1.portIndex=1000;

        mappingData.push(mapping);
        mappingData.push(mapping1);
        return mappingData;
    }
}
class DummyTreeService{
    getTree():TreeNode{

        var firstTreeNode=this.firstTreeNode();
        var secondTreeNode=this.secondTreeNode();  

        var treeNode=new TreeNode();
        var amlNodeTag=new AMLNodeTag();
        amlNodeTag.parentName='Setpoints';
        treeNode.name='Root';
        treeNode.text='Tree Root';
        treeNode.nodes.push(firstTreeNode,secondTreeNode);

        return treeNode;
    }

    firstTreeNode():TreeNode{
        var treeNode=new TreeNode();
        var amlNodeTag=new AMLNodeTag();
        amlNodeTag.cmElement='IO';
        amlNodeTag.cmName='Aqtk1T456';
        amlNodeTag.cmType='Transmitter6DH';
        amlNodeTag.comment='';
        amlNodeTag.parentElement='T456';
        amlNodeTag.parentName='Xmtrs';
        amlNodeTag.pcsdTable='A_IO_List_FE';
        amlNodeTag.tagName='8375';
        treeNode.name=amlNodeTag.cmName;
        treeNode.text=amlNodeTag.cmName;
        treeNode.tag=amlNodeTag;

        var treeNode1=new TreeNode();
        var amlNodeTag1=new AMLNodeTag();
        amlNodeTag1.cmElement='IO';
        amlNodeTag1.cmName='Aqtk1T456';
        amlNodeTag1.cmType='Transmitter6DH';
        amlNodeTag1.comment='';
        amlNodeTag1.parentElement='T456';
        amlNodeTag1.parentName='Xmtrs';
        amlNodeTag1.pcsdTable='A_IO_List_FE';
        amlNodeTag1.tagName='8375';
        treeNode1.name=amlNodeTag.cmName;
        treeNode1.text=amlNodeTag.cmName;
        treeNode1.tag=amlNodeTag;


        treeNode.nodes.push(treeNode1);
        return treeNode;
    }

    secondTreeNode():TreeNode{
        var treeNode=new TreeNode();
        var amlNodeTag=new AMLNodeTag();
        amlNodeTag.cmElement='IO';
        amlNodeTag.cmName='Aqtk1temp1900';
        amlNodeTag.cmType='Transmitter6DH';
        amlNodeTag.comment='';
        amlNodeTag.parentElement='temp1900';
        amlNodeTag.parentName='Xmtrs';
        amlNodeTag.pcsdTable='A_IO_List_FE';
        amlNodeTag.tagName='8387';
        treeNode.name=amlNodeTag.cmName;
        treeNode.text=amlNodeTag.cmName;
        treeNode.tag=amlNodeTag;
        return treeNode;
    }    
}
export {DummyPlantService,DummyTreeService,TransformationService}