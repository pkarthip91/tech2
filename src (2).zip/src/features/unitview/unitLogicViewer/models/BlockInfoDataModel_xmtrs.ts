export const blockInfoDataModel_xmtrs = [{
  "InputPortsCol": ["Name : Aqtk1AqTk1TankLT",
    "Description : This level transmitter",
    "AESevOE : Pre-LOPA",
    "AEOEFilterTimeOn : 0",
    "AEOEFilterTimeOff : 0",
    "AELevelL : Aqtk1CalcReal1",
    "AESevL : Low",
    "AELFilterTimeOn : 2",
    "AELFilterTimeOff : 3",
    "AELHysteresis : 5"],
  "OutputPortsCol": ["OUT :"],
  "OnDraw": null,
  "BlkName": "Aqtk1AqTk1TankLT",
  "BlkDesc": "Aqtk1AqTk1TankLT\nTransmitter6DH",
  "CmType": "Transmitter6DH",
  "IsLinkNode": false,
  "IsExternalVariable": false
}, {
  "InputPortsCol": ["Name : Aqtk1pw1", "In : AqTk1TankLT_IO"],
  "OutputPortsCol": ["OUT :"],
  "OnDraw": null,
  "BlkName": "Aqtk1pw1",
  "BlkDesc": "Aqtk1pw1\nPiecewiseLinearCC",
  "CmType": "PiecewiseLinearCC",
  "IsLinkNode": false,
  "IsExternalVariable": false
}, {
  "InputPortsCol": ["Name : Aqtk1pw2", "In : tt123"],
  "OutputPortsCol": ["OUT :"],
  "OnDraw": null,
  "BlkName": "Aqtk1pw2",
  "BlkDesc": "Aqtk1pw2\nPiecewiseLinearCC",
  "CmType": "PiecewiseLinearCC",
  "IsLinkNode": false,
  "IsExternalVariable": false
}, {
  "InputPortsCol": ["Name : Aqtk1T456", "Description : A", "AESevOE : Medium", "AEOEFilterTimeOn : 0", "AEOEFilterTimeOff : 0"],
  "OutputPortsCol": ["OUT :"],
  "OnDraw": null,
  "BlkName": "Aqtk1T456",
  "BlkDesc": "Aqtk1T456\nTransmitter6DH",
  "CmType": "Transmitter6DH",
  "IsLinkNode": false,
  "IsExternalVariable": false
}, {
  "InputPortsCol": ["Name : Aqtk1temp1900", "Description : tag description here", "AESevOE : Low", "AEOEFilterTimeOn : 0", "AEOEFilterTimeOff : 0", "AELevelL : 33", "AESevL : Medium", "AELFilterTimeOn : 0", "AELFilterTimeOff : 0", "AELHysteresis : 0"],
  "OutputPortsCol": ["OUT :"],
  "OnDraw": null,
  "BlkName": "Aqtk1temp1900",
  "BlkDesc": "Aqtk1temp1900\nTransmitter6DH",
  "CmType": "Transmitter6DH",
  "IsLinkNode": false,
  "IsExternalVariable": false
}, {
  "InputPortsCol": ["Name : Aqtk1Total1", "Description : aa", "In : Aqtk1T456_IO"],
  "OutputPortsCol": ["OUT :"],
  "OnDraw": null,
  "BlkName": "Aqtk1Total1",
  "BlkDesc": "Aqtk1Total1\nTotalizerRealIO",
  "CmType": "TotalizerRealIO",
  "IsLinkNode": false,
  "IsExternalVariable": false
}, {
  "InputPortsCol": ["Name : tt123", "Description : bbb Aqtk1", "AESevOE : LOPA", "AEOEFilterTimeOn : 0", "AEOEFilterTimeOff : 0", "AELevelHH : 88", "AESevHH : High", "AEHHFilterTimeOn : 0", "AEHHFilterTimeOff : 0", "AEHHHysteresis : 0", "AELevelH : 37.236", "AESevH : LOPA", "AEHFilterTimeOn : 1", "AEHFilterTimeOff : 1", "AEHHysteresis : 3", "AELevelL : Aqtk1CalcReal2", "AESevL : Low", "AELFilterTimeOn : 1", "AELFilterTimeOff : 0", "AELHysteresis : 0"],
  "OutputPortsCol": ["OUT :"],
  "OnDraw": null,
  "BlkName": "tt123",
  "BlkDesc": "tt123\nTransmitter6DH",
  "CmType": "Transmitter6DH",
  "IsLinkNode": false,
  "IsExternalVariable": false
}, {
  "InputPortsCol": ["Name : Aqtk1txsel", "Description : AA", "In1 : tt123", "In2 : Aqtk1t456_io", "In3 :", "AELevelDev : 4", "AELevelH : 44", "AEDevFilterOnTime : 11", "AEDevHyst : 3.8", "AEHFilterTimeOn : 3333", "AEDevFilterOffTime : 22", "AEHFilterTimeOff : 33", "AEHHysteresis : 2", "AESevDev : Low", "AESevH : High"],
  "OutputPortsCol": ["OUT :"],
  "OnDraw": null,
  "BlkName": "Aqtk1txsel",
  "BlkDesc": "Aqtk1txsel\nTransmitterSelect",
  "CmType": "TransmitterSelect",
  "IsLinkNode": false,
  "IsExternalVariable": false
}, {
  "InputPortsCol": ["Name : Aqtk1txsel2", "Description : asdfafd", "In1 : tt123", "In2 : Aqtk1t456_io", "In3 :"],
  "OutputPortsCol": ["OUT :"],
  "OnDraw": null,
  "BlkName": "Aqtk1txsel2",
  "BlkDesc": "Aqtk1txsel2\nTransmitterSelect",
  "CmType": "TransmitterSelect",
  "IsLinkNode": false,
  "IsExternalVariable": false
}]