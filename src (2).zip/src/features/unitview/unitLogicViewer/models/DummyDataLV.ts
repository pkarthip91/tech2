import {Plant} from './Plant';
import {Block, Pin,ConnectInfo,TagName} from './Block';

class DummyDataLV{
    getGraphData():Plant{
        var plant =new Plant();
        plant.unitKey='PlantD:AqueousTanks:Tanks1to10:Xmtrs';
        plant.units.push(this.getFirstBlock(),this.getSecondBlock());
        return plant;
    }

    getFirstBlock():Block{
        var block=new Block();
        block.name='Aqtk1AqTk1TankLT';
        block.cmType='Transmitter6DH';
        //pin1
        var pin1=new Pin();
        pin1.pinType='Alarm';
        pin1.name='AESevOE : Pre-LOPA';
        pin1.direction='in';
        pin1.portIndex=1900;

        //pin2
        var pin2=new Pin();
        pin2.pinType='Alarm';
        pin2.name='AEOEFilterTimeOn : 0';
        pin2.direction='in';
        pin2.portIndex=1901;        
        //pin3
        var pin3=new Pin();
        pin3.pinType='Alarm';
        pin3.name='AEOEFilterTimeOff : 0';
        pin3.direction='in';
        pin3.portIndex=1902; 
        //pin4
        var pin4=new Pin();
        pin4.pinType='Alarm';
        pin4.name='AELevelL : Aqtk1CalcReal1';
        pin4.direction='in';
        pin4.portIndex=2300;   
        //pin5
        var pin5=new Pin();
        pin5.pinType='Alarm';
        pin5.name='AESevL : Low';
        pin5.direction='in';
        pin5.portIndex=2300;  
        //pin6
        var pin6=new Pin();
        pin6.pinType='Alarm';
        pin6.name='AELFilterTimeOn : 2';
        pin6.direction='in';
        pin6.portIndex=2310;                     
        //pin7
        var pin7=new Pin();
        pin7.pinType='Alarm';
        pin7.name='AELFilterTimeOff : 3';
        pin7.direction='in';
        pin7.portIndex=2320; 
        //pin8
        var pin8=new Pin();
        pin8.pinType='Alarm';
        pin8.name='AELHysteresis : 5';
        pin8.direction='in';
        pin8.portIndex=2330; 
        //pin9
        var pin9=new Pin();
        pin9.pinType='IO';
        pin9.name='Name : Aqtk1AqTk1TankLT';
        pin9.direction='in';
        pin9.portIndex=1; 
        //pin10
        var pin10=new Pin();
        pin10.pinType='IO';
        pin10.name='Description : This level transmitter';
        pin10.direction='in';
        pin10.portIndex=2;                         
        block.Pins.push(pin1,pin2,pin3,pin4,pin4,pin5,pin6,pin7,pin8,pin9,pin10);

        var tagName1=new TagName();
        tagName1.name='Aqtk1AqTk1TankLT_InstrumentFailure';

        var tagName2=new TagName();
        tagName2.name='Aqtk1AqTk1TankLT_Low';

        var tagName3=new TagName();
        tagName3.name='AqTk1TankLT_IO';
        
        block.Tags.push(tagName1,tagName2,tagName3);
        return block;
    }

    getSecondBlock():Block{
        var block=new Block();
        block.name='Aqtk1pw1';
        block.cmType='PiecewiseLinearCC';

        var connectInfo=new ConnectInfo();
        connectInfo.destinationBlockName='Aqtk1pw1';
        connectInfo.destinationInputPort='In : AqTk1TankLT_IO';

        block.connectionInfos.push(connectInfo);

        var pin1=new Pin();
        pin1.name='Name : Aqtk1pw1';
        pin1.pinType='Calc';
        pin1.direction='in';
        pin1.portIndex=1

        var pin2=new Pin();
        pin2.name='In : AqTk1TankLT_IO';
        pin2.pinType='Calc';
        pin2.direction='in';
        pin2.portIndex=10        

        block.Pins.push(pin1,pin2);

        var tagName1=new TagName();
        tagName1.name='Aqtk1pw1';

        block.Tags.push(tagName1);

        return  block;
    }
}

export{DummyDataLV}