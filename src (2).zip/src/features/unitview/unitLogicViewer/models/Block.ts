class Block
    {

      Pins : Array<Pin>=[];
        /*_pins:Array<Pin>=[];
        get Pins():Array<Pin>{
            return this._pins;
        }
        set Pins(value){
            this._pins=value;
        }*/

        _connectionInfos:Array<ConnectInfo>=[]        
        get connectionInfos(){
            return this._connectionInfos;
        }

        set connectionInfos(value){
            this._connectionInfos=value;
        }

        _tags:Array<TagName>=[]
        get Tags(){
            return this._tags;
        }
        set Tags(value){
            this._tags=value;
        }
        
        _name:string='';
        get name(){
            return this._name;
        }
        set name(value){
            this._name=value;
        }

        _cmType:string='';
        get cmType(){
            return this._cmType;
        }
        set cmType(value){
            this._cmType=value;
        }        

        constructor(other?:Block){
            if(other!==undefined){
                this.name=other.name;
                this.cmType=other.cmType;

                other.Pins.forEach(element => {
                    this.Pins.push(element);
                });
                other.connectionInfos.forEach(element => {
                    this.connectionInfos.push(element);
                });
                other.Tags.forEach(element => {
                    this.Tags.push(element);
                });                                

            }
        }

    }


class ConnectInfo{

    _sourceBlockName:string=''
    get sourceBlockName() {
        return this._sourceBlockName;
      }
      set sourceBlockName(value) {
        this._sourceBlockName = value;
      }

    _sourceUnitName:string=''
    get sourceUnitName() {
        return this._sourceUnitName;
      }
      set sourceUnitName(value) {
        this._sourceUnitName = value;
      }      

    _sourceOutputPort:string=''
    get sourceOutputPort() {
        return this._sourceOutputPort;
      }
      set sourceOutputPort(value) {
        this._sourceOutputPort = value;
      }  

    _sourcePageGroup:string=''
    get sourcePageGroup() {
        return this._sourcePageGroup;
      }
      set sourcePageGroup(value) {
        this._sourcePageGroup = value;
      }      

    _destinationBlockName:string=''
    get destinationBlockName() {
        return this._destinationBlockName;
      }
      set destinationBlockName(value) {
        this._destinationBlockName = value;
      }

    _destinationPageGroup:string=''
    get destinationPageGroup() {
        return this._destinationPageGroup;
      }
      set destinationPageGroup(value) {
        this._destinationPageGroup = value;
      }  
      
    _destinationInputPort:string=''
    get destinationInputPort() {
        return this._destinationInputPort;
      }
      set destinationInputPort(value) {
        this._destinationInputPort = value;
      }       

    constructor(other?:ConnectInfo)      {
        if(other!==undefined){
            this.sourceBlockName=other.sourceBlockName;
            this.sourceOutputPort=other.sourceOutputPort;
            this.sourcePageGroup=other.sourcePageGroup;
            this.sourceUnitName=other.sourceUnitName;
            this.destinationBlockName=this.destinationBlockName;
            this.destinationInputPort=this.destinationInputPort;
            this.destinationPageGroup=this.destinationPageGroup;
        }
    }
    }

    class Pin{
      constructor(public name : string='',
          public pinType : string='',
          public direction : string='',
          public portIndex : number=0){
  
          }
  }

class TagName
    {
        _name :string='';
        get name() {
          return this._name;
        }
        set name(value) {
          this._name = value;
        }

        _tagname :string='';
        get tagname() {
          return this._tagname;
        }
        set tagname(value) {
          this._tagname = value;
        }  

        constructor(other?:TagName) {
            if (other !== undefined){
                this.name = other.name;
            }
        }
        
    }

export {Block,ConnectInfo,Pin,TagName}    