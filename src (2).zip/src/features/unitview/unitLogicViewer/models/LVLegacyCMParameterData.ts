    /// <summary>
    /// Class to Store the Object Model of LegacyCMParameter
    /// </summary>
    class LVLegacyCMParameterData
    {
        /// <summary>
        /// Holds the value for [CM_ID] DB Column
        /// </summary>
        cm_ID : string='';

        /// <summary>
        /// Holds the value for [ParamName] DB Column
        /// </summary>
        paramName : string='';

        /// <summary>
        /// Holds the value for [Direction] DB Column
        /// </summary>
        direction : string='';

        /// <summary>
        /// Holds the value for [PortIndex] DB Column
        /// </summary>
        portIndex : number=0;

        /// <summary>
        /// Holds the value for [LegacyControlModule].[CMName] DB Column
        /// </summary>
        cmType : string='';
    }

    export {LVLegacyCMParameterData};