class TreeNode{

    _name:string='';
    get name(){
        return this._name;
    }
    set name(value){
        this._name=value;
    }
    _tag:AMLNodeTag=new AMLNodeTag();
    get tag(){
        return this._tag;
    }
    set tag(value){
        this._tag=value;
    }
    _text:string='';
    get text(){
        return this._text;
    }
    set text(value){
        this._text=value;
    }        
    _nodes:Array<TreeNode>=[]
    get nodes(){
        return this._nodes;
    }
    set nodes(value){
        this._nodes=value;
    }
}

class AMLNodeTag{
    
    _cmType:string='';
    get cmType(){
        return this._cmType;
    }
    set cmType(value){
        this._cmType=value;
    }
    _cmName:string='';
    get cmName(){
        return this._cmName;
    }
    set cmName(value){
        this._cmName=value;
    }   
    _tagName:string='';
    get tagName(){
        return this._tagName;
    }
    set tagName(value){
        this._tagName=value;
    }  
    _cmElement:string='';
    get cmElement(){
        return this._cmElement;
    }
    set cmElement(value){
        this._cmElement=value;
    } 
    _comment:string='';
    get comment(){
        return this._comment;
    }
    set comment(value){
        this._comment=value;
    }    
    _parentElement:string='';
    get parentElement(){
        return this._parentElement;
    }
    set parentElement(value){
        this._parentElement=value;
    }               
    _parentName:string='';
    get parentName(){
        return this._parentName;
    }
    set parentName(value){
        this._parentName=value;
    }  
    _pcsdTable:string='';
    get pcsdTable(){
        return this._pcsdTable;
    }
    set pcsdTable(value){
        this._pcsdTable=value;
    }         
}
export{TreeNode,AMLNodeTag}