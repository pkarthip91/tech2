import { ConnectInfo, Pin } from "../models/Block";
import { BlockConnectionInfo, BlockConnectionInfoDataModel } from "../models/BlockConnectionModel";
import { BlockDataInfo, BlockInfo, BlockInfoDataModel } from "../models/BlockInfoDataModel";
import { Plant } from "../models/Plant";

export class GraphMapper {
    private _plant: Plant;
    blockInfoDataModel: BlockInfoDataModel = new BlockInfoDataModel();
    blockConnectionInfoDataModel = new BlockConnectionInfoDataModel();

    constructor(plantInfo: Plant) {
        this._plant = plantInfo;
        this.addExternalVariable(this._plant, this.blockInfoDataModel, this.blockConnectionInfoDataModel);
        this.addBlockConnectionInfo(this._plant, this.blockInfoDataModel, this.blockConnectionInfoDataModel);
        for (let i: number = 0; i < plantInfo.units.length; i++) {
            if (plantInfo.units[i].name != '') {
                var blockDataInfo = this.addBlockDataInfo(plantInfo, i);
                if (blockDataInfo != null) {
                    this.blockInfoDataModel.blockCollection.push(blockDataInfo);
                }

                if (plantInfo.units[i].connectionInfos == null) continue;
                var parsedConnectionInfo = this.parseConnectionsBasedOnTagNames(plantInfo.units[i].connectionInfos, plantInfo);
                console.log('parsedConnectionInfo'+plantInfo.units[i].name,parsedConnectionInfo)
                plantInfo.units[i].connectionInfos = [];
                plantInfo.units[i].connectionInfos = parsedConnectionInfo;


                //Logic to find output name based on tagnames/variable information
                //Made changes in order to refer tagnames instead of cmnames
                let parsedOutConnectionInfo: Array<ConnectInfo> = this.parseOutPutConnectionsBasedOnTagNames(plantInfo.units[i].connectionInfos, plantInfo);
                plantInfo.units[i].connectionInfos = [];


                plantInfo.units[i].connectionInfos = parsedOutConnectionInfo;
                let j = 0;
                plantInfo.units[i]._connectionInfos.forEach(item => {
                    console.log('>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>', j)
                    var blockConnectionInfo = new BlockConnectionInfo();

                    blockConnectionInfo.destinationName = item.destinationBlockName;
                    blockConnectionInfo.destinationInputPort = item.destinationInputPort;
                    blockConnectionInfo.sourceName = item.sourceBlockName;
                    blockConnectionInfo.sourceOutputPort = item.sourceOutputPort;
                    console.log(j, blockConnectionInfo.sourceName)
                    if (blockConnectionInfo.sourceName !== '')
                        this.blockConnectionInfoDataModel.blockConnectionInfos.push(blockConnectionInfo);
                    j = j + 1;

                });

            }
        }

        let b = this.blockConnectionInfoDataModel.blockConnectionInfos.filter(x => x.sourceName == '')
        b.forEach(f => this.blockConnectionInfoDataModel.blockConnectionInfos.splice(this.blockConnectionInfoDataModel.blockConnectionInfos.findIndex(e => e.destinationName === f.destinationName), 1));


    }
    parseOutPutConnectionsBasedOnTagNames(connectionInfos: ConnectInfo[], plantInfo: Plant): Array<ConnectInfo> {
        let parsedConnectInfos: Array<ConnectInfo> = [];

        connectionInfos.forEach(item => {
            let blockConnectionInfo = new ConnectInfo();
            blockConnectionInfo.destinationBlockName = item._destinationBlockName;
            blockConnectionInfo.destinationInputPort = item.destinationInputPort;
            blockConnectionInfo.sourcePageGroup = item.sourcePageGroup;
            blockConnectionInfo.destinationPageGroup = item.destinationPageGroup;
            blockConnectionInfo.sourceUnitName = item.sourceUnitName;
            blockConnectionInfo.sourceBlockName = item.sourceBlockName;

            let blockToParse = plantInfo.units.find(block => block.name == blockConnectionInfo.sourceBlockName);



            if (blockToParse != null && blockToParse.Pins != null && blockToParse.Pins.length > 1) {
                blockToParse.Pins.forEach(opin => {

                    console.log('opin', blockConnectionInfo)
                    if ((opin.direction.toLowerCase() == "in" || opin.direction.toLowerCase() == "in_out") &&
                        (blockConnectionInfo.sourceOutputPort == '' || blockConnectionInfo.sourceOutputPort == null))
                        return;
                    console.log('opin', opin)
                    let outputStrings = opin.name.split(':');
                    if (outputStrings.length <= 1 || (blockConnectionInfo.sourceOutputPort !== ''))
                        return;
                    let destTagNames = plantInfo.units.filter(t => t.name.toLowerCase() == blockConnectionInfo.destinationBlockName)[0].Tags;
                    if (!destTagNames)
                        return;

                    destTagNames.forEach(tagNames => {
                        let ports = blockConnectionInfo.destinationInputPort.split('.');
                        let ports1 = opin.name.split(':');
                        if (ports.length > 1 && ports1.length > 0 && ports[1] == ports1[0]) {
                            blockConnectionInfo.sourceOutputPort = opin.name;
                            return;
                        }

                        if (outputStrings[1] !== tagNames.name)
                            return;
                        blockConnectionInfo.sourceOutputPort = opin.name;
                        return;

                    });



                    if (blockConnectionInfo.sourceOutputPort != null && blockToParse != null) {
                        if (blockToParse.Pins != null) {
                            let result = null;
                            try {
                                result = blockToParse.Pins.filter(pin => pin.name.includes(blockConnectionInfo.sourceBlockName) && pin.direction == 'out')[0];
                            }
                            catch (InvalidOperationException) {

                            }

                            if (result != null && result.name != '')
                                blockConnectionInfo.sourceOutputPort = result.name;

                            else {
                                blockConnectionInfo.sourceOutputPort = 'OUT' + ' :';
                            }
                        }
                    }

                });
            }
            blockConnectionInfo.sourceOutputPort = 'OUT' + ' :';
            parsedConnectInfos.push(blockConnectionInfo);

        });
        return parsedConnectInfos;
    }


    addBlockDataInfo = (plant: Plant, index: number) => {
        let blockDataInfo = new BlockDataInfo();
        if (!plant.units[index].Pins.find(x => x.direction == 'out')) {
            blockDataInfo.outputPortsCol = [];
            blockDataInfo.outputPortsCol.push('OUT :')
        }

        blockDataInfo.blkName = plant.units[index].name;
        blockDataInfo.blkDescription = plant.units[index].name + "\n" + plant.units[index].cmType;
        blockDataInfo.cmType = plant.units[index].cmType;

        let sortedInputList = plant.units[index].Pins.sort(x => x.portIndex);

        let filteredSortedInputList = sortedInputList.filter(itemInput =>
            (itemInput.direction == 'in' || itemInput.direction == 'in_out'))
            .filter(itemInput => !blockDataInfo.inputPortsCol.includes(itemInput.name))

        if (filteredSortedInputList && filteredSortedInputList.length > 0) {
            filteredSortedInputList.forEach(item => {
                blockDataInfo.inputPortsCol.push(item.name)
            })
        }

        let filteredSortedOutputList = sortedInputList.filter(itemInput =>
            (itemInput.direction == 'out'))
            .filter(itemInput => !blockDataInfo.inputPortsCol.includes(itemInput.name))

        if (filteredSortedOutputList && filteredSortedOutputList.length > 0) {
            filteredSortedOutputList.forEach(item => {
                blockDataInfo.outputPortsCol.push(item.name.toUpperCase() + ' :')
            })
        }

        if (blockDataInfo.outputPortsCol != null && blockDataInfo.outputPortsCol.length > 1) {
            let duplicate =
                blockDataInfo.outputPortsCol.filter(x => x.toUpperCase().includes("OUT :")).length;

            if (duplicate > 1) {
                delete blockDataInfo.outputPortsCol[
                    blockDataInfo.outputPortsCol.findIndex(n => n == "OUT :")];
            }
        }
        return blockDataInfo;
    }
    addBlockConnectionInfo = (plant: Plant, blockInfoDataModel: BlockInfoDataModel, blockConnectionInfo: BlockConnectionInfoDataModel) => {

        console.log(blockInfoDataModel);
        plant.units.filter(block => block.connectionInfos != null).forEach(block => {
            if (block.connectionInfos && block.connectionInfos.length > 0) {
                if (block.name && block.connectionInfos.filter(conn => conn.sourcePageGroup || conn.destinationPageGroup).length > 0) {
                    console.log('-----------------------------')
                    block.connectionInfos.forEach(item => {
                        {
                            let cinfo = new BlockConnectionInfo();
                            cinfo.destinationName = item.destinationBlockName;
                            cinfo.destinationInputPort = item.destinationInputPort;
                            cinfo.sourceName = item.sourceBlockName;
                            cinfo.sourceOutputPort = item.sourceOutputPort;// item.sourceOutputPort.toUpperCase() + ' :';
                            let blockDataInfo = new BlockDataInfo();
                            blockDataInfo.isLinkNode = true;

                            if (item.sourcePageGroup && item.sourcePageGroup != '') {
                                blockDataInfo.blkName = item.sourceBlockName;
                                blockDataInfo.blkDescription = item.sourceBlockName;
                                blockDataInfo.cmType = item.sourcePageGroup;
                                cinfo.sourceOutputPort = item.sourceBlockName + " : " + item.sourceOutputPort;
                                blockDataInfo.outputPortsCol.push(cinfo.sourceOutputPort);
                                //destLinkBlocks.blockCollection.push(blockDataInfo);
                            }
                            else if (item.destinationPageGroup) {
                                blockDataInfo.blkName = item.destinationBlockName;
                                blockDataInfo.blkDescription = item.destinationBlockName;
                                blockDataInfo.cmType = item.destinationPageGroup;
                                cinfo.destinationInputPort = item.destinationBlockName + ' : ' + item.destinationInputPort;
                                blockDataInfo.inputPortsCol.push(cinfo.destinationInputPort);
                                //destLinkBlocks.push(blockDataInfo, 1);
                            }

                            let exists = blockConnectionInfo.blockConnectionInfos.filter(connInfo => (
                                connInfo.destinationName == cinfo.destinationName &&
                                connInfo.destinationInputPort == cinfo.destinationInputPort &&
                                connInfo.sourceName == cinfo.sourceName &&
                                connInfo.sourceOutputPort == cinfo.sourceOutputPort
                            )).length>0;

                            if (!exists)
                                blockConnectionInfo.blockConnectionInfos.push(cinfo);
                        }


                    });

                }

            }
        })
        console.log(blockInfoDataModel);
    }


    addExternalVariable = (plant: Plant, blockInfoDataModel: BlockInfoDataModel, connectionInfoDataModel: BlockConnectionInfoDataModel) => {
        plant.units.filter(blk => blk.connectionInfos != null && blk.connectionInfos.length > 0).forEach(block => {
            let blocks = block.connectionInfos.filter(conn => conn.sourceUnitName);
            if (blocks.length > 0 && block.name != '') {
                let filteredBlocks = block.connectionInfos.filter(conn => conn.sourceUnitName);
                filteredBlocks.forEach(block => {
                    let blockConnectionInfo = new BlockConnectionInfo();
                    blockConnectionInfo.destinationName = block.destinationBlockName;
                    blockConnectionInfo.destinationInputPort = block.destinationInputPort;
                    blockConnectionInfo.sourceName = block.sourceBlockName;
                    blockConnectionInfo.sourceOutputPort = block.destinationInputPort;//block.sourceOutputPort.toUpperCase() + ' :';

                    let blockDataInfo = new BlockDataInfo();
                    blockDataInfo.isLinkNode = true;
                    blockDataInfo.isExternalVariable = true;

                    blockDataInfo.blkName = block.sourceUnitName;
                    blockDataInfo.blkDescription = block.sourceUnitName;
                    blockDataInfo.cmType = block.sourceUnitName;
                    blockDataInfo.outputPortsCol.push(blockConnectionInfo.sourceOutputPort);
                    //blkInfoObj.BlockCollection.Add(blockDataInfo, 1);
                    connectionInfoDataModel.blockConnectionInfos.push(blockConnectionInfo);



                });

            }
        });

    }
    parseConnectionsBasedOnTagNames(blockConnectionInfo: Array<ConnectInfo>, plantInfo: Plant): Array<ConnectInfo> {
        let parsedConnectInfos = new Array<ConnectInfo>;
        blockConnectionInfo.forEach(item => {

            let inputStrings = item.destinationInputPort.split(':');

            let blockConnectionInfo = new ConnectInfo();
            blockConnectionInfo.destinationBlockName = item._destinationBlockName;
            blockConnectionInfo.destinationInputPort = item.destinationInputPort;
            blockConnectionInfo.sourcePageGroup = item.sourcePageGroup;
            blockConnectionInfo.destinationPageGroup = item.destinationPageGroup;
            blockConnectionInfo.sourceUnitName = item.sourceUnitName;

            plantInfo.units.forEach(block => {

                if (blockConnectionInfo.sourceBlockName)
                    return;

                block.Tags.forEach(tag => {
                    if (inputStrings.length <= 0)
                        return;
                    let targetBlock = inputStrings[1];
                    if (targetBlock && targetBlock.includes('.')) {
                        let targetBlockDtls = targetBlock.split('.');
                        targetBlock = targetBlockDtls[0];
                    }

                    if (tag.name.toLowerCase().trim() !== targetBlock.toLowerCase().trim()){
                        return;
                    }

                    else {
                        console.log('Bingo .....................:)')
                        blockConnectionInfo.sourceBlockName = block.name;
                        return;

                    }




                });

            });

            console.log('blockConnectionInfo', blockConnectionInfo);
            parsedConnectInfos.push(blockConnectionInfo);

        });



        return parsedConnectInfos;

    }
}