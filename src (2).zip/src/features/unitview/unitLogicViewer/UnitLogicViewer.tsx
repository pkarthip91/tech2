import { createRef, RefObject, useEffect, useState } from 'react';
import { Class, GraphComponent, GraphViewerInputMode, IPort, LayoutExecutor, License, Point, Rect, ShapeNodeStyle, Stroke } from 'yfiles';

import { useAppSelector } from '../../../app/hooks';
import NodeTemplate from '../../common/yFiles/components/templates/NodeTemplate';
import ReactComponentNodeStyle from '../../common/yFiles/components/templates/ReactComponentNodeStyle';
import { applyLicence } from '../../common/yFiles/service/LicenceService';
import { GraphMapper } from './graphMapper/graphMapper';
import { BlockConnectionInfo, BlockConnectionInfoDataModel } from './models/BlockConnectionModel';
import { BlockDataInfo, BlockInfoDataModel } from './models/BlockInfoDataModel';
import { PlantMapper } from './plantMapper/plantMapper';
import { applyHierarchicLayout } from './service/UnitLogicViewerHierarchicLayoutService';
import { applyTabularLayout } from './service/UnitLogicViewerTablularLayoutService';
import './styles/UnitLogicViewerStyles.css'
import { INIT_X_POSITION, INIT_Y_POSITION, } from './UnitLogicViewerConstants';
import React from 'react';

export const UnitLogicViewer = (props: any) => {
  applyLicence()
  const { mappingParameter } = useAppSelector((state: any) => state.mappingParameterView)
  const { mappingCMParameter } = useAppSelector((state: any) => state.mappingCMParameterView)
  const { unitPcsdData } = useAppSelector((state: any) => state.unitviewPCSDdata)
  // License.value = yFilesLicense;
  Class.ensure(LayoutExecutor)
  let graphDiv: RefObject<HTMLDivElement> = createRef<HTMLDivElement>();
  let graphComponent: GraphComponent = new GraphComponent();

  let blockInfoModel: BlockInfoDataModel | null = null

  enum layoutMode {
    tabular = 1,
    hierarchic
  }

  const [currentLayout, setCurrentLayout] = useState(layoutMode.tabular)

  const initGraph = () => {
    graphComponent.graph.clear();
    graphDiv.current!.appendChild(graphComponent.div);
    graphComponent.inputMode = new GraphViewerInputMode()
    createGraph(props.selectedNode);
    switch (currentLayout) {
      case layoutMode.hierarchic: applyHierarchicLayout(graphComponent)
        break
      case layoutMode.tabular: applyTabularLayout(graphComponent)
        break
    }
    graphComponent.fitGraphBounds();
  }

  const createGraph = (node: any) => {
    let graphMapper: GraphMapper | null = null;
    if ((mappingParameter && mappingCMParameter && unitPcsdData)) {
      let plantMapper = new PlantMapper(Object.assign(unitPcsdData, {}));
      let plant = plantMapper.mapPlant(node,
        mappingParameter,
        mappingCMParameter);
      graphMapper = new GraphMapper(plant);

      // blockInfoModel = mapToLogicViewerData(node)
      blockInfoModel = graphMapper.blockInfoDataModel
      let yPos: number = INIT_Y_POSITION
      blockInfoModel?.blockCollection.map((block: BlockDataInfo, index: number) => {
        let xPos: number = INIT_X_POSITION * index
        createNode(block, graphMapper?.blockConnectionInfoDataModel, xPos, yPos)
      }
      )
      createEdge(graphMapper?.blockConnectionInfoDataModel)
    }
  }

  const removeDuplicateConnection = (connectionData: any): any[] => {
    return connectionData?.blockConnectionInfos.reduce((g: any[], i: any) => {
      if (!(g.find((a: any) => a.sourceName == i.sourceName &&
        a.destinationName == i.destinationName &&
        a.sourceOutputPort == i.sourceOutputPort &&
        a.destinationInputPort == i.destinationInputPort)) && (i.sourceName != i.destinationName))
        g.push(i);
      return g
    }, [])
  }
  const createEdge = (connectionData: any) => {
    let conn: any = connectionData?.blockConnectionInfos//removeDuplicateConnection(connectionData) || []
    conn.map((data: any) => {
      const sport = graphComponent.graph.nodes.find(n => n.tag.blkName == data.sourceName)?.ports.filter((p: IPort) => p.tag == data.sourceOutputPort).toArray()[0]
      const dport = graphComponent.graph.nodes.find(n => n.tag.blkName == data.destinationName)?.ports.filter((p: IPort) => p.tag == data.destinationInputPort).toArray()[0]
      if (sport && dport)
        graphComponent.graph.createEdge(sport, dport, null, data.SrcBlkName + data.DestBlkName)
    })
  }

  const style = new ShapeNodeStyle({
    fill: 'rgb(255, 238, 238)',
    shape: 'round-rectangle',
    stroke: new Stroke({ fill: 'black', thickness: 5 })
  });

  const calculateNodeSize = (block: BlockDataInfo) => {
    const headerHeight = 14 + 13
    let y = headerHeight + (block.inputPortsCol.length > block.outputPortsCol.length
      ? block.inputPortsCol.length * 15 : block.outputPortsCol.length * 15) + 15

    let maxInputPortLength = block.inputPortsCol.reduce((m, t) => { if (m < t.length) m = t.length; return m }, 0)
    let maxOutPortLength = block.outputPortsCol.reduce((m, t) => { if (m < t.length) m = t.length; return m }, 0)
    let maxHeaderLength = block.blkName.length > block.cmType.length ? block.blkName.length : block.cmType.length

    let x = ((maxInputPortLength + maxOutPortLength) > maxHeaderLength ? (maxInputPortLength + maxOutPortLength) * 7 : maxHeaderLength * 10)

    return { x, y }
  }
  const createNode = (block: BlockDataInfo, connectionInfos: BlockConnectionInfoDataModel | undefined, xPos: number, yPos: number) => {
    let isOutputUsed = connectionInfos?.blockConnectionInfos.find(
      (bc: BlockConnectionInfo) => bc.sourceName == block.blkName
    )
    if (!isOutputUsed) {
      block.outputPortsCol = []
    }
    const { x, y } = calculateNodeSize(block)
    const node = graphComponent.graph.createNode({
      layout: new Rect(xPos, yPos, x, y),
      style: new ReactComponentNodeStyle(NodeTemplate),
      tag: block
    });

    block.inputPortsCol.map((inputPort: string, index: number) => {
      if ((/[in\d*\s:]+/).test(inputPort.toLocaleLowerCase())) {
        graphComponent.graph.addPortAt(node, new Point(node.layout.x + 5, node.layout.y + 30 + (12 * index) + 10), null, inputPort)
      }
    })

    block.outputPortsCol.map((outPort: string, index: number) => {
      if ((/[out\d*\s:]+/).test(outPort.toLocaleLowerCase())) {
        graphComponent.graph.addPortAt(node, new Point(node.layout.x + x, node.layout.y + 30 + (12 * index) + 10), null, outPort)
      }
    })
  }

  useEffect(() => {
    initGraph();
  }, []);

  useEffect(() => {
    graphDiv.current?.removeChild(graphDiv.current.children[0]); initGraph();
  }, [props.selectedNode, currentLayout]);

  return (
    <>
      <div className='text-center'>
        <label className='layout-type'>
          <input
            type="radio"
            value={layoutMode.tabular}
            checked={currentLayout === layoutMode.tabular}
            onChange={(e) => setCurrentLayout(layoutMode.tabular)}
          />
          Table Layout
        </label>
        <label className='layout-type'>
          <input
            type="radio"
            value={layoutMode.hierarchic}
            checked={currentLayout === layoutMode.hierarchic}
            onChange={(e) => setCurrentLayout(layoutMode.hierarchic)}
          />
          Hierarchic Layout
        </label>
      </div>
      <div className="graph-component-container" ref={graphDiv} />
    </>
  )
}