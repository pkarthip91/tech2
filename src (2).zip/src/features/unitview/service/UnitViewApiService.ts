import { httpClient } from '../../../app/api/middlewareSecurity'

export const unitViewTreeDataService = (userToken: string, unitId: number) => {
  return httpClient.get(`/unit/${unitId}`, {
    headers: {
      "Authorization": `Bearer ${userToken}`,
      "Accept": "text/plain"
    }
  })
}

export const unitViewPCSDDataService = (userToken: string, unitId: number) => {
  return httpClient.get(`/LogicViewer/PCSDData/${unitId}`, {
    headers: {
      "Authorization": `Bearer ${userToken}`,
      "Accept": "text/plain"
    }
  })
}

export const unitViewParameterSaveService = (userToken: string,
  tableName: string,
  tagName: string,
  pcsdKey: number,
  key: string,
  value: string) => {
  let data = JSON.stringify({ tableName, tagName, pcsdKey, key, value })
  return httpClient.post(`/LogicViewer/PCSDData`,
    data, {
    headers: {
      "Authorization": `Bearer ${userToken}`,
      "Content-Type": "application/json"
    }
  })
}
