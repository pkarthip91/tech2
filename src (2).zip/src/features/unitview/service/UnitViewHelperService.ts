import { create } from "domain";
import { Logger } from "../../../app/common/LoggerService";
import { SecondLevelOrder, TreeNodeLevel } from "../models/UnitViewEnums";
import { IUnitViewTreeModel } from "../models/UnitViewTreeInterface";
import { UnitViewTreeModel } from "../models/UnitViewTreeModel";
import { UnitViewTreeResponseType } from "../models/UnitViewTreeResponseType";

const createNode = (data: { row?: UnitViewTreeResponseType, unitName?: string, order?: number, pgGroup?: boolean, level?: TreeNodeLevel }): UnitViewTreeModel => {
  let node = new UnitViewTreeModel(data.unitName, data.order, data.pgGroup)
  node.nodeLevel = data.level || null
  if (data.row) {
    node.amlNodeTag.cmElement = data.row.cM_Element
    node.amlNodeTag.cmName = data.row.cM_Name
    node.amlNodeTag.cmType = data.row.cM_Type
    node.amlNodeTag.parentElement = data.row.parent_Element
    node.amlNodeTag.parentName = data.row.parent_Name
    node.amlNodeTag.pcsdTable = data.row.pcsdTable
    node.amlNodeTag.tagName = data.row.tag_Name
    node.amlNodeTag.pcsdKey = data.row.pcsDdataKey
  }
  return node
}

const sortByOrder = (obj: IUnitViewTreeModel | null): void => {
  if (obj) {
    obj.getChildView()?.sort((a, b) => (a.order == b.order ? 0 : (a.order < b.order ? -1 : 1)))
  }

}

export const mapUnitViewTreeResponseData = (unitName: string, treeResponseData: UnitViewTreeResponseType[]): IUnitViewTreeModel | null => {
  Logger.info('unit api--', treeResponseData)
  let mappedUnitViewTreeData: IUnitViewTreeModel | null = null;

  if (treeResponseData && treeResponseData.length > 0) {
    mappedUnitViewTreeData = createNode({ unitName, level: TreeNodeLevel.ROOT });

    treeResponseData.map((row: UnitViewTreeResponseType, i: number) => {
      let level_one_Node: IUnitViewTreeModel | null = null
      let level_two_Node: IUnitViewTreeModel | null = null
      let leafeNode: IUnitViewTreeModel = createNode({ row, level: TreeNodeLevel.LEAF_NODE })

      if (row.parent_Name) {
        level_one_Node = mappedUnitViewTreeData?.getChildView().find((p: IUnitViewTreeModel) => p.amlNodeTag.parentName == row.parent_Name) || null
        if (!level_one_Node) {
          let pgGroup = false
          let order = 1000
          switch (row.parent_Name.toLowerCase()) {
            case 'aqtk1':
              order = SecondLevelOrder.aqtk1
              break
            case 'calcs':
              order = SecondLevelOrder.calcs
              break
            case 'setpoints':
              order = SecondLevelOrder.setpoints
              break
            case 'externalvar':
              order = SecondLevelOrder.externalvar
              break
            case 'steps':
              order = SecondLevelOrder.steps
              break
            default: pgGroup = true
          }
          level_one_Node = createNode({ row, order, pgGroup, level: TreeNodeLevel.LEVEL_ONE })
          mappedUnitViewTreeData?.addChildView(level_one_Node);
        }
      }

      if (row.parent_Element) {
        let level_one_node_exist = mappedUnitViewTreeData?.getChildView().find(
          (p: IUnitViewTreeModel) => p.amlNodeTag.parentName == row.parent_Name) || null
        if (level_one_node_exist) {
          let level_two_node_exist = level_one_node_exist.getChildView().find((p: IUnitViewTreeModel) => p.amlNodeTag.parentElement == row.parent_Element) || null
          if (!level_two_node_exist) {
            level_two_Node = createNode({ row, level: TreeNodeLevel.LEVEL_TWO })
            level_one_node_exist.addChildView(level_two_Node);
          } else {
            level_two_Node = level_two_node_exist
          }
        }
      }

      if (level_one_Node) {
        if (level_two_Node) {
          level_two_Node.addChildView(leafeNode)
        }
      }
    });
  }
  sortByOrder(mappedUnitViewTreeData)
  return mappedUnitViewTreeData;
}



