import { createSlice } from '@reduxjs/toolkit';
import { unitViewPCSDDataAction } from '../actions/UnitViewPCSDdataActions';
import { unitViewParameterSaveAction } from '../actions/UnitViewPrameterSaveActions';
import { UNIT_VIEW_REDUCER } from '../UnitViewConstant';
import { updatePCSDdata } from './UnitViewHelper';

interface IUnitPcsdDataState {
  loading: boolean,
  unitPcsdData: any,
  error: string | null
}
const initialState: IUnitPcsdDataState = {
  loading: true,
  unitPcsdData: null,
  error: null
}

export const unitviewPCSDdataSlice = createSlice({
  name: `${UNIT_VIEW_REDUCER}PCSD`,
  initialState,
  reducers: {
  },
  extraReducers: (builder) => {
    builder
      .addCase(unitViewPCSDDataAction.pending, (state) => {
        state.loading = true;
      })
      .addCase(unitViewPCSDDataAction.fulfilled, (state, { payload }: any) => {
        state.loading = false;
        state.unitPcsdData = payload;
      })
      .addCase(unitViewPCSDDataAction.rejected, (state, { payload }: any) => {
        state.loading = false;
        state.error = payload
      })
      .addCase(unitViewParameterSaveAction.pending, (state) => {
        state.loading = true;
      })
      .addCase(unitViewParameterSaveAction.fulfilled, (state, { payload }: any) => {
        state.loading = false;
        state.unitPcsdData = updatePCSDdata(Object.assign([], JSON.parse(JSON.stringify(state.unitPcsdData))), payload)
      })
      .addCase(unitViewParameterSaveAction.rejected, (state, { payload }: any) => {
        state.loading = false;
        state.error = payload
      })
  },
});

export default unitviewPCSDdataSlice.reducer;
