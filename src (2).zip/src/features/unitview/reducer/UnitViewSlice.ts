import { createSlice } from '@reduxjs/toolkit';
import { unitViewTreeDataAction } from '../actions/UnitViewActions';
import { unitViewPCSDDataAction } from '../actions/UnitViewPCSDdataActions';
import { IUnitViewTreeModel } from '../models/UnitViewTreeInterface';
import { UNIT_VIEW_REDUCER } from '../UnitViewConstant';

interface IPlantViewState {
  loading: boolean,
  unitViewTreeData: IUnitViewTreeModel | null,
  error: string | null
}
const initialState: IPlantViewState = {
  loading: true,
  unitViewTreeData: null,
  error: null
}

export const unitviewSlice = createSlice({
  name: `${UNIT_VIEW_REDUCER}`,
  initialState,
  reducers: {
  },
  extraReducers: (builder) => {
    builder
      .addCase(unitViewTreeDataAction.pending, (state) => {
        state.loading = true;
      })
      .addCase(unitViewTreeDataAction.fulfilled, (state, { payload }: any) => {
        state.loading = false;
        state.unitViewTreeData = payload;
      })
      .addCase(unitViewTreeDataAction.rejected, (state, { payload }: any) => {
        state.loading = false;
        state.error = payload
      })
      .addCase(unitViewPCSDDataAction.pending, (state) => {
        state.loading = true;
      })
  },
});

export default unitviewSlice.reducer;
