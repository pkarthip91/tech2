export const updatePCSDdata = (stateData: any, payload: any) => {
  const { tableName, tagName, pcsdKey, key, value } = payload
  let tblParameter = stateData.find((tbl: any) =>
    (tbl.key.toLowerCase() === tableName.toLowerCase()) ||
    (tbl.key.toLowerCase() === tableName.toLowerCase().split('_fe')[0]));

  let tagParameter = tblParameter?.value.find((tag: any) => tag.key.toLowerCase() === tagName.toLowerCase());

  let parameter = tagParameter?.value.find((m: any) => m.key == key);

  if (parameter) {
    parameter.value = value
  }
  return stateData
}
