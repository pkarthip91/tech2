import { TreeNodeLevel } from "./UnitViewEnums";
import { IUnitViewTreeModel } from "./UnitViewTreeInterface";

export class UnitViewTreeModel implements IUnitViewTreeModel {
  constructor(
    public unitName: string = '',
    public order: number = 1000,
    public isPgGrp: boolean = false,
    private childView: IUnitViewTreeModel[] | null = null,
    public amlNodeTag: AMLnodeTag = new AMLnodeTag(),
    public nodeLevel: TreeNodeLevel | null = null
  ) { }

  public getChildView = (): IUnitViewTreeModel[] => this.childView ? this.childView : [];
  public getNodeText = (): string => {
    let nodeTextArray: string[] = []
    if (this.nodeLevel != null) {
      switch (this.nodeLevel) {
        case TreeNodeLevel.LEAF_NODE:
          if (this.amlNodeTag.pcsdTable) {
            const tableStrings = this.amlNodeTag.pcsdTable.split(/[_]/)
            if (tableStrings && tableStrings.length > 1) {
              nodeTextArray.push(tableStrings[1])
            }
          }
          if (this.amlNodeTag.tagName) {
            nodeTextArray.push(this.amlNodeTag.tagName)
          }
          if (this.amlNodeTag.cmType) {
            nodeTextArray.push(this.amlNodeTag.cmType)
          }
          if (this.amlNodeTag.cmElement) {
            nodeTextArray.push(this.amlNodeTag.cmElement)
          }
          break
        case TreeNodeLevel.LEVEL_TWO:
          if (this.amlNodeTag.parentElement) {
            nodeTextArray.push(this.amlNodeTag.parentElement)
          }
          if (this.amlNodeTag.cmName) {
            nodeTextArray.push(this.amlNodeTag.cmName)
          }
          if (this.amlNodeTag.cmType) {
            nodeTextArray.push(this.amlNodeTag.cmType)
          }
          break
        case TreeNodeLevel.LEVEL_ONE:
          if (this.amlNodeTag.parentName) {
            nodeTextArray.push(this.amlNodeTag.parentName)
          }
          if (this.isPgGrp) {
            nodeTextArray.push('PgGrp')
          }
          break
        case TreeNodeLevel.ROOT:
          nodeTextArray.push(this.unitName)
      }
    }
    return nodeTextArray.join(', ')
  }

  public addChildView = (child: IUnitViewTreeModel): void => {
    if (!this.childView) {
      this.childView = []
    }
    this.childView.push(child)
  }
}

export class AMLnodeTag {
  constructor(
    public cmElement: string = '',
    public cmName: string = '',
    public cmType: string = '',
    public comment: string = '',
    public parentElement: string = '',
    public parentName: string = '',
    public tagName: string = '',
    public pcsdTable: string = '',
    public pcsdKey: number | null = null

  ) { }
}