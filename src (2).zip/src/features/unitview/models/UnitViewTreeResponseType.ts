
export type UnitViewTreeResponseType = {
  pcsDdataKey: number,
  rev: string,
  parent_Name: string,
  parent_Element: string,
  cM_Name: string,
  cM_Type: string,
  cM_Element: string,
  related_Tag: string,
  detailed_Description: string,
  tagID: number,
  tagorder: number,
  pcsdTable: string,
  tag_Name: string
}