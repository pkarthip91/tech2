export enum childViews {
  properties,
  logicview
}

export enum TreeNodeLevel {
  ROOT = 1,
  LEVEL_ONE,
  LEVEL_TWO,
  LEAF_NODE
}

export enum SecondLevelOrder {
  aqtk1,
  steps,
  setpoints,
  calcs,
  externalvar
}