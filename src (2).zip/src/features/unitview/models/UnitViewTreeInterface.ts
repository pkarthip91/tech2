import { AMLnodeTag } from "./UnitViewTreeModel";

export interface IUnitViewTreeModel {
  amlNodeTag: AMLnodeTag;
  getChildView(): IUnitViewTreeModel[];

  addChildView(child: IUnitViewTreeModel): void;
  getNodeText(): string;
  order: number;
  isPgGrp: boolean;
}