import { httpClient } from '../../../../app/api/middlewareSecurity'

export const cbmReadService = (userToken: string, libpath: string) => {
  return httpClient.get(`/CBM/diagram/${libpath}`, {
    headers: {
      "Authorization": `Bearer ${userToken}`
    }
  })
}