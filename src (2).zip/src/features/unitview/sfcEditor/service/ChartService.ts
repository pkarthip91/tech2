import { SfcDiagram } from "../sfcModels/sfcDiagram"

// export const prepareNodeData = (data: ) => {
//   let rootNode = { name: chartData.child?.name }

// }