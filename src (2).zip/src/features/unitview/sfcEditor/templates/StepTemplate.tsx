import { useState } from "react"
import { INodeStyleProps } from "../../../common/interface/INodeStyleProps"
import SvgText from "../../../common/yFiles/components/SvgTextComponent"
import { sfcColors, sfcText } from "./TemplateConstants"

export const StepTemplate = ({
  width,
  height,
  selected,
  tag
}: INodeStyleProps<{
  name: string
}>) => {
  const [textColor, setTextColor] = useState(sfcText.Foreground)
  const [nodeColor, setNodeColor] = useState(sfcColors.StepNode)
  const [initialStep, setInitialStep] = useState(true)
  const initialStepSize: number = 100
  return (
    <g>
      <rect
        onMouseEnter={(e) => { setNodeColor(sfcColors.MouseOverBackColor); setTextColor(sfcColors.MouseOverTextColor); }}
        onMouseLeave={(e) => { setNodeColor(sfcColors.StepNode); setTextColor(sfcText.Foreground); }}
        style={{
          stroke: sfcColors.Border,
          strokeWidth: '1.2',
          fill: nodeColor
        }}
        x={0}
        y={0}
        width={initialStep ? initialStepSize : width}
        height={height}
      />
      <SvgText
        fill={textColor}
        text={tag.name}
        font={`normal ${sfcText.FontSize} ${sfcText.FontFamily}`}
        maxWidth={width}
        maxHeight={height}
        x={initialStep ? initialStepSize / 2 : width / 2}
        y={14}
        style={{ textAnchor: 'middle', dominantBaseline: 'middle' }}
      />
    </g>
  )
}
