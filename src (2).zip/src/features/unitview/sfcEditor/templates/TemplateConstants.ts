export const sfcColors = {
  StepNode: "#D9D9D9",
  TransitionNode: "#0079B8",
  TransitionNodeBackground: "White",
  MouseOverBackColor: "#00AD56",
  LineColor: 'steelBlue',
  MouseOverTextColor: "White",
  Border: 'lightGrey'
}

export const sfcText = {
  Foreground: "Black",
  FontSize: "11.5px",
  FontFamily: "Microsoft Sans Serif"
}