import { useState } from "react"
import { INodeStyleProps } from "../../../common/interface/INodeStyleProps"
import SvgText from "../../../common/yFiles/components/SvgTextComponent"
import { sfcColors, sfcText } from "./TemplateConstants"

export const LeftArrowTemplate = ({
  width,
  height,
  selected,
  tag
}: INodeStyleProps<{
  name: string
}>) => {
  return (
    <g>
      <SvgText
        fill={sfcColors.LineColor}
        text={'^'}
        font={`normal 25px ${sfcText.FontFamily}`}
        style={{ textAnchor: 'middle', dominantBaseline: 'middle' }}
      />
    </g>
  )
}
