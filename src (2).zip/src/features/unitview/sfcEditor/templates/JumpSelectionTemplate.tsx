// import type { ReactComponentNodeStyleProps } from './ReactComponentNodeStyle'

import { INodeStyleProps } from "../../../common/interface/INodeStyleProps"
import SvgText from "../../../common/yFiles/components/SvgTextComponent"

export const StepTemplate = ({
  width,
  height,
  selected,
  tag
}: INodeStyleProps<{
  name: string
}>) => {
  return (
    <g>
      <rect
        style={{
          stroke: 'steelBlue',
          strokeWidth: '1.2',
          fill: 'lightgrey'
        }}
        x={0}
        y={0}
        width={width}
        height={height}
      />
      <SvgText
        text={tag.name}
        font="bold 13px sans-serif"
        maxWidth={width}
        maxHeight={height}
        x={width / 2}
        y={14}
        style={{ textAnchor: 'middle', dominantBaseline: 'middle' }}
      />
    </g>
  )
}
