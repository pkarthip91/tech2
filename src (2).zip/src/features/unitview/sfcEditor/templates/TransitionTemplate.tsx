import { useState } from "react"
import { INodeStyleProps } from "../../../common/interface/INodeStyleProps"
import SvgText from "../../../common/yFiles/components/SvgTextComponent"
import { sfcColors, sfcText } from "./TemplateConstants"



export const TransitionTemplate = ({
  width,
  height,
  selected,
  tag
}: INodeStyleProps<{
  name: string
}>) => {
  const [textColor, setTextColor] = useState(sfcText.Foreground)
  const [nodeColor, setNodeColor] = useState(sfcColors.TransitionNode)
  const [lineColor, setLineColor] = useState(sfcColors.LineColor)
  const [parentNodeColor, setParentNodeColor] = useState(sfcColors.TransitionNodeBackground)
  const [nodeWidth, setNodeWidth] = useState(78 + ((tag.name.length) * 7) + 7)
  return (
    <g>
      <rect
        onMouseEnter={(e) => {
          setParentNodeColor(sfcColors.MouseOverBackColor);
          setTextColor(sfcColors.MouseOverTextColor);
          setLineColor(sfcColors.TransitionNodeBackground);
          setNodeColor(sfcColors.TransitionNodeBackground)
        }}
        onMouseLeave={(e) => {
          setParentNodeColor(sfcColors.TransitionNodeBackground);
          setTextColor(sfcText.Foreground);
          setLineColor(sfcColors.LineColor);
          setNodeColor(sfcColors.TransitionNode)
        }}
        style={{ fill: parentNodeColor }}
        x={0}
        y={0}
        width={nodeWidth}
        height={height}
      />
      <rect
        style={{ strokeWidth: '1.2', fill: lineColor }}
        x={(width / 10) + ((width / 5) / 2) - 1}
        y={0}
        width={2}
        height={height}
      />
      <rect
        style={{ stroke: 'grey', strokeWidth: '1.2', fill: nodeColor }}
        x={22}
        y={height / 2 - (10) / 2}
        width={55}
        height={10}
      />
      <SvgText
        fill={textColor}
        text={tag.name}
        font={`normal ${sfcText.FontSize} ${sfcText.FontFamily}`}
        maxWidth={width}
        maxHeight={height}
        x={78}
        y={14}
        style={{ dominantBaseline: 'middle' }}
      />
    </g>
  )
}
