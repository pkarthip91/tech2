import { INodeStyleProps } from "../../../common/interface/INodeStyleProps"
import { sfcColors } from "./TemplateConstants"

export const SelectionTemplate = ({
  width,
  height,
  selected,
  tag
}: INodeStyleProps<{
  name: string
}>) => {
  return (
    <g>
      <rect
        style={{
          stroke: sfcColors.LineColor,
          strokeWidth: '1',
          fill: sfcColors.LineColor
        }}
        x={0}
        y={0}
        width={width}
        height={height}
      />
    </g>
  )
}
