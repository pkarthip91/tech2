import { SfcObject } from "./sfcObject";
import { IsfcJump } from "./sfcInterface";

export class SfcJump extends SfcObject implements IsfcJump {
    connectedStepId: string = '';
    stepName: string = '';
    jumpWidth: number = 0;
    type: string = 'SfcJump';
    connectToStep(stepId: string, stepName: string): void {
        this.connectedStepId = stepId;
        this.stepName = stepName;
    }

}