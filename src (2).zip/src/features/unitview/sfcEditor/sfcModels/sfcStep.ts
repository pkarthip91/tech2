import { IsfcJumpSelectionSequence, IsfcSelectionSequence, IsfcStep, IsfcSubSequence, IsfcTransition } from "./sfcInterface";
import { SfcObject } from "./sfcObject";

export class SfcStep extends SfcObject implements IsfcStep {

    connectedJumpIds: Array<string> = [];
    stepHeight: number = 0;
    stepWidth: number = 0;
    stepName: string = '';
    tagorder: number = 0;
    um_Exposed: string = '';
    ilockMOPAuto: string = '';
    assigned_Mode_of_Operation_Phase_Alias: string = '';
    ilockMOP: string = '';
    legacy_Tagname: string = '';
    em_Exposed: string = '';
    tagId: number = 0;
    related_Tag: string = '';
    comments: string = '';
    elements_Connections: string = '';
    application_Module_Link_AML_Status: string = '';
    aml_Comments: string = '';
    reference_Element_Tag_Name: string = '';
    reference_Element_Worksheet: string = '';
    genericTag: string = '';
    cm_Element: string = '';
    cm_Name: string = '';
    cm_Type: string = '';
    parent_Element: string = '';
    parent_Name: string = '';
    step_Code_for_P1_TAG_Link: string = '';
    step_Code_for_N_TAG_Link: string = '';
    step_Code_for_P0_TAG_Link: string = '';
    step_Code_for_P1: string = '';
    step_Code_for_N: string = '';
    step_Code_for_P0: string = '';
    assigned_Mode_of_Operation: string = '';
    mofO: string = '';
    hold_Allowed: string = '';
    step_Tag: string = '';
    description_Things_that_occur_in_this_Step: string = '';
    step_Number: string = '';
    tag_Abbrev: string = '';
    step_Description: string = '';
    rev: string = '';
    pcsdDataKey: string = '';
    type: string = 'SfcStep';


    attachObject(selectionSubSequence: any): boolean {
        return this.attachChild(selectionSubSequence);
    }

    connectJump(jumpId: string): void {
        this.connectedJumpIds.push(jumpId);
    }

}