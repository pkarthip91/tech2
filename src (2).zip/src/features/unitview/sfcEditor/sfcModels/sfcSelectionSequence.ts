import { SfcObject } from "./sfcObject";
import { IsfcBranch, IsfcSelectionSequence, IsfcStep } from './sfcInterface';
import { BranchPortPosition, SfcBranch } from "./sfcBranch";

export class SfcSelectionSequence extends SfcObject implements IsfcSelectionSequence {
    branches: Array<SfcBranch> = [];
    width: number = 0;
    type: string = 'SfcSelectionSequence';
    endBranchPosition: BranchPortPosition = new BranchPortPosition();
    attachObject(branch: IsfcBranch): boolean;
    attachObject(step: IsfcStep): boolean;
    attachObject(step: unknown): boolean {
        return this.attachChild(step);
    }

}