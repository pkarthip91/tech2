import { IsfcObject } from "./sfcInterface";

export abstract class SfcObject implements IsfcObject{
    constructor(){
        this.id = crypto.randomUUID();
        this.position = new ObjectPosition();
        this.isModified = false;        
    }
    id : string = '';
    position : ObjectPosition;
    isModified : boolean = false;
    name : string = '';
    description : string = '';
    parentId : string = '';
    child ? : any ;

    attachChild(child : any) : boolean{
        if(!child)
            return false;
        this.child = child;
        this.child.parentId = this.id;
        return true;
    }
}




export class ObjectPosition{
    constructor(public X ? : number, public Y ? : number ){
    }
}