import { SfcDiagram } from "./sfcDiagram";
import { SfcSelectionSequence } from "./sfcSelectionSequence";
import { SfcStep } from "./sfcStep";
import { BranchPortPosition, Port, SfcBranch } from "./sfcBranch";
import { SfcTransition } from "./sfcTransition";
import { SfcObject } from "./sfcObject";

export class SfcDummyDataGenerator{
    getData () : SfcDiagram  {
        let sfcDiagram = new SfcDiagram();
        sfcDiagram.unitName = 'Aqtk1';
        sfcDiagram.isStepSFC = false;
        sfcDiagram.isSFCDiagramModified = false;
        sfcDiagram.child=this.createRootSfcStep();

        return sfcDiagram;
    }

    createRootSfcStep(): SfcStep{
        let sfcStep = new SfcStep();
        sfcStep.name = 'sIdle';
        sfcStep.description = '___';
        sfcStep.stepName = 'sIdle';
        sfcStep.stepWidth = 250;
        sfcStep.stepHeight = 50;
        sfcStep.step_Description = 'sIdle';
        sfcStep.child = this.createFirstChild(sfcStep.id);
        return sfcStep;
    }
    createFirstChild(parentId: string): SfcSelectionSequence{
        let sfcSelectionSequence : SfcSelectionSequence = new SfcSelectionSequence();
        sfcSelectionSequence.parentId = parentId;
        sfcSelectionSequence.width = 1500;
        sfcSelectionSequence.branches.push(this.getFirstBranch());
        return sfcSelectionSequence;
    }
    getFirstBranch(): SfcBranch {
        let sfcBranch: SfcBranch = new SfcBranch();
        let sfcTransition: SfcTransition = new SfcTransition();
        sfcTransition.name = '1:OoS';
        sfcTransition.parentId = sfcBranch.id;
        sfcTransition.transitionName = '1:OoS';
        sfcTransition.transitionWidth = 250;
        sfcTransition.isMOPTransition = true;
        sfcTransition.IsProxyTransition = false;

        this.getFirstStepOfFirstBranch(sfcTransition);
        sfcBranch.child = sfcTransition;
        sfcBranch.branchPortPosition = new BranchPortPosition();
        sfcBranch.branchPortPosition.beginPort = new Port();
        sfcBranch.branchPortPosition.beginPort.left = 162;
        sfcBranch.branchPortPosition.beginPort.top = 5;
        sfcBranch.branchPortPosition = new BranchPortPosition();
        sfcBranch.branchPortPosition.endPort = new Port();
        sfcBranch.branchPortPosition.endPort.left = 162;
        sfcBranch.branchPortPosition.endPort.top = 5;
        return sfcBranch;
    }

    getFirstStepOfFirstBranch(sfcTransition1: SfcObject) : SfcStep{
        let sfcStep = new SfcStep();
        
        sfcStep.name = 'Aqtk1_OoS';
        sfcStep.description = 'Out of Service';
        sfcStep.stepName = 'Aqtk1_OoS';
        sfcStep.stepWidth = 250;
        sfcStep.stepHeight = 50;
        //create one more transition and set this as a child of create step
        let sfcTransition: SfcTransition = new SfcTransition();
        sfcTransition.name = 'Dummy';
        sfcTransition.transitionName = 'Dummy';
        sfcTransition.transitionWidth = 250;
        sfcTransition.isMOPTransition = true;
        sfcTransition.IsProxyTransition = false; 
        sfcTransition.originating_Step = 'OutOfService';      
        sfcTransition.parentId = sfcStep.id;
        sfcStep.child = sfcTransition;


        sfcTransition1.child = sfcStep;
        sfcStep.parentId = sfcTransition1.id;
        return sfcStep;
    }
}