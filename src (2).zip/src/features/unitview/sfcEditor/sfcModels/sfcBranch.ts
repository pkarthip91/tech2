import { IsfcBranch, IsfcConnectionPort, IsfcJumpSelectionSequence, IsfcSimultaneousSequence, IsfcStep, IsfcTransition } from "./sfcInterface";
import { SfcObject } from "./sfcObject";

export class SfcBranch extends SfcObject implements IsfcBranch {
    branchPortPosition: BranchPortPosition = new BranchPortPosition();
    type: string = 'SfcBranch';
    attachObject(step: IsfcStep): boolean;
    attachObject(stepTransition: IsfcTransition): boolean;
    attachObject(simultaneousSequence: IsfcSimultaneousSequence): boolean;
    attachObject(jumpSelectionSequence: IsfcJumpSelectionSequence): boolean;
    attachObject(child: unknown): boolean {
        if (!child)
            return false;
        this.attachChild(child);
        return true;
    }

}

export class BranchPortPosition {
    beginPort: Port = new Port();
    endPort: Port = new Port()
}

export class Port implements IsfcConnectionPort {
    left: number = 162;
    top: number = 5;
}