import { SfcObject } from "./sfcObject";
import { IsfcJump, IsfcSimultaneousSequence, IsfcStep, IsfcTransition } from './sfcInterface';
import { SfcJump } from "./sfcJump";

export class SfcTransition extends SfcObject implements IsfcTransition {
    transitionName: string = '';
    transitionWidth: number = 0;
    connectedJumps: SfcJump = new SfcJump();
    isSFCJumpTransition: boolean = false;
    ConnectedStepId: string = '';
    connectedStepName: string = '';
    isMOPTransition: boolean = false;
    IsProxyTransition: boolean = false;
    originating_Step: string = '';
    type: string = 'SfcTransition';
    attachObject(step: IsfcStep): boolean;
    attachObject(simultaneousSequence: IsfcSimultaneousSequence): boolean;
    attachObject(jump: IsfcJump): boolean;
    attachObject(jump: unknown): boolean {
        return this.attachChild(jump);
    }
}