export interface IsfcObject{

}

export interface IsfcDiagram{
    attachObject(subSequence: IsfcSubSequence) : boolean;
    attachObject(step : IsfcStep) : boolean;
    attachObject(simultaneousSequence : IsfcSimultaneousSequence) : boolean;
}

export interface IsfcConnectionPort{
    left : number;
    top : number;
}

export interface IsfcStep{
    connectedJumpIds : Array<string>;
    attachObject(transition : IsfcTransition) : boolean;
    attachObject(jumpSelectionSequence : IsfcJumpSelectionSequence) : boolean;    
    attachObject(selectionSequence : IsfcSelectionSequence) : boolean;
    attachObject(selectionSubSequence : IsfcSubSequence) : boolean;
    connectJump(jumpId : string) : void;
}

export interface IsfcTransition{
    attachObject(step : IsfcStep) : boolean;
    attachObject(simultaneousSequence : IsfcSimultaneousSequence) : boolean;
    attachObject(jump : IsfcJump) : boolean;
}

export interface IsfcJump{
    connectedStepId : string;
    stepName : string;
    connectToStep(stepId : string, stepName : string) : void;
}


export interface IsfcSubSequence{
    attachObject(step : IsfcStep) : boolean;
    attachObject(transition : IsfcTransition) : boolean;

}

export interface IsfcBranch{
    attachObject(step : IsfcStep) : boolean;
    attachObject(stepTransition : IsfcTransition) : boolean;
    attachObject(simultaneousSequence : IsfcSimultaneousSequence) : boolean;
    attachObject(jumpSelectionSequence : IsfcJumpSelectionSequence) : boolean;    
}

export interface IsfcSimultaneousSequence{
    branches : Array<IsfcBranch>;
    attachObject(branch : IsfcBranch) : boolean;
    attachObject(transition : IsfcTransition) : boolean;
    attachObject(jumpSelectionSequence : IsfcJumpSelectionSequence) : boolean;    
}

export interface IsfcJumpSelectionSequence{
    branches : Array<IsfcBranch>;
    attachObject(branch : IsfcBranch) : boolean;
    attachObject(step : IsfcStep) : boolean;
    attachObject(simultaneousSequence : IsfcSimultaneousSequence) : boolean;
}

export interface IsfcSelectionSequence{
    branches : Array<IsfcBranch>;
    attachObject(branch : IsfcBranch) : boolean;
    attachObject(step : IsfcStep) : boolean;
}