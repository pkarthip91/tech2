import { SfcObject } from "./sfcObject";

export class SfcDiagram{
    unitName: string = '';
    sfcDiagramId: string = '';
    child?: SfcObject;
    isStepSFC: boolean = false;
    isSFCDiagramModified: boolean = false;;
    attachObject(child: any): boolean{
        if(child){
            this.child=child;
            return true;
        }
        else{
            return false;
        }
    }

}