import { useAppSelector, useAppDispatch } from '../../../../app/hooks';
import { useEffect, useState } from "react"
import { SfcEditorDiagram } from './SfcEditorDiagram';


const styles = {
  model: {
    display: 'none',
    zIndex: 9999,
    left: 0,
    top: 0,
    paddingTop: '50px',
    width: '100%',
    height: '100%',
    backgroundColor: 'rgba(0, 0, 0, 0.4)'
  },
  modalContent: {
    backgroundColor: '#fefefe',
    width: '90%',
    height: '80%',
    margin: 'auto',
    padding: '20px',
    overflow: 'auto',
    border: '1px solid #888',
  },
  close: {
    color: '#aaaaaa',
    fontSize: '20px',
    fontWeight: 'bold',
    cursor: 'pointer'
  }
}
export const SfcEditor = (props: any) => {

  return (
    <>
      <div id="myModal" style={{ ...styles.model, position: 'fixed', display: props.isOpen ? 'block' : 'none' }}>
        <div style={{ ...styles.modalContent }}>
          <div style={{ 'display': 'grid' }}>
            <div style={{ 'width': '100%' }}>
              <span style={{ float: 'left' }}>CAFE SFC Editor</span>
              <span onClick={() => { props.close() }} style={{ ...styles.close, float: 'right' }}>&times;</span>
            </div>
            <div style={{ 'width': '100%', 'height': '30px', 'background': 'grey' }}>
              <span style={{ float: 'left' }}>TOOLBAR</span>
            </div>
            <div style={{ 'width': '100%', 'height': '100%', 'background': 'white' }}>
              <SfcEditorDiagram />
            </div>
          </div>
        </div>

      </div>
    </>
  )
}