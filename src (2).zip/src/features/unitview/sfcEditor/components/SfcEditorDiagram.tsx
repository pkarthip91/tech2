import '../styles/SfcEditorStyle.css'
import { useAppSelector, useAppDispatch } from '../../../../app/hooks';
import { createRef, useEffect, useState } from "react"

import { applyLicence } from '../../../common/yFiles/service/LicenceService';
import { clearGraphComponent, createGraphComponent, setGraphInputMode } from '../../../common/yFiles/service/GraphComponentService';
import { SfcDummyDataGenerator } from '../sfcModels/sfcDummyDataGenerator';
// import { drawChart } from '../service/ChartService';
import { createEdgeByNodes, createEdgeByPorts, createGraphNode } from '../../../common/yFiles/service/GraphNodeService';
import { StepTemplate } from '../templates/StepTemplate'
import { SfcDiagram } from '../sfcModels/sfcDiagram';
import { TransitionTemplate } from '../templates/TransitionTemplate';
import { SfcStep } from '../sfcModels/sfcStep';
import { Logger } from '../../../../app/common/LoggerService';
import { StepNodeUiService } from '../uiService/StepNodeUiService';
import { SfcTransition } from '../sfcModels/sfcTransition';
import { SfcSelectionSequence } from '../sfcModels/sfcSelectionSequence';
import { SfcJump } from '../sfcModels/sfcJump';
import { GraphComponent, IEdge, INode, Point, Rect } from 'yfiles';
import { LeftArrowTemplate } from '../templates/LeftArrowTemplate';

export const SfcEditorDiagram = (props: any) => {
  applyLicence()
  const [diagramDiv, setDiagramDiv] = useState(createRef<HTMLDivElement>())
  const [graphComponent, setGraphComponent] = useState(createGraphComponent())

  useEffect(() => {
    diagramDiv.current!.appendChild(graphComponent.div)
    clearGraphComponent(graphComponent)
    setGraphInputMode(graphComponent)
    drawChart(new SfcDummyDataGenerator().getData())
  }, [])

  const drawChart = (diagramData: any): void => {
    try {
      let rootNode: SfcStep = diagramData?.child
      if (rootNode) {
        let stepNode = new StepNodeUiService(graphComponent, rootNode)
        updatePosition(stepNode)
        let sPort = stepNode.graphNode?.ports.find(p => p.tag.name === 'topPort')
        let tPort = stepNode.loopHeadNode?.graphNode?.ports.find(p => p.tag.name === 'bottomPort')

        if (sPort && tPort) {
          let edge = createEdgeByPorts(graphComponent.graph, tPort, sPort)
          addCloseLoopConnection(edge, stepNode.loopHeadNode?.graphNode, stepNode.graphNode)
        }
      }
    }
    catch (error: any) { Logger.error('drawNode:', error) }
  }

  const updatePosition = (node: any) => {
    for (let i = 0; i < 5; i++) {
      try {
        node.updatePosition()
        node = node.child
      } catch { }
    }
  }
  const addCloseLoopConnection = (connection: IEdge, headNode: INode | null | undefined, tailNode: INode | null | undefined) => {
    let leftNode: INode | null | undefined = headNode;
    graphComponent.graph.nodes.forEach((item: INode) => {
      if (leftNode && item.layout.x < leftNode?.layout.x) {
        leftNode = item;
      }
    });

    let moveside = 17;
    let leftSpaceBetweenLine = 70;

    if (leftNode && headNode && tailNode) {
      let p = new Point(leftNode.layout.x - leftSpaceBetweenLine, headNode.layout.y);

      graphComponent.graph.addBend(connection, new Point(50 + 50, p.y + headNode.layout.height + 20.0));


      graphComponent.graph.addBend(connection, new Point(p.x - 5.0 + 50, p.y + headNode.layout.height + 20.0));

      p = new Point(leftNode.layout.x - leftSpaceBetweenLine, tailNode.layout.y);
      graphComponent.graph.addBend(connection, new Point(p.x - 5.0 + 50, p.y - moveside));

      createGraphNode(graphComponent.graph, LeftArrowTemplate, p.x - 5 + 50, ((headNode.layout.height + headNode.layout.y) / 2) - 6.25, 40, 40, null)

      //p = new Point(graphComponent.graph.boun Bounds.Right / 10, tailNode.layout.y);
      let pp = tailNode.ports.find(p => p.tag.name === 'topPort')
      if (pp)
        graphComponent.graph.addBend(connection, new Point(pp.location.x, p.y - moveside));

      // graphComponent.zoom = .3
    }

  }

  return (
    <>
      <div className='sfc-editor-diagram'>
        {/* {JSON.stringify(new SfcDummyDataGenerator().getData())} */}
        <div className='graph-component-container' ref={diagramDiv}></div>
      </div>
    </>
  )
}



