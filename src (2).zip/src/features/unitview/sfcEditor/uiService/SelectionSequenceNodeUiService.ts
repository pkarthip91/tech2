import { FreeNodePortLocationModel, GraphComponent, IEdge, INode, IPort, IPortLocationModelParameter, Point, Rect, Size } from "yfiles";
import { createEdgeByPorts, createGraphNode, createNodePort, createPortLocationparameter } from "../../../common/yFiles/service/GraphNodeService";
import { BranchPortPosition, SfcBranch } from "../sfcModels/sfcBranch";
import { SfcJump } from "../sfcModels/sfcJump";
import { SfcSelectionSequence } from "../sfcModels/sfcSelectionSequence";
import { SfcStep } from "../sfcModels/sfcStep";
import { SfcTransition } from "../sfcModels/sfcTransition";
import { SelectionTemplate } from "../templates/SelectionTemplate";
import { StepNodeUiService } from "./StepNodeUiService";
import { TransitionNodeUiService } from "./TransitionNodeUiService";

export class SelectionSequenceNodeUiService {

  public template: any = SelectionTemplate
  public tag: any = { name: '' }
  public offsetX: number = 0
  public offsetY: number = 0
  public width: number = 0
  public height: number = 0
  public borderWidth: number = 0

  private branchIndex: number = 0

  public graphNode: INode | null = null
  public topPort: IPort | null = null
  public bottomPort: IPort | null = null
  public loopHeadNode: SelectionSequenceNodeService | null = null

  public parent: any = null
  public child: any = null

  public branches: any = []

  constructor(
    private graphComponent: GraphComponent,
    private sfcSelection: SfcSelectionSequence) {

    this.offsetX = sfcSelection.position?.X || 0
    this.offsetY = sfcSelection.position?.Y || 0
    this.width = this.borderWidth = 0.01
    this.height = 2

    this.graphNode = this.createNode()

    if (this.graphNode) {
      this.topPort = this.createTopPort()
      this.bottomPort = this.createBottomPort()

      let endSelectionNode = new SelectionSequenceNodeService(graphComponent,
        this.width,
        this.height,
        sfcSelection.endBranchPosition
      )

      // endSelectionNode.startSelectionNode = this
      this.branchIndex = -1

      sfcSelection.branches.forEach((branch: SfcBranch) => {
        this.branchIndex++
        this.addBranch(branch)
        this.createEdge(this.child.graphNode.ports.find((pp: any) => pp.tag.name === 'bottomPort'),
          endSelectionNode.graphNode?.ports.find(p => p.tag.name === 'topPort'))
      })
      this.loopHeadNode = endSelectionNode
    }
  }

  public updatePosition() {
    if (this.parent instanceof StepNodeUiService || this.parent instanceof TransitionNodeUiService) {
      this.offsetX = this.parent.offsetX - (this.width / 2) + 50
      this.offsetY = this.parent.offsetY + this.parent.height + 20
      if (this.graphNode)
        this.graphComponent.graph.setNodeLayout(this.graphNode, new Rect(new Point(this.offsetX + 50, this.offsetY), new Size(this.width, this.height)))

      this.branches.forEach((branch: any) => {
        if (branch instanceof TransitionNodeUiService) {
          branch.offsetX = this.offsetX - 50
        }
        branch.offsetY = this.offsetY + 20
        if (branch.graphNode)
          this.graphComponent.graph.setNodeLayout(branch.graphNode, new Rect(new Point(branch.offsetX + 50, branch.offsetY), new Size(branch.width, branch.height)))
        if (this.loopHeadNode)
          this.loopHeadNode.offsetY = branch.offsetY + branch.height + 20
      })
      if (this.loopHeadNode)
        this.loopHeadNode.offsetX = this.offsetX
      if (this.loopHeadNode && this.loopHeadNode.graphNode) {

        this.graphComponent.graph.setNodeLayout(this.loopHeadNode.graphNode, new Rect(new Point(this.loopHeadNode.offsetX + 50, this.loopHeadNode.offsetY), new Size(this.loopHeadNode.width, this.loopHeadNode.height)))
      }

    }
  }

  private addBranch(branch: SfcBranch) {
    if (branch.child instanceof SfcTransition) {
      let transitionNode = new TransitionNodeUiService(this.graphComponent, branch.child)
      transitionNode.parent = this
      transitionNode.child = this.loopHeadNode //TO DO...
      this.child = transitionNode
      this.branches.push(transitionNode)
      this.createEdge(this.graphNode?.ports.find(p => p.tag.name === 'bottomPort'), transitionNode.graphNode?.ports.find(p => p.tag.name === 'topPort'))
    }
  }

  private createEdge = (sourcePort: IPort | null | undefined, targetPort: IPort | null | undefined): IEdge | undefined => {
    if (sourcePort && targetPort) {
      return createEdgeByPorts(
        this.graphComponent.graph,
        sourcePort,
        targetPort
      )
    }
  }

  private createNode = (): INode => {
    return createGraphNode(
      this.graphComponent.graph,
      this.template,
      this.offsetX,
      this.offsetY,
      this.width,
      this.height,
      this.tag
    )
  }

  private createTopPort = (): IPort => {
    return this.createPort(
      createPortLocationparameter(new Point(0, 0), new Point(this.width / 2, 0)), { name: 'topPort' }
    )
  }

  private createBottomPort = (): IPort => {
    return this.createPort(
      createPortLocationparameter(new Point(0, 0), new Point(this.width / 2, this.height)), { name: 'bottomPort' }
    )
  }

  private createPort = (locationParameter: IPortLocationModelParameter, tag?: any): IPort => {
    return createNodePort(
      this.graphComponent.graph,
      this.graphNode!,
      locationParameter,
      tag
    )
  }
}

export class SelectionSequenceNodeService {

  public template: any = SelectionTemplate

  public startSelectionNode: SelectionSequenceNodeUiService | null = null
  public tag: any = { name: '' }
  public offsetX: number = 0
  public offsetY: number = 0
  public borderWidth: number = 0

  public graphNode: INode | null = null
  public topPort: IPort | null = null
  public bottomPort: IPort | null = null

  public parent: any = null
  public child: any = null

  constructor(
    private graphComponent: GraphComponent,
    public width: number,
    public height: number,
    branchPortPosition: BranchPortPosition
  ) {
    this.offsetX = branchPortPosition.endPort.left || 0
    this.offsetY = branchPortPosition.endPort.top || 0
    this.width = 0.01
    this.height = 2

    this.graphNode = this.createNode()
    if (this.graphNode) {
      this.topPort = this.createTopPort()
      this.bottomPort = this.createBottomPort()
      // if (sfcStep.child) {
      //   if (sfcStep.child instanceof SfcTransition) {

      //   } else if (sfcStep.child instanceof SfcSelectionSequence) {

      //   } if (sfcStep.child instanceof SfcJump) {

      //   }
      // }
    }
  }

  private createNode = (): INode => {
    return createGraphNode(
      this.graphComponent.graph,
      this.template,
      this.offsetX,
      this.offsetY,
      this.width,
      this.height,
      this.tag
    )
  }

  private createTopPort = (): IPort => {
    return this.createPort(
      createPortLocationparameter(new Point(0, 0), new Point(this.width / 2, 0)), { name: 'topPort' }
    )
  }

  private createBottomPort = (): IPort => {
    return this.createPort(
      createPortLocationparameter(new Point(0, 0), new Point(this.width / 2, this.height)), { name: 'bottomPort' }
    )
  }

  private createPort = (locationParameter: IPortLocationModelParameter, tag?: any): IPort => {
    return createNodePort(
      this.graphComponent.graph,
      this.graphNode!,
      locationParameter,
      tag
    )
  }
}