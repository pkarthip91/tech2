import { CreateEdgeInputMode, FreeNodePortLocationModel, GraphComponent, IEdge, INode, IPort, IPortLocationModelParameter, Point } from "yfiles";
import { createEdgeByPorts, createGraphNode, createNodePort, createPortLocationparameter } from "../../../common/yFiles/service/GraphNodeService";
import { SfcJump } from "../sfcModels/sfcJump";
import { SfcSelectionSequence } from "../sfcModels/sfcSelectionSequence";
import { SfcStep } from "../sfcModels/sfcStep";
import { SfcTransition } from "../sfcModels/sfcTransition";
import { StepTemplate } from "../templates/StepTemplate";
import { TransitionTemplate } from "../templates/TransitionTemplate";
import { SelectionSequenceNodeUiService } from "./SelectionSequenceNodeUiService";

export class TransitionNodeUiService {

  public template: any = TransitionTemplate
  public tag: any = { name: '' }
  public offsetX: number = 0
  public offsetY: number = 0
  public width: number = 0
  public height: number = 50

  public graphNode: INode | null = null
  public topPort: IPort | null = null
  public bottomPort: IPort | null = null

  public parent: any = null
  public child: any = null

  constructor(
    private graphComponent: GraphComponent,
    private sfcTransition: SfcTransition) {

    this.offsetX = sfcTransition.position?.X || 0
    this.offsetY = sfcTransition.position?.Y || 0
    this.width = sfcTransition.transitionWidth || 0
    this.height = 50

    this.tag.name = sfcTransition.transitionName

    this.graphNode = this.createNode()
    if (this.graphNode) {
      this.topPort = this.createTopPort()
      this.bottomPort = this.createBottomPort()

      // if (!sfcTransition.child) {
      //   this.createEdge(this.node.ports.find(p => p.tag.name === 'bottomPort'), parentNode.ports.find(p => p.tag.name === 'bottomPort'))
      // }
    }
  }

  private createEdge = (sourcePort: IPort | null, targetPort: IPort | null): IEdge | undefined => {
    if (sourcePort && targetPort) {
      return createEdgeByPorts(
        this.graphComponent.graph,
        sourcePort,
        targetPort
      )
    }
  }
  private createNode = (): INode => {
    return createGraphNode(
      this.graphComponent.graph,
      this.template,
      this.offsetX,
      this.offsetY,
      this.width,
      this.height,
      this.tag
    )
  }

  private createTopPort = (): IPort => {
    return this.createPort(
      createPortLocationparameter(new Point(0, 0), new Point(50, 0)), { name: 'topPort' }
    )
  }

  private createBottomPort = (): IPort => {
    return this.createPort(
      createPortLocationparameter(new Point(0, 0), new Point(50, this.height)), { name: 'bottomPort' }
    )
  }

  private createPort = (locationParameter: IPortLocationModelParameter, tag?: any): IPort => {
    return createNodePort(
      this.graphComponent.graph,
      this.graphNode!,
      locationParameter,
      tag
    )
  }


}