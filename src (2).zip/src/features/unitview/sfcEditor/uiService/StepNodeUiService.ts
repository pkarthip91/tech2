import { CreateEdgeInputMode, FreeNodePortLocationModel, GraphComponent, IEdge, INode, IPort, IPortLocationModelParameter, Point, Rect, Size } from "yfiles";
import { createEdgeByPorts, createGraphNode, createNodePort, createPortLocationparameter } from "../../../common/yFiles/service/GraphNodeService";
import { SfcJump } from "../sfcModels/sfcJump";
import { SfcSelectionSequence } from "../sfcModels/sfcSelectionSequence";
import { SfcStep } from "../sfcModels/sfcStep";
import { SfcTransition } from "../sfcModels/sfcTransition";
import { StepTemplate } from "../templates/StepTemplate";
import { SelectionSequenceNodeService, SelectionSequenceNodeUiService } from "./SelectionSequenceNodeUiService";

export class StepNodeUiService {

  public template: any = StepTemplate
  public tag: any = { name: '' }
  public offsetX: number = 0
  public offsetY: number = 0
  public width: number = 0
  public height: number = 0

  public graphNode: INode | null = null
  public topPort: IPort | null = null
  public bottomPort: IPort | null = null
  public loopHeadNode: SelectionSequenceNodeService | null = null

  public parent: any = null
  public child: any = null

  constructor(
    private graphComponent: GraphComponent,
    private sfcStep: SfcStep) {

    this.offsetX = sfcStep.position?.X || 0
    this.offsetY = sfcStep.position?.Y || 0
    this.width = sfcStep.stepWidth || 0
    this.height = sfcStep.stepHeight || 0
    this.tag.name = sfcStep.stepName

    this.graphNode = this.createNode()
    if (this.graphNode) {
      this.topPort = this.createTopPort()
      this.bottomPort = this.createBottomPort()

      if (sfcStep.child) {
        if (sfcStep.child instanceof SfcTransition) {

        } else if (sfcStep.child instanceof SfcSelectionSequence) {

          let selectionSequenceNode = new SelectionSequenceNodeUiService(graphComponent, sfcStep.child)
          selectionSequenceNode.parent = this
          this.child = selectionSequenceNode
          this.createEdge(
            this.graphNode.ports.find(p => p.tag.name === 'bottomPort'),
            selectionSequenceNode?.graphNode?.ports.find(p => p.tag.name === 'topPort'))
          this.loopHeadNode = selectionSequenceNode.loopHeadNode

        } else if (sfcStep.child instanceof SfcJump) {

        }
      }

      this.updatePosition()
    }
  }

  public updatePosition() {
    this.offsetY = 20
    if (this.graphNode)
      this.graphComponent.graph.setNodeLayout(this.graphNode, new Rect(new Point(this.offsetX + 50, this.offsetY), new Size(this.width, this.height)))
  }


  private createEdge = (sourcePort: IPort | null, targetPort: IPort | null | undefined): IEdge | undefined => {
    if (sourcePort && targetPort) {
      return createEdgeByPorts(
        this.graphComponent.graph,
        sourcePort,
        targetPort
      )
    }
  }

  private createNode = (): INode => {
    return createGraphNode(
      this.graphComponent.graph,
      this.template,
      this.offsetX,
      this.offsetY,
      this.width,
      this.height,
      this.tag
    )
  }

  private createTopPort = (): IPort => {
    return this.createPort(
      createPortLocationparameter(new Point(0, 0), new Point(50, 0)), { name: 'topPort' }
    )
  }

  private createBottomPort = (): IPort => {
    return this.createPort(
      createPortLocationparameter(new Point(0, 0), new Point(50, this.height)), { name: 'bottomPort' }
    )
  }

  private createPort = (locationParameter: IPortLocationModelParameter, tag?: any): IPort => {
    return createNodePort(
      this.graphComponent.graph,
      this.graphNode!,
      locationParameter,
      tag
    )
  }


}