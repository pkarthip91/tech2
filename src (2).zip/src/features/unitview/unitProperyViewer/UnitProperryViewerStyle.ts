import CSS from 'csstype';
import { FontWeight } from 'yfiles/*';

export const row: CSS.Properties = {
  width: '100%',
  display: '-webkit-box',
  border: '1px solid grey',
  fontSize: '12px'
}

export const header: CSS.Properties = {
  backgroundColor: 'darkgray',
  fontWeight: 'bold'
}

export const column: CSS.Properties = {
  border: '1px solid lightgrey'
}