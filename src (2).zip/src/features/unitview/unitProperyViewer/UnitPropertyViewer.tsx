import { useState } from "react"
import { useAppDispatch, useAppSelector } from "../../../app/hooks"
import { unitViewParameterSaveAction } from "../actions/UnitViewPrameterSaveActions"
import { IUnitViewTreeModel } from "../models/UnitViewTreeInterface"
import { column, header, row } from "./UnitProperryViewerStyle"
import { UnitPropertyModel } from "./UnitPropertyModel"
import React from "react";
import {
  Table,
} from '@abb/abb-common-ux-react';
import CheckCircel from '../../../assest/img/unity/content/check-circel.svg';

export const UnitPropertyViewer = (props: any) => {
  const [modelOpen, setModelOpen] = useState(false)
  const [selectedProperty, setSelectedProperty] = useState({})
  const selectedSubTree: IUnitViewTreeModel = props.selectedSubTree
  const { unitPcsdData, error } = useAppSelector((state: any) => state.unitviewPCSDdata)
  const { userToken } = useAppSelector((state: any) => state.auth)
  const dispatch = useAppDispatch();
  if (error) { alert(error) }
  let propertiesData: { key: string, value: string }[] = []
  if (selectedSubTree && !selectedSubTree.getChildView().length) {
    if (unitPcsdData && Array.isArray(unitPcsdData)) {
      try {
        let tabName = selectedSubTree.amlNodeTag.pcsdTable
        let tagName = selectedSubTree.amlNodeTag.tagName
        if (tabName && tagName) {
          unitPcsdData.filter(tbl =>
            (tbl.key.toLowerCase() === tabName.toLowerCase()) ||
            (tbl.key.toLowerCase() === tabName.toLowerCase().split('_fe')[0]))
            .map(tbl => tbl.value.filter((tag: any) => tag.key.toLowerCase() === tagName.toLowerCase())
              .map((p: any) => p.value.map((m: any) => propertiesData.push({ key: m.key, value: m.value }))))
        }
      } catch {
        propertiesData = []
      }
    }
  }

  const handleDoubleClick = (propertyData: { key: string, value: string }) => {
    setSelectedProperty(propertyData)
    if (!modelOpen)
      setModelOpen(true)
  }

  return (
    <>
      <div>
        <>
        <div className="margins borders padding">
        <div style={{height: '100%', overflow: 'auto', background: 'inherit'}}>
        <Table>
      <thead>
        <tr>
          <th className="status-title">Status</th>
          <th>Parameter Name</th>
          <th className="value-titile">Parameter Value</th>
        </tr>
      </thead>
      <tbody className="unity-table-body">
      {(propertiesData && propertiesData.length) ? propertiesData.map((p, i) =>
        <tr key={i} onDoubleClick={() => handleDoubleClick(p)}>
          <><td className="status-check"><img className="check-circel-img" src={CheckCircel} /></td>
          <td>{p.key}</td>
          <td className="value-status">{p.value}</td></>
        </tr>
         ) : <p className="no-properites">No properties available for selected node!</p>}
      </tbody>
    </Table>
    </div>
    </div>

          {/* <div className="margins borders padding">
            <div style={{ ...column, width: '5%' }}></div>
            <div style={{ ...column, width: '30%' }}>Parameter Name</div>
            <div style={{ ...column, width: '65%' }}>Parameter Value</div>
          </div>
          <div style={{ 'overflow': 'auto', 'height': '400px' }}>
            {(propertiesData && propertiesData.length) ? propertiesData.map((p, i) =>
              <div style={{ ...row }} key={i} onDoubleClick={() => handleDoubleClick(p)}>
                <div style={{ ...column, width: '5%' }}></div>
                <div style={{ ...column, width: '30%' }}>{p.key}</div>
                <div style={{ ...column, width: '65%' }}>{p.value}</div>
              </div>
            ) : "No properties available for selected node!"}
          </div> */}
          <UnitPropertyModel save={(key: string, value: string) => {
            dispatch(unitViewParameterSaveAction({
              userToken: userToken,
              tableName: selectedSubTree.amlNodeTag.pcsdTable.includes('_FE') ?
                selectedSubTree.amlNodeTag.pcsdTable.split('_FE')[0] : selectedSubTree.amlNodeTag.pcsdTable,
              tagName: selectedSubTree.amlNodeTag.tagName,
              pcsdKey: selectedSubTree.amlNodeTag.pcsdKey,
              key: key,
              value: value
            }));
            setModelOpen(false)
          }} close={() => setModelOpen(false)} isOpen={modelOpen} property={selectedProperty} />
        </>
      </div>
    </>
  )
}