import { useEffect, useState } from "react"


const styles = {
  model: {
    display: 'none',
    zIndex: 1,
    paddingTop: '100px',
    left: 0,
    top: 0,
    width: '100%',
    height: '100%',
    overflow: 'auto',
    backgroundColor: 'rgba(0, 0, 0, 0.4)'
  },
  modalContent: {
    backgroundColor: '#fefefe',
    margin: 'auto',
    padding: '20px',
    border: '1px solid #888',
    width: '50%'
  },
  close: {
    color: '#aaaaaa',
    fontSize: '28px',
    fontWeight: 'bold'
  }
}
export const UnitPropertyModel = (props: any) => {

  const [value, setValue] = useState(props.property.value)
  useEffect(() => setValue(props.property.value), [props.property.value])
  const handleChange = (event: any) => {
    setValue(event.target.value);
  }
  return (
    <>
      <div id="myModal" style={{ ...styles.model, position: 'fixed', display: props.isOpen ? 'block' : 'none' }}>
        <div style={{ ...styles.modalContent }}>
          <span onClick={() => { props.close() }} style={{ ...styles.close, float: 'right' }}>&times;</span>
          <p>{`Enter new Parameter Value For '${props.property.key}'`}</p>
          <textarea style={{ 'width': '90%' }} value={value} onChange={handleChange} />
          <div style={{ 'display': 'inline-block' }}>
            <button onClick={() => { props.save(props.property.key, value) }}>OK</button>
            <button onClick={() => { props.close() }}>Cancel</button>
          </div>
        </div>

      </div>
    </>
  )
}