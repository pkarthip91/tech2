import React from 'react';
import Navbar from './Navbar';
import {
  WithDialog,
  Button,
  Dialog
} from '@abb/abb-common-ux-react';


const Header = () => {
  return (
    <header>
      <div className="nav-area">
        <Navbar/>
      </div>

    </header>
  );
};

export default Header;