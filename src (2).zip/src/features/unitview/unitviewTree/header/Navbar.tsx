import {menuItems} from "./Menuitemsdata";
import MenuItems from "./Menuitems";
import React from "react";
const Navbar = () => {
  return (
  <nav>
      <ul className = "menus" > {
          menuItems.map((menu, index) => {
              const depthLevel = 0;
              return <MenuItems items = {
                  menu
              }
              key = {index}
              depthLevel = {depthLevel}
              />;
          })
      }
      </ul>
      </nav>

  );

};



export default Navbar;