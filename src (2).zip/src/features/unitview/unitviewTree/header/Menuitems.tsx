import React from "react";
import { useState, useEffect, useRef } from "react";
// Add menu
import plusadd from '../../../../assest/img/unity/plus-add.svg';
import EMAddCm from '../../../../assest/img/unity/EMAddCm.svg';
import CMT from '../../../../assest/img/unity/CMT.svg';
import EMAddEM from '../../../../assest/img/unity/EMAddEM.svg';
import pageGroup from '../../../../assest/img/unity/page-group.svg';

// Edit
import Edit from '../../../../assest/img/unity/edit.svg';
import Findreplace from '../../../../assest/img/unity/find-replace.svg';
import EMEditObjectTag from '../../../../assest/img/unity/EMEditObjectTag.svg';
import EMShowVirtualTags from '../../../../assest/img/unity/EMShowVirtualTags.svg';
import EMDeleteObjectTag from '../../../../assest/img/unity/EMDeleteObjectTag.svg';

// Update
import Reset from '../../../../assest/img/unity/reset.svg';
import EMUpdateStCode from '../../../../assest/img/unity/EMUpdateStCode.svg';
import EMUpdateDefault from '../../../../assest/img/unity/EMUpdateDefault.svg';
import plusaddUpdate from '../../../../assest/img/unity/plus-add.svg';
import localST from '../../../../assest/img/unity/localST.svg';

// 800xA Import
import Transfrom from '../../../../assest/img/unity/ImportXA.svg';
import Import_800xA from '../../../../assest/img/unity/Import_800xA.svg';
import ObjectConfig from '../../../../assest/img/unity/object-config.svg';
import Export_Diff_Report from '../../../../assest/img/unity/Export_Diff_Report.svg';
import External_Variable from '../../../../assest/img/unity/External_Variable.svg';


import Dropdown from "./Dropdown";
const MenuItems = ({ items, depthLevel }: any) => {
  const getIcon = (iconName: string) => {
    let icon: any
    switch (iconName) {
      // Add
      case 'plus-add.svg': { icon = plusadd; break; }
      case 'EMAddCm.svg': { icon = EMAddCm; break; }
      case 'CMT.svg': { icon = CMT; break; }
      case 'EMAddEM.svg': { icon = EMAddEM; break; }
      case 'page-group.svg': { icon = pageGroup; break; }

      // Edit
      case 'edit.svg': { icon = Edit; break; }
      case 'find-replace.svg': { icon = Findreplace; break; }
      case 'EMEditObjectTag.svg': { icon = EMEditObjectTag; break; }
      case 'EMShowVirtualTags.svg': { icon = EMShowVirtualTags; break; }
      case 'EMDeleteObjectTag.svg': { icon = EMDeleteObjectTag; break; }

      //Update
      case 'reset.svg': { icon = Reset; break; }
      case 'EMUpdateStCode.svg': { icon = EMUpdateStCode; break; }
      case 'EMUpdateDefault.svg': { icon = EMUpdateDefault; break; }
      case 'plus-add.svg': { icon = plusaddUpdate; break; }
      case 'localST.svg': { icon = localST; break; }


      //800xA Import
      case 'ImportXA.svg': { icon = Transfrom; break; }
      case 'Import_800xA.svg': { icon = Import_800xA; break; }
      case 'object-config.svg': { icon = ObjectConfig; break; }

    }
    return icon
  }
  const [dropdown, setDropdown] = useState(false);
  let refli: React.RefObject<HTMLLIElement> = React.createRef<HTMLLIElement>();
  useEffect(() => {
    const handler = (event: any) => {
      if (dropdown && refli.current && !refli.current.contains(event.target)) {
        setDropdown(false);
      }
    };

    document.addEventListener("mousedown", handler);
    document.addEventListener("touchstart", handler);
    return () => {

      // Cleanup the event listener

      document.removeEventListener("mousedown", handler);
      document.removeEventListener("touchstart", handler);
    };

  }, [dropdown]);

  const onMouseEnter = () => {
    window.innerWidth > 960 && setDropdown(true);
  };

  const onMouseLeave = () => {
    window.innerWidth > 960 && setDropdown(false);
  };

  return (
    <li className="menu-items" ref={refli} onMouseEnter={onMouseEnter} onMouseLeave={onMouseLeave} >
      {
        items.submenu ? (
          <div className={items.class + " main-submenu"}>
            <button type="button" className="menu-radius" aria-haspopup="menu" aria-expanded={dropdown ? "true" : "false"
            }
              onClick={() => setDropdown((prev) => !prev)}>
              {getIcon(items.icon) && <span className="icon-14 menu-icons">
                <img src={getIcon(items.icon)} className="fetoolImg" alt="FETool" />
              </span>
              } {items.title} {""} {depthLevel > 0 ? <span className="right-arrow"></span> : <span className="arrow" />}
            </button>
            <Dropdown depthLevel={
              depthLevel
            }
              submenus={
                items.submenu
              }
              dropdown={dropdown} />
          </div>
        ) : (<a href="/#" >{getIcon(items.icon) && <span className="icon-14  menu-icons">
          <img src={getIcon(items.icon)} className="fetoolImg" alt="FETool" />
        </span>
        }{items.title} </a>)

      } </li>);
};
export default MenuItems;