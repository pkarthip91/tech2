export const menuItems = [
    // Add menu
    {
      icon : 'plus-add.svg',
      title: 'Add',
      url: '/',
      submenu: [
        {
          icon : 'EMAddCm.svg',
          title: 'CM',
        },
        {
          icon : 'CMT.svg',
          title: 'CMT',
          url: '/',
        },
        {
          icon : 'EMAddEM.svg',
          title: 'EM',
          url: '/',
        },
        {
          icon : 'page-group.svg',
          title: 'Page Group',
          url: '/',
        },
      ],
    },
    // Add Menu End

 // Edit
    {
      icon : 'edit.svg',
      title: 'Edit',
      url: '/',
      submenu: [
        {
          icon : 'find-replace.svg',
          title: 'Find & Replace',
        },
        {
          icon : 'EMEditObjectTag.svg',
          title: 'Edit Object/ Tag',
          url: '/',
        },
        {
          icon : 'EMShowVirtualTags.svg',
          title: 'Show Virtual Tag',
          url: '/',
        },

        {
          icon : 'EMDeleteObjectTag.svg',
          title: 'Delete  Object/ Tag',
          url: '/',
        },
      ],
    },
    // Edit Menu End

    // Update Menu
    {
      icon : 'reset.svg',
      title: 'Update',
      url: '/',
      submenu: [
        {
          icon : 'EMUpdateStCode.svg',
          title: 'Update ST Code',
        },
        {
          icon : 'EMUpdateDefault.svg',
          title: 'Update to Defaults',
          url: '/',
        },
        {
          icon : 'plus-add.svg',
          title: 'Create Required Tags',
          url: '/',
        },
        {
          icon : 'localST.svg',
          title: 'Local ST',
          url: '/',
        },
      ],
    },
    // Bulk Edit Menu End

     // 800xA Import Menu
     {
      icon : 'ImportXA.svg',
      title: '800xA Import',
      url: '/',
      submenu: [
        {
          icon : 'Import_800xA.svg',
          title: 'Import to 800xA',
        },
        {
          icon : 'object-config.svg',
          title: 'Object Configuration',
          url: '/',
        },
      ],
    },
  ];