import React from "react";
import { IUnitViewTreeModel } from "../models/UnitViewTreeInterface";
import { nodeOpen, nodeClose, nodeHeader, nodeTitle, nodeFields, nodeFieldFilePath } from "../styles/UnitViewStyle";

import TriangleBlack from '../../../assest/img/unity/content/triangle-black.svg';
import CheckCircel from '../../../assest/img/unity/content/check-circel.svg';
import CheckCircelRed from '../../../assest/img/unity/content/check-circel-red.svg';

export const NodeHeader = (props: any) => {
  const node: IUnitViewTreeModel = props.node;
  const isOpen: boolean = props.isOpen;
  const onToggle: any = props.onToggle;

  return (
    <>
      <div className={isOpen ? "nodeHeader active" : "nodeHeader"} style={nodeHeader}
        onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#ebebeb'}
        onMouseLeave={(e) => e.currentTarget.style.backgroundColor = 'transparent'}>
        {node.getChildView().length > 0 ?

          <div className="p-left-20"  onDoubleClick={onToggle} onClick={() => props.onClick(node)}>
            <span className={isOpen ? "nodeOpen" : "nodeClose"} onClick={onToggle}></span>
            <span className="unity-list-icons"><img src={TriangleBlack} alt="TriangleBlack"  /></span>
            <span>{
              (node.getNodeText())
            }</span>
          </div> :
          <div className="tableSection1" onClick={() => props.onClick(node)}>
            <span className="unity-list-icons"><img src={CheckCircelRed} alt="TriangleBlack"  /></span>
            <span>{node.getNodeText()}</span>
          </div>
        }
      </div>
    </>
  );
}