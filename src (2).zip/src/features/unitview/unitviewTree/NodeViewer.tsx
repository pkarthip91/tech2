import { useState } from 'react';
import { NodeHeader } from './NodeHeader';
import { nodeChild, nodeViewer } from '../styles/UnitViewStyle';
import { IUnitViewTreeModel } from '../models/UnitViewTreeInterface';
import React from 'react';

export const NodeViewer = (props: any) => {
  const node: IUnitViewTreeModel = props.node;
  const [isOpen, setIsOpen] = useState(false);

  const onToggle = () => {
    setIsOpen(!isOpen);
  }

  return (
    <>
      <div className='nodeViewer'>
        <NodeHeader className='table-section_main' node={node} isOpen={isOpen} onToggle={onToggle} onClick={props.onClick} />
        <div className='node-full-hover'>
        {
          isOpen && node.getChildView().length > 0 &&
          <div className='table-section'>
            <div className='Collapsible-hasChildren'>
            {node.getChildView().map((child: IUnitViewTreeModel, i: number) => (
              <NodeViewer key={i} node={child} onClick={props.onClick} />
            ))}
            </div>
          </div>
        }
      </div>
      </div>
    </>
  );
}