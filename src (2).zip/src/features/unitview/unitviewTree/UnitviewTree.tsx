import React from 'react';
import { IUnitViewTreeModel } from '../models/UnitViewTreeInterface';
import { NodeViewer } from './NodeViewer';

export const UnitViewTree = (props: any) => {

  const treeData: IUnitViewTreeModel = props.treeData
  return (
    <div className='nodeMain-row'>
      <NodeViewer node={treeData} onClick={props.onClick} />
    </div>
  );
}
