import { createAsyncThunk } from "@reduxjs/toolkit";
import { Logger } from "../../../app/common/LoggerService";
import { UNIT_VIEW_PCSD_DATA_SAVE_ACTION, UNIT_VIEW_PCSD_DATA_SAVE_ACTION_FAIL, UNIT_VIEW_REDUCER } from "../UnitViewConstant";
import { unitViewParameterSaveService } from "../service/UnitViewApiService";

export const unitViewParameterSaveAction = createAsyncThunk(
  `${UNIT_VIEW_REDUCER}/${UNIT_VIEW_PCSD_DATA_SAVE_ACTION}`,
  async ({ userToken, tableName, tagName, pcsdKey, key, value }: any, { rejectWithValue }: any) => {
    let result = null
    // return { tableName, tagName, pcsdKey, key, value }
    try {
      const response = await unitViewParameterSaveService(userToken, tableName, tagName, +pcsdKey, key, value)
      if (response.status === 200 && response.data) {
        try {
          Logger.info(UNIT_VIEW_PCSD_DATA_SAVE_ACTION, response)
          result = { tableName, tagName, pcsdKey, key, value }
        } catch (error: any) {
          Logger.error(UNIT_VIEW_PCSD_DATA_SAVE_ACTION_FAIL, error)
          result = rejectWithValue(UNIT_VIEW_PCSD_DATA_SAVE_ACTION_FAIL)
        }
      } else {
        result = rejectWithValue(UNIT_VIEW_PCSD_DATA_SAVE_ACTION_FAIL)
      }
    } catch (error: any) {
      Logger.error(UNIT_VIEW_PCSD_DATA_SAVE_ACTION_FAIL, error)
      if (error.response.data || error.message) {
        result = rejectWithValue(error.response.data || error.message)
      } else {
        result = rejectWithValue(UNIT_VIEW_PCSD_DATA_SAVE_ACTION_FAIL)
      }
    }
    return result
  }
)
