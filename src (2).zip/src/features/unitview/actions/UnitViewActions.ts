import { createAsyncThunk } from "@reduxjs/toolkit";
import { Logger } from "../../../app/common/LoggerService";
import { UnitViewTreeResponseType } from "../models/UnitViewTreeResponseType";
import { UNIT_VIEW_DATA_ACTION, UNIT_VIEW_DATA_ACTION_FAIL, UNIT_VIEW_REDUCER } from "../UnitViewConstant";
import { unitViewTreeDataService } from "../service/UnitViewApiService";
import { mapUnitViewTreeResponseData } from "../service/UnitViewHelperService";

export const unitViewTreeDataAction = createAsyncThunk(
  `${UNIT_VIEW_REDUCER}/${UNIT_VIEW_DATA_ACTION}`,
  async ({ userToken, unitId, unitName }: any, { rejectWithValue }: any) => {
    let result = null
    try {
      const response = await unitViewTreeDataService(userToken, unitId)
      if (response.status === 200 && response.data) {
        try {
          const unitViewResponseData: UnitViewTreeResponseType[] = response.data
          result = unitViewResponseData.length > 0 ?
            mapUnitViewTreeResponseData(unitName, unitViewResponseData) :
            []
        } catch (error: any) {
          Logger.error(UNIT_VIEW_DATA_ACTION, error)
          result = rejectWithValue(UNIT_VIEW_DATA_ACTION_FAIL)
        }
      } else {
        result = rejectWithValue(UNIT_VIEW_DATA_ACTION_FAIL)
      }
    } catch (error: any) {
      Logger.error(UNIT_VIEW_DATA_ACTION_FAIL, error)
      if (error.response.data || error.message) {
        result = rejectWithValue(error.response.data || error.message)
      } else {
        result = rejectWithValue(UNIT_VIEW_DATA_ACTION_FAIL)
      }
    }
    return result
  }
)
