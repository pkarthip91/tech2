export interface IHistory {
  confirmationMessage: string | null,
  pcsdDataKey: number,
  pcsdDataKey_SIM: number,
  reservedBy: string | null
}

export interface IImportXMLHistoryState {
  historyLoading: boolean | null,
  historyData: IHistory | null,
  historyError: string | null
}

export interface IHistoryDelete {
  deleted: boolean
}

export interface IImportXMLHistoryDeleteState {
  historyDeleteLoading: boolean | null,
  historyDeleteData: IHistoryDelete | null
  historyDeleteError: string | null
}

export interface IXmlInsert {
  confirmationMessage: string | null,
  pcsdDataKey: number,
  simDataKey: number,
  sisDataKey: number
}

export interface IImportXMLInsertState {
  xmlInsertLoading: boolean | null,
  xmlInsertData: IXmlInsert | null,
  xmlInsertError: string | null
}

export interface IImportXMLInsertRequst {
  plantName: string,
  areaName: string,
  cellName: string,
  unitName: string,
  unitDesc: string,
  unitDescALL: string,
  multiuse: boolean,
  template: string,
  designerName: string,
  unitStatus: string,
  revNumber: string,
  revComment: string,
  tagNamePrefix: string,
  fileName: string
}