import { ChangeEvent, RefObject, createRef, useEffect, useState } from "react"
import { ModalPopup } from "../../common/modalPopup/ModalPopup";

import { useAppDispatch, useAppSelector } from "../../../app/hooks";
import { setInformationAction } from "../../informationBar/reducer/InformationBarSlice";
import { resetFileUploadStore } from "../reducer/ImportXMLFileUploadSlice";
import { resetImportXMLHistoryStore } from "../reducer/ImportXMLHistorySlice";
import { resetImportXMLHistoryDeleteStore } from "../reducer/ImportXMLHistoryDeleteSlice";

import { importXMLFileUploadAction } from '../actions/ImportXMLFileUploadAction';
import { importXMLHistoryAction } from "../actions/ImportXMLHistoryAction";
import { importXMLHistoryDeleteAction } from "../actions/ImportXMLHistoryDeleteAction";
import { importXMLInsertAction } from "../actions/ImportXMLInsertAction";

import { ImportXMLModal } from "./importXMLModel";

import { IImportXMLHistoryState, IImportXMLInsertRequst, IImportXMLInsertState } from "../interface/ImportXMLInterface";
import { IImportXMLHistoryDeleteState } from "../interface/ImportXMLInterface";

import { isXmlFile } from "../service/ImportXMLHelperService";

import { IMPORT_XML_CANCELED, IMPORT_XML_ENTER_OBJECT_INFORMATION, IMPORT_XML_FAILED, IMPORT_XML_FILE_LOADING, IMPORT_XML_FILE_LOADING_COMPLETE, IMPORT_XML_FILE_LOADING_FAILED, IMPORT_XML_FILE_TYPE_ALERT, IMPORT_XML_FUNCTIONAL_SPEC, IMPORT_XML_HISTORY_DELETE_LOADING, IMPORT_XML_HISTORY_DELETE_LOADING_COMPLETE, IMPORT_XML_HISTORY_DELETE_LOADING_FAILED, IMPORT_XML_HISTORY_LOADING, IMPORT_XML_HISTORY_LOADING_COMPLETE, IMPORT_XML_HISTORY_LOADING_FAILED, IMPORT_XML_INSERT_XML_COMPLETE, IMPORT_XML_INSERT_XML_FAILED, IMPORT_XML_INSERT_XML_LOADING, IMPORT_XML_RESERVATION_CANCELED, IMPORT_XML_TAKE_OVER_RESERVATION } from "../ImportXMLConstant";
import React from "react";


export const InputXML = (props: any) => {
  const fileRef: RefObject<HTMLInputElement> = createRef<HTMLInputElement>()
  const { userToken } = useAppSelector((state: any) => state.auth)
  const dispatch = useAppDispatch()

  useEffect(() => {
    if (props.onClick) {
      props.setToClose()
      const { current } = fileRef;
      if (current) current.click()
    }
  }, [props.onClick])

  const handleFileChange = (e: ChangeEvent<HTMLInputElement>) => {

    if (e.target.files?.length) {
      const selectedFile = e.target.files[0]
      if (isXmlFile(selectedFile)) {
        dispatch(importXMLFileUploadAction({ userToken, file: selectedFile }))
      } else {
        dispatch(setInformationAction({ message: IMPORT_XML_CANCELED }))
        alert(IMPORT_XML_FILE_TYPE_ALERT)
      }
    } else
      dispatch(setInformationAction({ message: IMPORT_XML_CANCELED }))
    e.target.value = ''
  };

  const { fileLoading, fileLoadingError, xmlData } = useAppSelector((state: any) => state.importXML)

  useEffect(() => {
    fileLoading != null &&
      (fileLoading ? dispatch(setInformationAction({ message: IMPORT_XML_FILE_LOADING })) :
        !fileLoadingError && dispatch(setInformationAction({ message: IMPORT_XML_FILE_LOADING_COMPLETE })))
  }, [fileLoading])

  useEffect(() => {
    if (fileLoadingError != null) {
      dispatch(setInformationAction({ message: fileLoadingError || IMPORT_XML_FILE_LOADING_FAILED, isNewGropu: false }))
      dispatch(setInformationAction({ message: IMPORT_XML_FAILED, isNewGropu: false }))
    }
  }, [fileLoadingError])

  const [modalOpen, setModalOpen] = useState<boolean>(false);
  useEffect(() => { xmlData && setModalOpen(true) }, [xmlData])

  const InsertXml = () => {
    let data: IImportXMLInsertRequst = { ...formData }
    dispatch(importXMLInsertAction({ userToken, data }))
  }

  const { historyLoading, historyError, historyData } = useAppSelector<IImportXMLHistoryState>((state: any) => state.importXMLHistory)
  useEffect(() => {
    historyLoading != null &&
      (historyLoading ? dispatch(setInformationAction({ message: IMPORT_XML_HISTORY_LOADING, isNewGropu: false })) :
        dispatch(setInformationAction({ message: IMPORT_XML_HISTORY_LOADING_COMPLETE, isNewGropu: false })))
  }, [historyLoading])

  useEffect(() => {
    if (historyError != null) {
      dispatch(resetFileUploadStore())
      dispatch(setInformationAction({ message: historyError || IMPORT_XML_HISTORY_LOADING_FAILED, isNewGropu: false }))
      dispatch(setInformationAction({ message: IMPORT_XML_FAILED, isNewGropu: false }))
    }
  }, [historyError])

  const [historyModalOpen, setHistoryModalOpen] = useState<boolean>(false);
  useEffect(() => {
    historyData &&
      (historyData.confirmationMessage ? setHistoryModalOpen(true) : InsertXml())
  }, [historyData])

  const { historyDeleteLoading, historyDeleteError, historyDeleteData } = useAppSelector<IImportXMLHistoryDeleteState>((state: any) => state.importXMLHistoryDelete)
  useEffect(() => {
    historyDeleteLoading != null &&
      (historyDeleteLoading ?
        dispatch(setInformationAction({ message: IMPORT_XML_HISTORY_DELETE_LOADING, isNewGropu: false })) :
        dispatch(setInformationAction({ message: IMPORT_XML_HISTORY_DELETE_LOADING_COMPLETE, isNewGropu: false })))
  }, [historyDeleteLoading])

  useEffect(() => {
    if (historyDeleteError != null) {
      dispatch(resetFileUploadStore())
      dispatch(resetImportXMLHistoryStore())
      dispatch(setInformationAction({ message: historyDeleteError || IMPORT_XML_HISTORY_DELETE_LOADING_FAILED, isNewGropu: false }))
      dispatch(setInformationAction({ message: IMPORT_XML_FAILED, isNewGropu: false }))
    }
  }, [historyDeleteError])

  useEffect(() => { historyDeleteData && InsertXml() }, [historyDeleteData])

  const { xmlInsertLoading, xmlInsertError, xmlInsertData } = useAppSelector<IImportXMLInsertState>((state: any) => state.importXMLInsert)
  useEffect(() => {
    xmlInsertLoading != null &&
      (xmlInsertLoading ?
        dispatch(setInformationAction({ message: IMPORT_XML_INSERT_XML_LOADING, isNewGropu: false })) :
        !xmlInsertError && dispatch(setInformationAction({ message: IMPORT_XML_INSERT_XML_COMPLETE, isNewGropu: false }))
      )
  }, [xmlInsertLoading])

  useEffect(() => {
    if (xmlInsertError != null) {
      dispatch(resetFileUploadStore())
      dispatch(resetImportXMLHistoryStore())
      dispatch(resetImportXMLHistoryDeleteStore())
      dispatch(setInformationAction({ message: xmlInsertError || IMPORT_XML_INSERT_XML_FAILED, isNewGropu: false }))
      dispatch(setInformationAction({ message: IMPORT_XML_FAILED, isNewGropu: false }))
    }
  }, [xmlInsertError])

  const [unitReserveOpen, setUnitReserveOpen] = useState<boolean>(false);
  useEffect(() => {
    xmlInsertData &&
      (xmlInsertData.confirmationMessage && setUnitReserveOpen(true))
  }, [xmlInsertData])


  const [formData, setFormData] = useState<any>({});
  const handleChange = (formData: IImportXMLInsertRequst) => { setFormData(formData) }

  return (
    <>
      <input
        accept=".xml"
        type="file" hidden ref={fileRef} onChange={(e) => handleFileChange(e)} />

      <ModalPopup
        onSave={() => {
          dispatch(importXMLHistoryAction({ userToken, fileName: xmlData.fileName }));
          setModalOpen(false)
        }}
        onClose={() => {
          dispatch(resetFileUploadStore())
          dispatch(setInformationAction({ message: IMPORT_XML_CANCELED, isNewGropu: false }));
          setModalOpen(false)
        }}
        isOpen={modalOpen}
        title={IMPORT_XML_ENTER_OBJECT_INFORMATION}>
        {xmlData && <ImportXMLModal xmlData={xmlData} onChange={handleChange} />}
      </ModalPopup>

      <ModalPopup
        onSave={() => {
          setHistoryModalOpen(false)
          dispatch(importXMLHistoryDeleteAction({
            userToken,
            fileName: xmlData.fileName,
            pcsdDataKey: historyData?.pcsdDataKey,
            pcsdDataKey_SIM: historyData?.pcsdDataKey_SIM
          }))
        }}
        onClose={() => {
          dispatch(resetFileUploadStore())
          dispatch(resetImportXMLHistoryStore())
          dispatch(setInformationAction({ message: IMPORT_XML_CANCELED, isNewGropu: false }));
          setHistoryModalOpen(false)
        }}
        isOpen={historyModalOpen}
        title={IMPORT_XML_FUNCTIONAL_SPEC}>
        <div>{historyData?.confirmationMessage}</div>
      </ModalPopup>

      <ModalPopup
        onSave={() => setUnitReserveOpen(false)}
        onClose={() => {
          dispatch(setInformationAction({ message: IMPORT_XML_RESERVATION_CANCELED, isNewGropu: false }));
          setUnitReserveOpen(false)
        }}
        isOpen={unitReserveOpen}
        title={IMPORT_XML_TAKE_OVER_RESERVATION}>
        <div>{xmlInsertData?.confirmationMessage}</div>
      </ModalPopup>
    </>
  )
}