import { useEffect, useState } from "react"
import { ModalPopup } from "../../common/modalPopup/ModalPopup"
import { fieldKey } from "../ImportXMLEnum"
import { ImportXMLDropdown } from "./importXMLDropdown"
import { IImportXMLInsertRequst } from "../interface/ImportXMLInterface"
import React from "react"
import NewModel from '../../../assest/img/open-new-window.svg';

// 5/2/2023
const labelStyle = { width: '35%', fontSize: '11px', fontFamily: 'abbvoicemedium', color: '#1F1F1F' }
const inputStyle = { width: '55%' }
const btnCommentStyle = { width: '15%', marginLeft: '20px' }
const fieldStyle = { width: '100%', display: 'inline-flex', margin: '2px 0px 2px 0px' }

export const ImportXMLModal = (props: any) => {
  const [xmlData, setXmlData] = useState<any>(props.xmlData);

  useEffect(() => { setXmlData(props.xmlData) }, [props.xmlData])
  useEffect(() => {
    setFormData(values => ({
      ...values,
      plantName: getValue(fieldKey.plantName),
      areaName: getValue(fieldKey.areaName),
      cellName: getValue(fieldKey.cellName),
      unitName: getValue(fieldKey.unitName),
      unitDesc: getValue(fieldKey.unitDesc),
      unitDescALL: getValue(fieldKey.unitDescALL),
      multiuse: getValue(fieldKey.multiuse),
      template: getValue(fieldKey.template),
      designerName: getValue(fieldKey.designerName),
      unitStatus: getValue(fieldKey.unitStatus),
      revNumber: getValue(fieldKey.revNumber),
      revComment: getValue(fieldKey.revComment),
      tagNamePrefix: getValue(fieldKey.tagNamePrefix),
      fileName: getValue(fieldKey.fileName)
    }))
  }, [xmlData])

  const [modalOpen, setModalOpen] = useState<boolean>(false);



  if (modalOpen == true) {
    document.body.classList.add('modal-open-width');
  }
  else {
    document.body.classList.remove('modal-open-width');
  }


  const getValue = (key: fieldKey) => {
    let value: any;
    try { value = xmlData[key].toString(); } catch { }
    return value! ? value : ''
  }

  const [formData, setFormData] = useState<IImportXMLInsertRequst>({
    plantName: getValue(fieldKey.plantName),
    areaName: getValue(fieldKey.areaName),
    cellName: getValue(fieldKey.cellName),
    unitName: getValue(fieldKey.unitName),
    unitDesc: getValue(fieldKey.unitDesc),
    unitDescALL: getValue(fieldKey.unitDescALL),
    multiuse: getValue(fieldKey.multiuse),
    template: getValue(fieldKey.template),
    designerName: getValue(fieldKey.designerName),
    unitStatus: getValue(fieldKey.unitStatus),
    revNumber: getValue(fieldKey.revNumber),
    revComment: getValue(fieldKey.revComment),
    tagNamePrefix: getValue(fieldKey.tagNamePrefix),
    fileName: getValue(fieldKey.fileName)
  })

  useEffect(() => { props.onChange(formData) }, [formData])
  const [externalComment, setExternalComment] = useState<string>(formData.revComment);

  const fieldInfo = [
    { label: 'Plant Name', key: fieldKey.plantName },
    { label: 'Area Name', key: fieldKey.areaName },
    { label: 'Process Cell Name', key: fieldKey.cellName },
    { label: 'Object Name', key: fieldKey.unitName },
    { label: 'Object Description', key: fieldKey.unitDesc },
    { label: 'Object In Multiuse', key: fieldKey.multiuse },
    { label: 'Object Template', key: fieldKey.template },
    { label: 'Object Designer Name', key: fieldKey.designerName },
    { label: 'Object Status', key: fieldKey.unitStatus },
    { label: 'Object Revision Number', key: fieldKey.revNumber },
    { label: 'Object Revision Comment', key: fieldKey.revComment }
  ]

  const handleChange = (event: any) => {
    const name = event.target.name;
    const value = event.target.value;
    if (name === 'externalComment')
      setExternalComment(value)
    else
      setFormData(values => ({ ...values, [name]: value }))

  }

  const handleDropdownChange = (name: string, value: string) => {
    if (name) {
      value = value || ''
      setFormData(values => ({ ...values, [name]: value }))
    }
  }

  const getList = (key: fieldKey) => {
    let list: any[] = []
    let l = JSON.parse(JSON.stringify(xmlData))
    try { list = l[key + 'List']; } catch { list = [] }
    let selectedOption = getValue(key)
    if (selectedOption && list && !(list.filter((o: any) => o.toString() == selectedOption.toString()).length)) {
      list.push(selectedOption.toString())
    }
    return list
  }

  const getField = (key: fieldKey) => {
    switch (key) {
      case fieldKey.plantName:
      case fieldKey.areaName:
      case fieldKey.cellName:
      case fieldKey.unitName:
      case fieldKey.multiuse:
      case fieldKey.template:
      case fieldKey.unitStatus:
        return xmlData && <ImportXMLDropdown fieldName={key} options={getList(key)} selectedOption={getValue(key)} onChange={handleDropdownChange} />;
      case fieldKey.unitDesc:
        return <textarea className="text-area-custom" name={fieldKey.unitDesc} value={formData.unitDesc} onChange={handleChange} />
      case fieldKey.designerName:
        return <input className="input-custom" type="text" name={fieldKey.designerName} value={formData.designerName} style={{ width: '97%' }} onChange={handleChange} />
      case fieldKey.revNumber:
        return <input className="input-custom" type="text" name={fieldKey.revNumber} value={formData.revNumber} style={{ width: '97%' }} onChange={handleChange} />
      case fieldKey.revComment:
        return <div className="popup-text-area">
          <textarea className="text-area-custom"
            name={fieldKey.revComment}
            value={formData.revComment}
            onChange={(event) => handleChange(event)}
          />
          <button onClick={() => { setExternalComment(formData.revComment); setModalOpen(true); }} className="btn-custom-openwindow" ><img src={NewModel} className="icon-window" /></button>
        </div>
    }
  }
  return (
    <div className="popup-reserver">
      {props.xmlData ? fieldInfo.map((field, index) =>
        <div key={index} className="custom-form-field">
          <span className="custom-label">{field.label}</span>
          <span className="popup-input">
            {getField(field.key as fieldKey)}
          </span>
        </div>
      ) : 'Loading...'}

      <ModalPopup
        onSave={() => { setFormData(values => ({ ...values, revComment: externalComment })); setModalOpen(false) }}
        onClose={() => { setExternalComment(formData.revComment); setModalOpen(false) }}
        isOpen={modalOpen}
        title='Enter Object Information  ( Import XML FS)  -  Revision comments'
        style={{ zindex: 1000 }}
        className="popup-reserver"
      >
        <div style={{ width: '100%' }}>
          <span style={{ width: '100%' }}>
            <textarea className="text-area-reverse"
              name='externalComment'
              value={externalComment}
              onChange={(event) => handleChange(event)}
            />
          </span>
        </div>
      </ModalPopup>
    </div>
  )
}

function getElementById(arg0: string) {
  throw new Error("Function not implemented.")
}
