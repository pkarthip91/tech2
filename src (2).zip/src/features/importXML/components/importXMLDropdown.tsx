import { Dropdown, DropdownOption } from "@abb/abb-common-ux-react"
import React from "react"
import { useEffect, useState } from "react"

interface IOptionType {
  value: string,
  label: string,
  isNew: boolean
}

export const ImportXMLDropdown = (props: { fieldName: string, options: any[], selectedOption: any, onChange: any }) => {


  const mapOptions = (options: any[]) => {
    let mappedOptions: IOptionType[] = new Array<IOptionType>()
    if (options) {
      options.map(opt => { return mappedOptions.push({ value: opt.toString(), label: opt.toString(), isNew: false }) })
    }
    return mappedOptions
  }


  const handleNewValue = (selection: IOptionType) => {
    setDropDownOptions(options => [...options, selection]);
    handleUpdate(selection);
  }

  const handleUpdate = (selection: IOptionType) => {
    setSelectedValue(selection);
    props.onChange(props.fieldName, selection.value)
  }

  const [dropDownOptions, setDropDownOptions] = useState<IOptionType[]>(mapOptions(props.options))
  const [selectedValue, setSelectedValue] = useState<IOptionType | undefined>(dropDownOptions.find(o => o.value == props.selectedOption.toString()))

  useEffect(() => { setDropDownOptions(mapOptions(props.options)) }, [props.options])

  const [userName, setUserName] = useState('');

  const ChangeUsername = (e: any) => {
    setDropDownOptions(e.target.value);
    e.preventDefault();
    var Mydrop: any = document.getElementById("myDrop");
    Mydrop.classList.add("show");
  }

  const myFunction = () => {
    var Mydrop: any = document.getElementById("myDrop");
    Mydrop.classList.toggle("show");
  }

  const Dopdownlist = (e: any) => {
    setDropDownOptions(e.target.value);
    var Mydrop: any = document.getElementById("myDrop");
    Mydrop.classList.remove('show');
  }

  return (
    <>
      {/* <Dropdown
        {...{
          value: selectedValue ? [selectedValue] : undefined,
          onChange: (selection) => {
            selection[0].isNew ?
              handleNewValue(selection[0]) :
              handleUpdate(selection[0])
          },
          allowAdd: true,
          searchable: true
        }}
      >
        {dropDownOptions && dropDownOptions.map(o =>
          <DropdownOption
            key={o.value}
            value={o.value}
            label={o.label}
          />)
        }
      </Dropdown > */}


      {dropDownOptions && dropDownOptions.map(o =>
        <><input onClick={myFunction} className="control-input" id="myInput Drop" type="select"
        value={o.value} onChange={ChangeUsername} />
        <div id="myDrop" className="dropdown-content">
          {/* <div>{userName}</div> */}
          <div className="search">
            {dropDownOptions.filter((selectedValue: any) => o.value.includes(o.value)).map((value: any, key: any) => {
              return (
                <li className="list-option" key={key} onClick={Dopdownlist}>{o.value}</li>
              )
            })}
          </div>
        </div><span className="input-group-text">
            <i className="arrow-custom down-arrow"></i>
          </span>
        </>)
      }

    </>
  )
}


