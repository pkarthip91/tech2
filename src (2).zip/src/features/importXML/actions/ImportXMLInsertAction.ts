import { createAsyncThunk } from "@reduxjs/toolkit";
import { Logger } from "../../../app/common/LoggerService";
import { IMPORT_XML_INSERT_ACTION, IMPORT_XML_INSERT_ACTION_FAIL, IMPORT_XML_INSERT_REDUCER, IMPORT_XML__HISTORY_DELETE_ACTION_FAIL } from "../ImportXMLConstant";
import { importXMLInsertService } from "../service/ImportXMLApiService"

export const importXMLInsertAction = createAsyncThunk(
  `${IMPORT_XML_INSERT_REDUCER}/${IMPORT_XML_INSERT_ACTION}`,
  async ({ userToken, data }: any, { rejectWithValue }: any) => {
    let result = null
    try {
      const response = await importXMLInsertService(userToken, data)
      Logger.info('Import XML insert api response- ', response)
      debugger
      if (response.status === 200 && response.data) {
        result = {
          confirmationMessage: response.data.confirmationMessage || null,
          simDataKey: response.data.simDataKey || 0,
          pcsdDataKey: response.data.pcsdDataKey || 0,
          sisDataKey: response.data.sisDataKey || null
        }
      } else if (response.status === 400) {
        if (response.data && response.data.errors && response.data.errors.Error0?.length) {
          result = rejectWithValue(response.data.errors.Error0[0])
        }
      }
    } catch (error: any) {
      Logger.error(`${IMPORT_XML_INSERT_ACTION_FAIL}`, error)
      if (error.message || error.response.data) {
        result = rejectWithValue(error.message || error.response.data)
      }
    }
    return result || rejectWithValue(`${IMPORT_XML_INSERT_ACTION_FAIL}`)
  }
)
