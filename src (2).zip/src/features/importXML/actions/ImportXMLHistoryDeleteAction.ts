import { createAsyncThunk } from "@reduxjs/toolkit";
import { Logger } from "../../../app/common/LoggerService";
import { IMPORT_XML_HISTORY_DELETE_REDUCER, IMPORT_XML__HISTORY_DELETE_ACTION, IMPORT_XML__HISTORY_DELETE_ACTION_FAIL } from "../ImportXMLConstant";
import { importXMLFileUploadService, importXMLHistoryDeleteService } from "../service/ImportXMLApiService"

export const importXMLHistoryDeleteAction = createAsyncThunk(
  `${IMPORT_XML_HISTORY_DELETE_REDUCER}/${IMPORT_XML__HISTORY_DELETE_ACTION}`,
  async ({ userToken, fileName, pcsdDataKey, pcsdDataKey_SIM }: any, { rejectWithValue }: any) => {
    let result = null
    try {
      const response = await importXMLHistoryDeleteService(userToken, fileName, pcsdDataKey, pcsdDataKey_SIM)
      Logger.info('Import XML HistoryDelete api response- ', response)
      debugger
      if (response.status === 200 && response.data) {
        result = response.data || false
      } else if (response.status === 400) {
        if (response.data && response.data.errors && response.data.errors.Error0?.length) {
          result = rejectWithValue(response.data.errors.Error0[0])
        }
      }
    } catch (error: any) {
      Logger.error(`${IMPORT_XML__HISTORY_DELETE_ACTION_FAIL}`)
      if (error.message || error.response.data) {
        result = rejectWithValue(error.message || error.response.data)
      }
    }
    return result || rejectWithValue(`${IMPORT_XML__HISTORY_DELETE_ACTION_FAIL}`)
  }
)
