import { createAsyncThunk } from "@reduxjs/toolkit";
import { Logger } from "../../../app/common/LoggerService";
import { IMPORT_XML_REDUCER, IMPORT_XML_FILE_UPLOAD_ACTION, IMPORT_XML_FILE_UPLOAD_ACTION_FAIL } from "../ImportXMLConstant";
import { importXMLFileUploadService } from "../service/ImportXMLApiService"

export const importXMLFileUploadAction = createAsyncThunk(
  `${IMPORT_XML_REDUCER}/${IMPORT_XML_FILE_UPLOAD_ACTION}`,
  async ({ userToken, file }: any, { rejectWithValue }: any) => {
    let result = null
    try {
      const response = await importXMLFileUploadService(userToken, file)
      Logger.info('Import XML file upload api response- ', response)

      if (response.status === 200 && response.data) {
        result = response.data
      } else if (response.status === 400) {
        if (response.data && response.data.errors && response.data.errors.Error0?.length) {
          result = rejectWithValue(response.data.errors.Error0[0])
        }
      }
    } catch (error: any) {
      Logger.error(`${IMPORT_XML_FILE_UPLOAD_ACTION_FAIL}`)
      if (error.message || error.response.data) {
        result = rejectWithValue(error.message || error.response.data)
      }
    }
    return result || rejectWithValue(`${IMPORT_XML_FILE_UPLOAD_ACTION_FAIL}`)
  }
)
