import { createAsyncThunk } from "@reduxjs/toolkit";
import { Logger } from "../../../app/common/LoggerService";
import { IMPORT_XML_REDUCER, IMPORT_XML_FILE_UPLOAD_ACTION, IMPORT_XML_FILE_UPLOAD_ACTION_FAIL, IMPORT_XML_HISTORY_REDUCER, IMPORT_XML__HISTORY_ACTION, IMPORT_XML__HISTORY_ACTION_FAIL } from "../ImportXMLConstant";
import { importXMLFileUploadService, importXMLHistoryService } from "../service/ImportXMLApiService"

export const importXMLHistoryAction = createAsyncThunk(
  `${IMPORT_XML_HISTORY_REDUCER}/${IMPORT_XML__HISTORY_ACTION}`,
  async ({ userToken, fileName }: any, { rejectWithValue }: any) => {
    let result = null
    try {
      const response = await importXMLHistoryService(userToken, fileName)
      Logger.info('Import XML History api response- ', response)
      debugger
      if (response.status === 200 && response.data) {
        result = {
          confirmationMessage: response.data.confirmationMessage || null,
          pcsdDataKey: response.data.pcsdDataKey || 0,
          pcsdDataKey_SIM: response.data.pcsdDataKey_SIM || 0,
          reservedBy: response.data.reservedBy || null
        }
      } else if (response.status === 400) {
        if (response.data && response.data.errors && response.data.errors.Error0?.length) {
          result = rejectWithValue(response.data.errors.Error0[0])
        }
      }
    } catch (error: any) {
      Logger.error(`${IMPORT_XML__HISTORY_ACTION_FAIL}`)
      if (error.message || error.response.data) {
        result = rejectWithValue(error.message || error.response.data)
      }
    }
    return result || rejectWithValue(`${IMPORT_XML__HISTORY_ACTION_FAIL}`)
  }
)
