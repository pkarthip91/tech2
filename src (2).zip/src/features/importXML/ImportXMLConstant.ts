export const IMPORT_XML_REDUCER = 'importXML'
export const IMPORT_XML_FILE_UPLOAD_ACTION = 'importXMLFileUploadAction'
export const IMPORT_XML_FILE_UPLOAD_ACTION_FAIL = 'Import XML file upload failed!'

export const IMPORT_XML_HISTORY_REDUCER = 'importXMLHistory'
export const IMPORT_XML__HISTORY_ACTION = 'importXMLHistoryAction'
export const IMPORT_XML__HISTORY_ACTION_FAIL = 'Import XML History failed!'

export const IMPORT_XML_HISTORY_DELETE_REDUCER = 'importXMLHistoryDelete'
export const IMPORT_XML__HISTORY_DELETE_ACTION = 'importXMLHistoryDeleteAction'
export const IMPORT_XML__HISTORY_DELETE_ACTION_FAIL = 'Import XML History deletee failed!'

export const IMPORT_XML_INSERT_REDUCER = 'importXMLInsert'
export const IMPORT_XML_INSERT_ACTION = 'importXMLInsertAction'
export const IMPORT_XML_INSERT_ACTION_FAIL = 'Import XML insert failed!'

export const IMPORT_XML_CANCELED = 'Import XML canceled'
export const IMPORT_XML_FAILED = 'Import XML failed'
export const IMPORT_XML_FILE_TYPE_ALERT = 'Please select XML file only!'

export const IMPORT_XML_FILE_LOADING = 'File loading...'
export const IMPORT_XML_FILE_LOADING_COMPLETE = 'File loading complete'
export const IMPORT_XML_FILE_LOADING_FAILED = 'File loading failed'
export const IMPORT_XML_ENTER_OBJECT_INFORMATION = 'Enter object information (Import XML FS)'

export const IMPORT_XML_HISTORY_LOADING = 'Checking history...'
export const IMPORT_XML_HISTORY_LOADING_COMPLETE = 'Checking history complete'
export const IMPORT_XML_HISTORY_LOADING_FAILED = 'Checking history failed'
export const IMPORT_XML_FUNCTIONAL_SPEC = 'Import Functional Spec'

export const IMPORT_XML_HISTORY_DELETE_LOADING = 'Deleting history...'
export const IMPORT_XML_HISTORY_DELETE_LOADING_COMPLETE = 'Deleting history complete'
export const IMPORT_XML_HISTORY_DELETE_LOADING_FAILED = 'Deleting history failed'

export const IMPORT_XML_INSERT_XML_LOADING = 'Updating database...'
export const IMPORT_XML_INSERT_XML_COMPLETE = 'Load XML and User default data completed'
export const IMPORT_XML_INSERT_XML_FAILED = 'Updating database failed'

export const IMPORT_XML_TAKE_OVER_RESERVATION = 'Take Over Reservation'
export const IMPORT_XML_RESERVATION_CANCELED = 'Reservation canceled'