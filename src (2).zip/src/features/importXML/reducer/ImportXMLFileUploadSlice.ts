import { createSlice } from '@reduxjs/toolkit';
import { importXMLFileUploadAction } from '../actions/ImportXMLFileUploadAction';
import { IMPORT_XML_REDUCER } from '../ImportXMLConstant';

interface IImportXMLState {
  fileLoading: boolean | null,
  xmlData: any | null,
  fileLoadingError: string | null
}
const initialState: IImportXMLState = {
  fileLoading: null,
  xmlData: null,
  fileLoadingError: null
}

export const importXMLSlice = createSlice({
  name: `${IMPORT_XML_REDUCER}`,
  initialState,
  reducers: {
    resetFileUploadStore: (state) => {
      state = initialState
    }
  },
  extraReducers: (builder) => {
    builder
      .addCase(importXMLFileUploadAction.pending, (state) => {
        state.fileLoading = true;
        state.fileLoadingError = null;
        state.xmlData = null;
      })
      .addCase(importXMLFileUploadAction.fulfilled, (state, { payload }: any) => {
        state.fileLoading = false;
        state.fileLoadingError = null;
        state.xmlData = payload
      })
      .addCase(importXMLFileUploadAction.rejected, (state, { payload }: any) => {
        state.fileLoading = false;
        state.fileLoadingError = payload || '';
        state.xmlData = null;
      });
  },
});
export const { resetFileUploadStore } = importXMLSlice.actions
export default importXMLSlice.reducer;
