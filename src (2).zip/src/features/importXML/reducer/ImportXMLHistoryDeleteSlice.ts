import { createSlice } from '@reduxjs/toolkit';
import { importXMLHistoryDeleteAction } from '../actions/ImportXMLHistoryDeleteAction';
import { IMPORT_XML_HISTORY_DELETE_REDUCER } from '../ImportXMLConstant';
import { IImportXMLHistoryDeleteState } from '../interface/ImportXMLInterface';


const initialState: IImportXMLHistoryDeleteState = {
  historyDeleteLoading: null,
  historyDeleteData: null,
  historyDeleteError: null
}

export const importXMLHistoryDeleteSlice = createSlice({
  name: `${IMPORT_XML_HISTORY_DELETE_REDUCER}`,
  initialState,
  reducers: {
    resetImportXMLHistoryDeleteStore: (state) => {
      state = initialState
    }
  },
  extraReducers: (builder) => {
    builder
      .addCase(importXMLHistoryDeleteAction.pending, (state) => {
        state.historyDeleteLoading = true;
        state.historyDeleteError = null;
        state.historyDeleteData = null;
      })
      .addCase(importXMLHistoryDeleteAction.fulfilled, (state, { payload }: any) => {
        state.historyDeleteLoading = false;
        state.historyDeleteError = null;
        state.historyDeleteData = payload
      })
      .addCase(importXMLHistoryDeleteAction.rejected, (state, { payload }: any) => {
        state.historyDeleteLoading = false;
        state.historyDeleteError = payload;
        state.historyDeleteData = null;
      });
  },
});
export const { resetImportXMLHistoryDeleteStore } = importXMLHistoryDeleteSlice.actions
export default importXMLHistoryDeleteSlice.reducer;
