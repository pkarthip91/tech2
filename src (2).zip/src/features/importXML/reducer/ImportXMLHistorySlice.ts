import { createSlice } from '@reduxjs/toolkit';
import { importXMLHistoryAction } from '../actions/ImportXMLHistoryAction';
import { IMPORT_XML_HISTORY_REDUCER, IMPORT_XML_REDUCER } from '../ImportXMLConstant';
import { IHistory, IImportXMLHistoryState } from '../interface/ImportXMLInterface';


const initialState: IImportXMLHistoryState = {
  historyLoading: null,
  historyData: null,
  historyError: null
}

export const importXMLHistorySlice = createSlice({
  name: `${IMPORT_XML_HISTORY_REDUCER}`,
  initialState,
  reducers: {
    resetImportXMLHistoryStore: (state) => {
      state = initialState
    }
  },
  extraReducers: (builder) => {
    builder
      .addCase(importXMLHistoryAction.pending, (state) => {
        state.historyLoading = true;
        state.historyError = null;
        state.historyData = null;
      })
      .addCase(importXMLHistoryAction.fulfilled, (state, { payload }: any) => {
        state.historyLoading = false;
        state.historyError = null;
        state.historyData = payload
      })
      .addCase(importXMLHistoryAction.rejected, (state, { payload }: any) => {
        state.historyLoading = false;
        state.historyError = payload;
        state.historyData = null;
      });
  },
});
export const { resetImportXMLHistoryStore } = importXMLHistorySlice.actions
export default importXMLHistorySlice.reducer;
