import { createSlice } from '@reduxjs/toolkit';
import { importXMLInsertAction } from '../actions/ImportXMLInsertAction';
import { IMPORT_XML_INSERT_REDUCER } from '../ImportXMLConstant';
import { IImportXMLInsertState } from '../interface/ImportXMLInterface';


const initialState: IImportXMLInsertState = {
  xmlInsertLoading: null,
  xmlInsertData: null,
  xmlInsertError: null
}

export const importXMLInsertSlice = createSlice({
  name: `${IMPORT_XML_INSERT_REDUCER}`,
  initialState,
  reducers: {
  },
  extraReducers: (builder) => {
    builder
      .addCase(importXMLInsertAction.pending, (state) => {
        state.xmlInsertLoading = true;
        state.xmlInsertError = null;
        state.xmlInsertData = null;
      })
      .addCase(importXMLInsertAction.fulfilled, (state, { payload }: any) => {
        state.xmlInsertLoading = false;
        state.xmlInsertError = null;
        state.xmlInsertData = payload
      })
      .addCase(importXMLInsertAction.rejected, (state, { payload }: any) => {
        state.xmlInsertLoading = false;
        state.xmlInsertError = payload;
        state.xmlInsertData = null;
      });
  },
});
export default importXMLInsertSlice.reducer;
