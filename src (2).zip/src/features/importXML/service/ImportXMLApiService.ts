import { httpClient } from '../../../app/api/middlewareSecurity'
import { IImportXMLInsertRequst } from '../interface/ImportXMLInterface'

export const importXMLFileUploadService = (userToken: string, xmlFile: File) => {

  return httpClient.post(`/Import/xml/upload`, { xmlFile }, {
    headers: {
      "Authorization": `Bearer ${userToken}`,
      'Content-Type': 'multipart/form-data'
    }
  })
}

export const importXMLHistoryService = (userToken: string, fileName: string) => {

  return httpClient.post(`/Import/xml/history`, { fileName, isFETool: true }, {
    headers: {
      "Authorization": `Bearer ${userToken}`
    }
  })
}

export const importXMLHistoryDeleteService = (
  userToken: string,
  fileName: string,
  pcsdDataKey: number,
  pcsdDataKey_SIM: number
) => {

  return httpClient.delete(`/Import/xml/history`,
    {
      headers: {
        "Authorization": `Bearer ${userToken}`
      },
      data: { fileName, pcsdDataKey, pcsdDataKey_SIM }
    })
}

export const importXMLInsertService = (userToken: string, data: IImportXMLInsertRequst) => {
  let mapData = Object.assign(data,
    { multiuse: data.multiuse ? true : false },
    { fileName: data.fileName.includes('.xml') ? data.fileName : data.fileName + '.xml' })
  return httpClient.post(`/Import/xml/insert`, { ...mapData }, {
    headers: {
      "Authorization": `Bearer ${userToken}`
    }
  })
}