
import '@abb/abb-common-ux-react/styles.css';
import { AppRoute } from './app/routing/AppRoute';

export const App = () => {
  return (
    <AppRoute />
  );
}
